# DASE7506 Mini-project 3 | SQL Repair Agent

The frozen controller scored **181/240 (75.42%) on the official TEST** and **117/120 (97.50%) on validation**. A question earns a point when its query matches the required output on all three database instances. These are local scores from the course evaluator, subject to instructor reproduction. The controller combines the V16 program with one risk-routed proposal from a Qwen3-0.6B LoRA called H65.

## From a draft to a submitted query

1. V16 requests the schema and checks the exact original draft against the public example. It tracks attempted SQL, tool responses and the remaining budget in the episode history. A static edit or a suggestion from the shared hint tool can become a candidate. The official retrieval tool supplies TRAIN examples whose edits can be adapted to the current schema.
2. V16 selects a provisional answer. If a check remains, the H67 routing rule can request a model proposal when the public check fails, matches an empty result, or when question wording or SQL structure raises a concern about grouping, existence or record selection. The model sees the question, complete public schema, original draft, actual check, public example and ordering flag.
3. The model proposes one complete SQLite query. The program checks that it is read-only and binds to the schema. It reuses a previous check or spends one call to check a distinct query. If only one answer matches the public example, that result guides the choice. If both match, the H61/H66 rules can construct a small in-memory database with a question-grounded expectation, such as two branches with different numbers of clients. This distinguishes a per-branch average from a per-client average. An inconclusive comparison retains V16's answer.

Each task starts with fresh state. One shared process caches the model weights. The live limits are eight charged tool calls and one greedy, non-thinking completion of up to 384 new tokens per task. The fixed hint service is a course tool.

## Model and training

The base is `Qwen/Qwen3-0.6B` at `c1899de289a04d12100db370d81485cdf75e47ca`. It has 596,049,920 parameters. The unmerged adapter adds 1,146,880, for **597,196,800 total**. The optimizer trained rank-8 LoRA A/B matrices on the query and value projections, with alpha 16. The base and tokenizer remained frozen. CPU inference loads safetensors locally with remote code disabled.

H65 used 257 distinct course TRAIN questions from 74 databases within a fitting partition of 305 questions from 75 databases. The 257 labels included 196 repairs and 61 cases where the draft could be kept. Training used the question, schema, draft and public feedback to predict a complete SQL answer. Reference SQL and offline checks supported labeling. The run made 76 optimizer updates with effective batch size eight, presenting 608 samples and supervising 18,257 answer tokens. The exact schedule, optimizer settings, training log, label evidence and file digests accompany this report under `training/`. Validation was used for design and regression checks. Other frozen systems were also evaluated during the project. This hand-in uses the highest recorded aggregate TEST result. The H80 controller and H65 adapter were fixed before their reported TEST run. The project has historical benchmark exposure, including post-run review.

## Controlled comparisons on TRAIN

The 79-task development panel and the 96-task confirmation panel used different databases from the fitting set and each other. Both panels had been examined in earlier experiments. Comparisons used the same tasks and reused verified model outputs for identical prompts and weights when isolating controller decisions.

| Change under comparison | Same-task outcome |
|---|---|
| Add the risk-routed H65 proposal and its acceptance rules to V16 | V16 scored 59/79 and 76/96. The complete controller scored 62/79 and 79/96, gaining three questions on each panel and losing none. This comparison measures the combined change. |
| Add the H66 tie rule while holding the all-call proposals fixed | Confirmation improved from 78/96 to 79/96. The added check distinguished a branch-level average from an average that gives branches with more clients greater weight. |
| Enable H67 routing while keeping proposal and acceptance settings fixed | Across the combined 175 tasks, model calls fell from 175 to 146 and charged actions fell from 789 to 771. All 175 submitted queries remained identical. |
| Add one candidate by merging independent edits to two queries | On the 79-task panel this spent one extra check, left all submissions unchanged and added no three-instance-correct candidate. It did not advance to confirmation. |

### Failure analysis on TRAIN

A development question requested male persons' names and ages ordered by age. V16 had dropped the age output, and the model had dropped the ordering. A proposed merge lost both requirements. An empty public instance allowed the merged query to match. The tie rule retained the incumbent, and both queries passed only one of the three instances. A public match can give little evidence about either a missing column or the order of an empty result. Independent boundary examples provided semantic support for two of the six aggregate gains over V16, contradicted three, and left one question ambiguous.

## Runtime, safeguards and reproduction

| Frozen run | Validation | TEST |
|---|---:|---:|
| Official three-instance score | 117/120 | 181/240 |
| Live model calls | 98 | 182 |
| Generated tokens, total / maximum per completion | 2,184 / 83 | 4,781 / 384 |
| Charged tool calls, mean / maximum per task | 4.32 / 8 | 4.30 / 8 |
| Prediction wall time | 664.19 s | 1,193.81 s |
| Prediction CPU time, user plus system | 2,340.49 s | 4,185.19 s |
| Peak predictor RSS | 4.60 GiB | 4.64 GiB |
| Official scoring wall time | 8.70 s | 16.92 s |

Prediction used offline Linux, four CPU threads and one worker. The separate official scorer replayed the tool traces. The run recorded each model prompt, generated text, token count and model identity. See [reproduction commands](REPRODUCE.md) and the resource and identity records under `evidence/`.

A question, retrieved SQL, a database value or a tool suggestion can contain instructions. The controller supplies this material as data in a structured prompt. The model can return a candidate query only. The controller decides tool calls, enforces the budget, checks query form and field binding, and delegates benchmark database access to the course read-only tools. A malicious or misleading value may still influence query semantics. Input validation and the independent acceptance step limit what such a proposal can do.

## Assistance and attribution

OpenAI Codex assisted with implementation, experiment design, diagnostics, verification and writing. Other LLMs were consulted in historical design discussions. Graded inference used the single declared local model and the course's fixed shared hint cache. The benchmark derives from Spider with course modifications. Dependency, dataset and model attributions are in [NOTICE](NOTICE).
