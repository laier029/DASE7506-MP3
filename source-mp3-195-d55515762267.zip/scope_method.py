from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from prior_method import create_agent as prior
from harness_lab.grain_repair.scopes import ScopeAgent

def create_agent(checkpoint=None):
    return ScopeAgent(prior(checkpoint),'scope_early')
