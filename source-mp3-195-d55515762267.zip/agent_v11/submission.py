"""Independent champion + explicitly cued, checked top-k aggregation branch."""

from dataclasses import asdict, replace
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agent_v2.submission import canonical
from agent_v5.submission import SqlRepairAgent as SharedController, load_config as shared_config
from agent_v11.topk import build_topk_options


NUMBER_WORDS = dict(zip("one two three four five six seven eight nine ten".split(), range(1, 11)))
AGGREGATE_WORDS = {"sum": "SUM", "total": "SUM", "average": "AVG", "mean": "AVG",
                   "minimum": "MIN", "maximum": "MAX"}
NEGATION = re.compile(r"\b(?:no|not|never|without|except|exclude|excludes|excluded|excluding|"
                      r"neither|nor|unless|instead|rather|avoid|ignore|ignores|ignored|ignoring|"
                      r"omit|omits|omitted|omitting|outside|beyond|other\s+than)\b|n[’']t\b", re.I)
COUNT_CONTINUATION = re.compile(r"\s+(?:(?:hundred|thousand|million|billion|trillion|dozen)s?\b|"
                                r"(?:half|halves|thirds?|quarters?|fourths?|fifths?|sixths?|sevenths?|"
                                r"eighths?|ninths?|tenths?|point|percent|percentage|and|or|to|through)\b|"
                                r"per\s+cent\b|%|/)", re.I)
QUOTES = frozenset("\"'`‘’“”")


def infer_topk(question, option):
    """Record lexical support, not a proof of output meaning or field correctness."""
    result = {"operation": None, "status": "unresolved", "evidence": [],
              "assumptions": []}
    if option is None:
        return {**result, "reason": "no_supported_same_level_aggregate_limit_shape"}
    if not isinstance(question, str) or any(char in QUOTES for char in question):
        return {**result, "reason": "quoted_or_nontext_question_is_outside_this_lexical_slice"}
    if NEGATION.search(question):
        return {**result, "reason": "negation_or_exclusion_scope_is_uncertain"}
    rankings = list(re.finditer(r"\b(top|bottom)\s+(\S+)", question, re.I))
    if len(rankings) != 1:
        return {**result, "reason": "need_one_explicit_top_or_bottom_count"}
    ranking = rankings[0]
    token = ranking.group(2).casefold()
    count = NUMBER_WORDS.get(token)
    if count is None and len(token) <= 19 and re.fullmatch(r"[0-9]+", token):
        count = int(token)
    if count is None or count != option.limit or COUNT_CONTINUATION.match(question[ranking.end():]):
        return {**result, "reason": "question_count_is_not_an_exact_match_to_existing_limit"}
    aggregate_mentions = list(re.finditer(r"\b(?:sum|total|average|mean|minimum|maximum)\b", question, re.I))
    operations = {AGGREGATE_WORDS[match.group().casefold()] for match in aggregate_mentions}
    if operations != {option.aggregate} or re.search(r"\btotal\s+(?:number|count)\b", question, re.I):
        return {**result, "reason": "output_aggregate_intent_is_missing_ambiguous_or_different"}
    evidence = [{"kind": "ranking_words", "text": ranking.group(),
                 "start": ranking.start(), "end": ranking.end(),
                 "direction_word": ranking.group(1).casefold(), "count": count}]
    evidence += [{"kind": "aggregate_word", "text": match.group(), "start": match.start(),
                  "end": match.end(), "operation": AGGREGATE_WORDS[match.group().casefold()]}
                 for match in aggregate_mentions]
    return {"operation": "TOPK_THEN_AGGREGATE", "status": "semantic_hypothesis",
            "reason": "explicit_count_and_matching_aggregate_words", "evidence": evidence,
            "assumptions": [
                "The aggregate words describe the requested output over the top/bottom-k rows, not another clause.",
                "The existing ordering expresses the top/bottom ranking; its fields, direction and tie policy are not inferred.",
                *option.assumptions]}


def _validate(config):
    if (config.get("base_policy") != "champion" or config.get("selector") not in ("off", "program")
            or config.get("use_model") is not False):
        raise ValueError("The independent top-k branch supports champion + off/program without a model")


def load_config(checkpoint=None):
    config = shared_config(checkpoint)
    _validate(config)
    if checkpoint is None:
        config["log_dir"] = "outputs/agent-v11-topk-logs"
    return config


class SqlRepairAgent(SharedController):
    def __init__(self, config, base=None):
        _validate(config)
        super().__init__(config, base=base)
        self.pending_details = None

    def _log(self, record):
        super()._log({**record, "kind": "topk"})

    def _lineage(self, parent):
        lineage = []
        candidates = self.state.candidates
        while parent is not None:
            if parent.id in lineage:
                raise ValueError("Candidate lineage must not contain a cycle")
            lineage.append(parent.id)
            parent = candidates.get(parent.parent_id) if parent.parent_id is not None else None
        return lineage

    def _opportunities(self):
        incumbent = replace(self.state.incumbent, sql=self.incumbent_sql)
        matched = self.state.checks[self.incumbent_sql]["observation"].get("matches_example") is True
        parents = [incumbent]
        if not matched:
            parents += [candidate for candidate in self.state.candidates.values() if candidate.id != incumbent.id]
        for parent in parents:
            event = self.state.checks.get(parent.sql)
            if event is None or event["observation"].get("ok") is not True:
                continue
            option = next((option for option in build_topk_options(parent.sql, self.state.schema)
                           if option.name == "TOPK_THEN_AGGREGATE"), None)
            cue = infer_topk(self.state.task["question"], option)
            common = {"parent_id": parent.id, "parent_lineage": self._lineage(parent),
                      "source_sql": parent.sql, "infer_cue": cue}
            selection = cue["operation"] or ("KEEP" if matched else "UNRESOLVED")
            self._log({"phase": "choice", **common, "selection": selection})
            if cue["operation"] is None:
                continue
            identity = canonical(option.sql)
            if identity in self.attempted or any(canonical(sql) == identity for sql in self.state.checks):
                self._log({"phase": "routing", **common, "reason": "candidate_already_checked_or_attempted"})
                continue
            yield parent, option, cue, common, identity

    def act(self, observation):
        self.state.sync(observation)
        self._log({"phase": "state", "state": self.state.snapshot()})
        if not self.base_finished:
            action = self.base.act(observation)
            if action["tool"] != "submit":
                return action
            if action["sql"] not in self.state.checks:
                raise ValueError("The exact baseline submission must already have a real check")
            candidate = self.state.add_candidate(action["sql"], "baseline_incumbent")
            self.state.set_incumbent(candidate.id, "champion_finished_inside_shared_budget")
            self.incumbent_sql = action["sql"]
            self.base_finished = True
        if self.config["selector"] == "off":
            return self._finish("baseline_adapter_only")
        if self.pending is not None:
            details = self.pending_details
            event = self.state.checks.get(details["sql"])
            if event is None:
                raise ValueError("The top-k proposal needs feedback for its exact requested SQL")
            result = event["observation"]
            self._log({"phase": "check", **details, "ok": result["ok"],
                       "matches_example": result["matches_example"], "error": result.get("error")})
            if result["ok"] is True and result["matches_example"] is True:
                self.state.set_incumbent(self.pending, "topk_proposal_matched_real_public_check")
                self.incumbent_sql = details["sql"]
                self._log({"phase": "adopt", **details,
                           "interpretation": "Lexical support and public match support a hypothesis, not semantic proof"})
                return self._finish("checked_topk_repair")
            self.unresolved.append({"candidate_id": self.pending, "sql": details["sql"],
                                    "reason": "topk_proposal_failed_public_check"})
            self.pending, self.pending_details = None, None
        if self.state.remaining <= 0:
            return self._finish("shared_tool_budget_exhausted")
        for parent, option, cue, common, identity in self._opportunities():
            self.attempted.add(identity)
            candidate = self.state.add_candidate(option.sql, "program_topk", parent_id=parent.id,
                operator=option.name, evidence=[cue], assumptions=cue["assumptions"])
            self.pending = candidate.id
            self.pending_details = {**common, "candidate_id": candidate.id, "sql": candidate.sql,
                                    "selection": option.name, "option_id": option.id}
            self._log({"phase": "proposal", **self.pending_details,
                       "option": asdict(option), "remaining_before_check": self.state.remaining})
            return {"tool": "check", "sql": candidate.sql}
        return self._finish("no_supported_untried_topk_action")


def create_agent(checkpoint=None):
    return SqlRepairAgent(load_config(checkpoint))
