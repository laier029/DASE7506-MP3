"""Pure top-k-before-aggregate alternatives; no question or answer inference."""

from dataclasses import dataclass
import hashlib

from sqlglot import exp

from agent_v2.submission import canonical, parse_query
from agent_v3.evidence import grounding_issues
from agent_v4.operators import _aggregate, _positive_limit, _topk_candidate
from agent_v6.binding import FieldBinding, _bind, _inspect as _physical_select
from harness_lab.h05.editor import UnsupportedEdit


CURRENT_SEMANTICS = (
    "The ungrouped aggregate produces one output row from all source/filter rows; "
    "same-level ORDER BY and positive LIMIT apply to that aggregate output, not its input rows."
)
TOPK_SEMANTICS = (
    "Apply the existing sources, JOINs and WHERE, then the existing ORDER BY and LIMIT "
    "to input rows, then aggregate the selected rows' existing measure."
)
ASSUMPTIONS = (
    "The question intends aggregation over the selected top-k input rows; query shape alone does not prove this.",
    "The existing measure, sources, JOINs, filters, ranking fields and direction express the requested meanings.",
    "LIMIT counts physical result rows, including duplicate joined rows and rows with a NULL measure.",
    "Ties at the limit boundary may select different rows unless the supplied ordering resolves them; no tie-breaker is invented.",
    "SQLite aggregate coercion, NULL handling and ordering semantics are retained; changed row order can affect floating-point rounding.",
)
PRECONDITIONS = (
    "One grounded physical SELECT scope with exactly one SUM/AVG/MIN/MAX over a direct column.",
    "No grouping, HAVING, DISTINCT, OFFSET, nested scopes, windows or ambiguous alias references.",
    "ORDER BY contains only bound physical columns; LIMIT is a positive SQLite-range integer literal.",
    "The whole existing FROM/JOIN/WHERE/ORDER/LIMIT subtree is copied into the inner query.",
)


@dataclass(frozen=True)
class TopKOption:
    id: str
    name: str
    sql: str
    source_sql: str
    description: str
    aggregate: str
    measure_sql: str
    measure: FieldBinding
    order_by_sql: tuple[str, ...]
    order_fields: tuple[FieldBinding, ...]
    limit: int
    output_alias: str | None
    current_semantics: str
    resulting_semantics: str
    preconditions: tuple[str, ...]
    assumptions: tuple[str, ...]
    status: str


def _identity(name, sql):
    return "TOPK_" + hashlib.sha256((name + "\0" + canonical(sql)).encode()).hexdigest()


def _inspect(sql, schema):
    # Reuse strict physical-field binding, including every unedited WHERE/JOIN
    # column, and rejection of SELECT-alias collisions in ORDER/GROUP/WHERE.
    tree, sources = _physical_select(sql, schema)
    aggregate = _aggregate(tree)
    if (aggregate is None or not isinstance(aggregate.this, exp.Column)
            or any(tree.args.get(key) for key in ("group", "having", "distinct", "offset"))
            or not tree.args.get("order") or not _positive_limit(tree)):
        raise UnsupportedEdit("Expected one direct-column aggregate with ORDER BY and positive LIMIT")
    limit = tree.args["limit"]
    if any(value for key, value in limit.args.items() if key != "expression"):
        raise UnsupportedEdit("Only a plain LIMIT literal is supported")
    amount = int(limit.expression.this)
    if amount > 2**63 - 1:
        raise UnsupportedEdit("LIMIT must fit SQLite's signed integer range")
    ordered_fields = []
    for ordered in tree.args["order"].expressions:
        value = ordered.this
        while isinstance(value, exp.Paren):
            value = value.this
        if not isinstance(value, exp.Column):
            raise UnsupportedEdit("Ranking expressions, positions and output aliases are not inferred")
        ordered_fields.append(_bind(value, sources))
    if not ordered_fields:
        raise UnsupportedEdit("An explicit ranking field is required")
    return tree, aggregate, _bind(aggregate.this, sources), tuple(ordered_fields), amount


def build_topk_options(sql, schema) -> list[TopKOption]:
    """Return exact KEEP and TOPK_THEN_AGGREGATE, or [] for unsupported input.

    Metadata IDs derive from operation and SQL content, not enumeration position.
    No model, database, task ID, question text, public example or answer is accessed.
    The returned rewrite is an unverified hypothesis; a controller must justify and
    check it. Existing field bindings can be edited first by a separate pure editor.
    """
    try:
        tree, aggregate, measure, order_fields, limit = _inspect(sql, schema)
        edited = _topk_candidate(tree)
        if edited is None or grounding_issues(edited["sql"], schema):
            return []
        changed = parse_query(edited["sql"])
        # The reused rewriter is intentionally narrower here than its V4 caller.
        # Confirm the preserved inner relational/ranking clauses before exposing it.
        inner = changed.args["from"].this.this
        for key in ("from", "joins", "where", "order", "limit"):
            if inner.args.get(key) != tree.args.get(key):
                raise UnsupportedEdit("A preserved source/ranking clause changed")
        common = {
            "source_sql": sql, "aggregate": aggregate.key.upper(),
            "measure_sql": aggregate.this.sql(dialect="sqlite"), "measure": measure,
            "order_by_sql": tuple(item.sql(dialect="sqlite") for item in tree.args["order"].expressions),
            "order_fields": order_fields, "limit": limit,
            "output_alias": tree.expressions[0].alias or None,
            "current_semantics": CURRENT_SEMANTICS,
            "preconditions": PRECONDITIONS, "assumptions": ASSUMPTIONS,
        }
        return [
            TopKOption(_identity("KEEP", sql), "KEEP", sql,
                       description="Keep the exact current query and its aggregate-then-limit behavior.",
                       resulting_semantics=CURRENT_SEMANTICS, status="unchanged", **common),
            TopKOption(_identity("TOPK_THEN_AGGREGATE", edited["sql"]), "TOPK_THEN_AGGREGATE", edited["sql"],
                       description="Aggregate the same measure after applying the existing row ranking and limit.",
                       resulting_semantics=TOPK_SEMANTICS, status="unverified_hypothesis", **common),
        ]
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return []
