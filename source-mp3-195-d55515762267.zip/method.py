from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from scope_method import create_agent as prior
from harness_lab.population_logic.agent import PopulationAgent

def create_agent(checkpoint=None):
    return PopulationAgent(prior(checkpoint),'grounded')
