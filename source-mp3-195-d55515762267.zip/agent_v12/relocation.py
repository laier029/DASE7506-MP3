"""Guard the existing relocation generator with exact error and AST evidence."""
from dataclasses import dataclass
from pathlib import Path
import re
import sys

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from agent_v10.join_repair import (
    UnsupportedJoin, _bind, _require, _schema_tables, _source, _unique_edge,
)

# The frozen submission's pure modules use sibling imports. Reuse exactly those
# modules rather than copying the old policy or its candidate generator.
LEGACY = str(Path(__file__).resolve().parents[1] / "submission")
if LEGACY not in sys.path:
    sys.path.insert(0, LEGACY)
from schema_context import build_schema_context
from schema_grounding import (
    _direct_sources, _path_from_sources, generate_column_relocation_candidates,
)


MISSING_COLUMN = re.compile(r"no such column: ([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\Z")


@dataclass(frozen=True)
class RelocationOption:
    name: str
    sql: str
    preconditions: tuple[str, ...]
    evidence: dict
    assumptions: tuple[str, ...]


def _scope(sql, tables):
    statements = sqlglot.parse(sql, read="sqlite")
    _require(len(statements) == 1 and isinstance(statements[0], exp.Select), "Expected one SELECT")
    tree = statements[0]
    _require(len(list(tree.find_all(exp.Select))) == 1
             and not any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))
             and not any(tree.args.get(key) for key in ("qualify", "windows", "laterals", "operation_modifiers")),
             "Nested or window scope is unsupported")
    origin = tree.args.get("from")
    _require(isinstance(origin, exp.From) and origin.this is not None and not origin.expressions,
             "An ordinary physical FROM is required")
    sources = [_source(origin.this, tables)]
    for join in tree.args.get("joins", []):
        _require(not join.args.get("side") and str(join.args.get("kind") or "").upper() in ("", "INNER")
                 and join.args.get("on") is not None and not join.args.get("method") and not join.args.get("using")
                 and not any(value for key, value in join.args.items()
                             if key not in ("this", "on", "kind", "side", "method", "using")),
                 "Only explicit ordinary INNER JOINs are supported")
        sources.append(_source(join.this, tables))
    _require(len({source["alias"].casefold() for source in sources}) == len(sources)
             and len({source["table"]["name"].casefold() for source in sources}) == len(sources),
             "Duplicate aliases or self-join roles are unsupported")
    _require(not any(not isinstance(star.parent, exp.Count) for star in tree.find_all(exp.Star)),
             "Expanded star fields are unsupported")
    return tree, sources


def _reported_missing(sql, event):
    _require(isinstance(event, dict) and event.get("tool") == "check" and event.get("sql") == sql,
             "The exact original string must have a check event")
    observed = event.get("observation", {})
    error = observed.get("error") or {}
    _require(observed.get("ok") is False and observed.get("matches_example") is False
             and error.get("type") == "OperationalError", "Expected a failed SQLite check")
    message = error.get("message")
    match = MISSING_COLUMN.fullmatch(message) if isinstance(message, str) else None
    _require(match is not None, "Expected one explicit qualified missing-column error")
    return match.group(1), match.group(2), message


def _inspect(sql, schema, event):
    alias, name, message = _reported_missing(sql, event)
    tables = _schema_tables(schema)
    tree, sources = _scope(sql, tables)
    source = next((item for item in sources if item["alias"].casefold() == alias.casefold()), None)
    _require(source is not None and all(column["name"].casefold() != name.casefold()
                                      for column in source["table"]["columns"]),
             "The reported qualifier must bind to a table that lacks this field")
    owners = [(table, column) for table in tables.values() for column in table["columns"]
              if column["name"].casefold() == name.casefold()]
    _require(len(owners) == 1, "The exact column name needs one schema owner")
    target, _ = owners[0]
    missing = []
    for column in tree.find_all(exp.Column):
        if column.table.casefold() == alias.casefold() and column.name.casefold() == name.casefold():
            _require(not column.is_star and not column.db and not column.catalog
                     and column.find_ancestor(exp.Join) is None, "Existing JOIN predicates must remain unchanged")
            missing.append(column)
        else:
            _bind(column, sources)
    _require(missing, "The reported field is not present in this SQL")
    for index, join in enumerate(tree.args.get("joins", [])):
        for column in join.args["on"].find_all(exp.Column):
            _bind(column, sources[:index + 2])
    target_source = next((item for item in sources if item["table"]["name"].casefold() == target["name"].casefold()), None)
    context = build_schema_context(schema)
    path, start_alias, edge_evidence = [], None, []
    if target_source is None:
        start_alias, path = _path_from_sources(context, _direct_sources(tree, context), context.table(target["name"]))
        _require(start_alias is not None and path and len(path) <= 2, "No unique bounded declared FK path")
        introduced = {item["table"]["name"].casefold() for item in sources}
        for edge in path:
            _require(edge.target_table.casefold() not in introduced, "A path cannot reintroduce an existing table")
            introduced.add(edge.target_table.casefold())
            a = {"alias": edge.source_table, "table": tables[edge.source_table.casefold()]}
            b = {"alias": edge.target_table, "table": tables[edge.target_table.casefold()]}
            child, child_column, parent, parent_column = _unique_edge([a], b)
            edge_evidence.append({"source_table": child["table"]["name"], "source_column": child_column["name"],
                                  "target_table": parent["table"]["name"], "target_column": parent_column["name"]})
    target_alias = target_source["alias"] if target_source else target["name"]
    return tree, context, alias, name, target, target_alias, start_alias, path, edge_evidence, message


def _guard(original, candidate, tables, alias, name, target_alias, start_alias, path):
    changed, sources = _scope(candidate, tables)
    old_joins, new_joins = original.args.get("joins", []), changed.args.get("joins", [])
    _require(len(new_joins) == len(old_joins) + len(path) and new_joins[:len(old_joins)] == old_joins,
             "Existing JOINs changed or the path has unexpected edges")
    current_alias = start_alias
    for join, edge in zip(new_joins[len(old_joins):], path):
        expected = exp.Join(this=exp.to_table(edge.target_table), on=exp.EQ(
            this=exp.column(edge.source_column, table=current_alias),
            expression=exp.column(edge.target_column, table=edge.target_table)))
        _require(join == expected, "An appended JOIN differs from the unique declared path")
        current_alias = edge.target_table
    for column in changed.find_all(exp.Column):
        _bind(column, sources)
    for index, join in enumerate(new_joins):
        for column in join.args["on"].find_all(exp.Column):
            _bind(column, sources[:index + 2])
    restored = changed.copy()
    restored.set("joins", [join.copy() for join in old_joins] if old_joins else None)
    before, after = list(original.find_all(exp.Column)), list(restored.find_all(exp.Column))
    _require(len(before) == len(after), "Existing column occurrences changed")
    for old, new in zip(before, after):
        if old.table.casefold() == alias.casefold() and old.name.casefold() == name.casefold():
            _require(new.name == old.name and new.this == old.this and new.table.casefold() == target_alias.casefold(),
                     "The original field spelling must be preserved; only its qualifier may change")
            new.set("table", old.args["table"].copy())
        else:
            _require(new == old, "An unrelated original column changed")
    _require(restored == original, "Other original AST clauses, literals or predicates changed")
    return changed.sql(dialect="sqlite")


def build_relocation_options(sql, schema, check_event) -> list[RelocationOption]:
    """Exact failed-check provenance + exact-name relocation; no SQL execution."""
    try:
        (tree, context, alias, name, target, target_alias, start_alias,
         path, edges, message) = _inspect(sql, schema, check_event)
        candidates = generate_column_relocation_candidates(sql, context)
        _require(len(candidates) == 1, "Expected one legacy relocation candidate")
        candidate = _guard(tree, candidates[0], _schema_tables(schema), alias, name, target_alias, start_alias, path)
        evidence = {"exact_parent_check_error": message, "reported_qualifier": alias, "unchanged_column": name,
                    "unique_exact_owner": target["name"], "target_alias": target_alias,
                    "appended_fk_edges": edges, "path_length": len(path),
                    "preserved_existing_join_count": len(tree.args.get("joins", [])),
                    "preserved_predicates_and_literals": True,
                    "legacy_generator": "submission.schema_grounding.generate_column_relocation_candidates"}
        preconditions = ("an exact check of the original SQL reports one qualified missing column",
                         "one physical INNER JOIN scope; only that column lacks a binding",
                         "the unchanged exact column name has one schema owner; no fuzzy substitution",
                         "a unique at-most-two-edge explicit FK path is complete and non-composite when needed",
                         "only reported field qualifiers and appended FK JOINs change; other AST nodes remain")
        assumptions = ("the original column name denotes the requested attribute despite its incorrect qualifier",
                       "the declared FK path is the intended relation and its INNER JOIN coverage is appropriate",
                       "all original filters remain, including potentially unsupported role or charge restrictions",
                       "row multiplicity, full semantics and official correctness are unverified; public match is not proof")
        return [RelocationOption("KEEP", sql, preconditions, evidence, assumptions),
                RelocationOption("RELOCATE_COLUMN", candidate, preconditions, evidence, assumptions)]
    except (UnsupportedJoin, SqlglotError, TypeError, KeyError, AttributeError, RecursionError):
        return []
