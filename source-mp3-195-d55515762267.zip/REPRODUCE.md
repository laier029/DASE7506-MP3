# Reproduce the offline SQL repair run

The export's `method.py` implements the course `create_agent(checkpoint=None)` interface. The official predictor creates fresh agent state for each question. One process holds the shared frozen model. The official Starter distribution supplies `mp3_sql` and its data.

## Prepare the environment

The reference run used Linux aarch64, Python 3.12.16, CPU PyTorch 2.7.1, Transformers 4.53.2, PEFT 0.17.1, Accelerate 1.10.1, safetensors 0.8.0, huggingface-hub 0.36.2 and sqlglot 27.29.0. Install the two included requirements files in a Linux environment with a CPU build of PyTorch. Prepare dependencies and local model files before disconnecting networking.

Provision `Qwen/Qwen3-0.6B` at revision `c1899de289a04d12100db370d81485cdf75e47ca`. An ordinary revision-pinned Hugging Face snapshot directory is supported. The loader checks the seven inference files against upstream digests packaged in `harness_lab/h33/base-metadata.json`. Extract the separate LoRA ZIP into its own directory. It contains `adapter_model.safetensors` and `adapter_config.json` at its root. The actual parameter counts are 596,049,920 shared base parameters and 1,146,880 LoRA parameters, for a total of 597,196,800. The CPU run loads float32 weights from safetensors with `local_files_only=True` and `trust_remote_code=False`.

When provisioning from the public Hugging Face repository, the following command downloads the pinned snapshot. Use the local path printed by the command as `MP3_BASE_MODEL`.

```sh
hf download Qwen/Qwen3-0.6B --revision c1899de289a04d12100db370d81485cdf75e47ca
```

## Run the official predictor and scorer

For the commands below, set `STARTER`, `EXPORT`, `MP3_BASE_MODEL` and `MP3_ADAPTER_DIR` to the four absolute local paths for the official Starter, this extracted source ZIP, the pinned base snapshot, and the extracted adapter. Set `RESULT_DIR` to a new, writable output directory. Run inside an offline Linux environment with four CPUs and a 16 GiB memory limit. Python's executable and dependencies must remain available after network access is disabled.

```sh
export STARTER=/path/to/official/starter
export EXPORT=/path/to/extracted/source
export MP3_BASE_MODEL=/path/to/pinned/Qwen3-0.6B
export MP3_ADAPTER_DIR=/path/to/extracted/adapter
export RESULT_DIR=/path/to/empty/results
export PYTHONPATH="$EXPORT:$STARTER"
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0
mkdir -p "$RESULT_DIR"
cd "$RESULT_DIR"
for split in validation test; do
  export MP3_RECEIPTS="$RESULT_DIR/$split-model-receipts"
  timeout 7200 python -m mp3_sql.predict --split "$split" --workers 1 \
    --method "$EXPORT/method.py" --output "$RESULT_DIR/$split.json"
  timeout 180 python -m mp3_sql.score --split "$split" --workers 4 \
    --predictions "$RESULT_DIR/$split.json" --output "$RESULT_DIR/$split-score.json"
done
```

The scorer replays every tool observation and checks all three instances. When comparing against the archived prediction or score files, compare task identities, traces, SQL and scoring outcomes. Timing fields and embedded digests of files containing timing fields can differ on a repeat run. The predictor limits inference to one worker. The scorer uses its official four-worker default and does not load the model. Baseline receipts describe provisional answers; the official predictions contain the final submissions. The archive preserves one inference receipt per task in `evidence/model-receipts.jsonl.gz` for the final TEST. Rerunning the above command produces human-readable individual JSON files. Inspect `training/provenance.json` and the accompanying logs for the model training record.
