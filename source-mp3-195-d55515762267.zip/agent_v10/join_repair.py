"""Propose one explicit FK edge for one self-equality INNER JOIN condition.

The declared FK is structural evidence, not proof of the intended relation.
In SQLite, x = x is UNKNOWN for NULL; replacing it is deliberately not an
equivalence-preserving optimization and may change that NULL restriction.
"""
from dataclasses import dataclass

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError


@dataclass(frozen=True)
class JoinOption:
    name: str
    sql: str
    preconditions: tuple[str, ...]
    evidence: dict
    assumptions: tuple[str, ...]


class UnsupportedJoin(ValueError):
    pass


def _require(condition, message):
    if not condition:
        raise UnsupportedJoin(message)


def _unparen(node):
    while isinstance(node, exp.Paren):
        node = node.this
    return node


def _schema_tables(schema):
    _require(isinstance(schema, list), "Expected the official table schema list")
    tables = {}
    for table in schema:
        _require(isinstance(table, dict) and isinstance(table.get("name"), str)
                 and table["name"] and isinstance(table.get("columns"), list)
                 and isinstance(table.get("foreign_keys"), list), "Incomplete table metadata")
        key = table["name"].casefold()
        _require(key not in tables, "Ambiguous table names")
        columns = table["columns"]
        _require(all(isinstance(column, dict) and isinstance(column.get("name"), str)
                     and column["name"] and type(column.get("pk")) is int
                     and column["pk"] >= 0 for column in columns), "Incomplete column metadata")
        _require(len({column["name"].casefold() for column in columns}) == len(columns),
                 "Ambiguous column names")
        keys = [column["pk"] for column in columns if column["pk"]]
        _require(len(keys) == len(set(keys)), "Ambiguous primary key positions")
        tables[key] = table
    return tables


def _source(node, tables):
    _require(isinstance(node, exp.Table) and isinstance(node.this, exp.Identifier)
             and not node.db and not node.catalog
             and not any(value for key, value in node.args.items()
                         if key not in ("this", "alias", "db", "catalog")), "Expected an ordinary physical table")
    alias = node.args.get("alias")
    _require(alias is None or not alias.args.get("columns"), "Renamed table-column lists are unsupported")
    table = tables.get(node.name.casefold())
    _require(table is not None, "Unknown physical table")
    return {"alias": node.alias_or_name, "table": table}


def _bind(node, sources):
    node = _unparen(node)
    _require(isinstance(node, exp.Column) and not node.is_star and not node.db and not node.catalog,
             "Expected a physical column")
    matches = [(source, column) for source in sources for column in source["table"]["columns"]
               if column["name"].casefold() == node.name.casefold()
               and (not node.table or node.table.casefold() == source["alias"].casefold())]
    _require(len(matches) == 1, "Unbound or ambiguous column")
    return matches[0]


def _binding_key(binding):
    source, column = binding
    return source["alias"].casefold(), column["name"].casefold()


def _inspect(sql, schema):
    _require(isinstance(sql, str) and sql.strip(), "Empty query")
    statements = sqlglot.parse(sql, read="sqlite")
    _require(len(statements) == 1 and isinstance(statements[0], exp.Select), "Expected exactly one SELECT")
    tree = statements[0]
    _require(len(list(tree.find_all(exp.Select))) == 1
             and not any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))
             and not any(tree.args.get(key) for key in ("qualify", "windows", "laterals", "operation_modifiers")),
             "Nested scopes or window queries are unsupported")
    tables = _schema_tables(schema)
    origin, joins = tree.args.get("from"), tree.args.get("joins", [])
    _require(isinstance(origin, exp.From) and origin.this is not None and not origin.expressions and joins,
             "A physical FROM and explicit JOIN are required")
    sources = [_source(origin.this, tables)]
    for join in joins:
        _require(not join.args.get("side") and str(join.args.get("kind", "")).upper() in ("", "INNER")
                 and not join.args.get("method") and not join.args.get("using") and join.args.get("on") is not None
                 and not any(value for key, value in join.args.items() if key not in ("this", "on", "kind", "side", "method", "using")),
                 "Only explicit ordinary INNER JOINs are supported")
        sources.append(_source(join.this, tables))
    _require(len({source["alias"].casefold() for source in sources}) == len(sources), "Duplicate aliases")
    _require(len({source["table"]["name"].casefold() for source in sources}) == len(sources),
             "Self joins need additional relation-role evidence")
    _require(not any(not isinstance(star.parent, exp.Count) for star in tree.find_all(exp.Star)),
             "Expanded star outputs are unsupported")
    for column in tree.find_all(exp.Column):
        _bind(column, sources)
    targets = []
    for index, join in enumerate(joins):
        visible = sources[:index + 2]
        for column in join.args["on"].find_all(exp.Column):
            _bind(column, visible)
        condition = _unparen(join.args["on"])
        if not isinstance(condition, exp.EQ):
            continue
        if not all(isinstance(_unparen(side), exp.Column) for side in (condition.this, condition.expression)):
            continue
        left, right = _bind(condition.this, visible), _bind(condition.expression, visible)
        if _binding_key(left) == _binding_key(right):
            targets.append((index, left))
    _require(len(targets) == 1, "Expected exactly one bare same-column equality JOIN")
    return tree, sources, targets[0]


def _unique_edge(prior, right):
    edges = []
    for left in prior:
        for source, target in ((left, right), (right, left)):
            for foreign_key in source["table"]["foreign_keys"]:
                _require(isinstance(foreign_key, dict) and isinstance(foreign_key.get("table"), str),
                         "Malformed foreign key metadata")
                if foreign_key["table"].casefold() == target["table"]["name"].casefold():
                    edges.append((source, target, foreign_key))
    # The official schema flattens foreign keys to table/from/to. Multiple
    # entries cannot safely be grouped into a composite constraint or treated
    # as independent semantic roles, so neither interpretation is guessed.
    _require(len(edges) == 1, "No unique complete explicit FK edge across this JOIN")
    source, target, foreign_key = edges[0]
    _require(all(isinstance(foreign_key.get(key), str) and foreign_key[key] for key in ("from", "to")),
             "Foreign key columns must be explicit")
    _require(foreign_key.get("seq", 0) == 0 and not any(foreign_key.get(key) for key in ("columns", "from_columns", "to_columns")),
             "Composite foreign key metadata is unsupported")
    source_column = next((column for column in source["table"]["columns"]
                          if column["name"].casefold() == foreign_key["from"].casefold()), None)
    primary_key = [column for column in target["table"]["columns"] if column["pk"]]
    _require(source_column is not None and len(primary_key) == 1 and primary_key[0]["pk"] == 1
             and primary_key[0]["name"].casefold() == foreign_key["to"].casefold(),
             "The full target must be one explicitly declared primary-key column")
    return source, source_column, target, primary_key[0]


def build_join_options(sql, schema) -> list[JoinOption]:
    """Return exact KEEP and one FK_JOIN hypothesis, or [] when unsupported.

No question text, examples, task IDs, execution or scoring are used. Multiple
ordinary JOINs are supported, but exactly one must have a bare x=x condition.
"""
    try:
        tree, sources, (index, old_binding) = _inspect(sql, schema)
        source, source_column, target, target_column = _unique_edge(sources[:index + 1], sources[index + 1])
        replacement = exp.EQ(this=exp.column(source_column["name"], table=source["alias"], quoted=True),
                             expression=exp.column(target_column["name"], table=target["alias"], quoted=True))
        old_condition = tree.args["joins"][index].args["on"].sql(dialect="sqlite")
        changed = tree.copy()
        changed.args["joins"][index].set("on", replacement)
        old_source, old_column = old_binding
        evidence = {"join_index": index, "old_on_sql": old_condition,
                    "replacement_on_sql": replacement.sql(dialect="sqlite"),
                    "prior_aliases": [item["alias"] for item in sources[:index + 1]],
                    "joined_alias": sources[index + 1]["alias"],
                    "same_binding": {"table": old_source["table"]["name"], "alias": old_source["alias"],
                                     "column": old_column["name"], "declared_not_null": bool(old_column.get("not_null")),
                                     "pk_position": old_column["pk"]},
                    "foreign_key": {"source_table": source["table"]["name"], "source_alias": source["alias"],
                                    "source_column": source_column["name"], "target_table": target["table"]["name"],
                                    "target_alias": target["alias"], "target_column": target_column["name"],
                                    "target_single_column_primary_key": True},
                    "null_semantics": "x = x evaluates to UNKNOWN for NULL, not unconditionally TRUE; replacing it can change NULL filtering."}
        preconditions = ("one physical SELECT scope with ordinary INNER JOINs and unambiguous column bindings",
                         "exactly one JOIN ON is a bare equality of the same bound column",
                         "exactly one explicit FK edge connects the new right table to prior aliases",
                         "that FK targets the complete single-column primary key; ambiguous or composite edges are rejected",
                         "only this JOIN ON AST is changed; all other clauses and JOINs are retained")
        assumptions = ("the declared FK is the intended relation for this JOIN, not an intentional uncorrelated pairing",
                       "removing the self-equality's NULL restriction is part of the proposed repair, not a proven equivalence",
                       "the existing INNER JOIN kind, other joins, filters, grouping, output grain and multiplicity remain appropriate",
                       "public check and full task correctness remain unverified; a matching example is not semantic proof")
        return [JoinOption("KEEP", sql, preconditions, evidence, assumptions),
                JoinOption("FK_JOIN", changed.sql(dialect="sqlite"), preconditions, evidence, assumptions)]
    except (UnsupportedJoin, SqlglotError, TypeError, KeyError, AttributeError, RecursionError):
        return []
