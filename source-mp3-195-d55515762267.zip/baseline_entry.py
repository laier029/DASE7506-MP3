"""Official entry point. Each episode has a fresh controller and shares only model weights."""
import hashlib
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from harness_lab.h60.agent import shared_model
from harness_lab.h67.routed_agent import RoutedAgent


class LoggedAgent(RoutedAgent):
    def act(self, obs):
        action = super().act(obs)
        if action['tool'] == 'submit':
            task_id = obs['task']['id']
            receipt = {'id': task_id, 'routed': self.routed,
                       'v16_sql': self.v16_sql, 'submitted_sql': action['sql'],
                       'tool_calls': len(obs['history']), 'generation': self.generation}
            folder = Path(os.environ.get('MP3_RECEIPTS', 'outputs/model-receipts'))
            folder.mkdir(parents=True, exist_ok=True)
            filename = hashlib.sha256(task_id.encode()).hexdigest() + '.json'
            (folder / filename).write_text(json.dumps(receipt, ensure_ascii=False), encoding='utf-8')
        return action


def create_agent(checkpoint=None):
    config = json.loads(Path(checkpoint).read_text()) if checkpoint else {}
    adapter = os.environ.get('MP3_ADAPTER_DIR') or config.get('adapter')
    if not adapter:
        raise ValueError('Set MP3_ADAPTER_DIR to the extracted two-file H65 adapter.')
    if checkpoint and not Path(adapter).is_absolute():
        adapter = Path(checkpoint).resolve().parent / adapter
    return LoggedAgent(shared_model(str(Path(adapter).resolve())))
