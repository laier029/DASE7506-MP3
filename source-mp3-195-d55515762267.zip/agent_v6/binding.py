"""Factual, single-column AST edits within one already grounded physical scope.

This module selects neither a semantic target nor a correct field. It exposes
bound occurrences and reproducible choices; the caller must justify and check
any change. Unsupported queries return no slots/options.
"""

from dataclasses import dataclass
import hashlib
import json

from sqlglot import exp

from agent_v3.evidence import grounding_issues
from agent_v5.aggregate import _numeric
from harness_lab.h05.editor import (
    UnsupportedEdit, _field_nodes, _physical_sources, _positional_clause,
    _select, apply_decision, build_task,
)


@dataclass(frozen=True)
class FieldBinding:
    table: str
    alias: str
    column: str
    data_type: str
    not_null: bool
    pk: int
    sql: str


@dataclass(frozen=True)
class BindingSlot:
    id: str
    clause: str
    target_sql: str
    expression_sql: str
    current_field: FieldBinding
    source_sql: str
    node_path: tuple[str, ...]


@dataclass(frozen=True)
class BindingOption:
    name: str
    sql: str
    description: str
    replacement_sql: str
    replacement_field: FieldBinding
    current_bool: bool
    preconditions: tuple[str, ...]
    type_hints: tuple[str, ...]
    local_expression_sql: str


def _identity(prefix, value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return prefix + hashlib.sha256(payload.encode()).hexdigest()


def _field(alias, table, column):
    return FieldBinding(table["name"], alias, column["name"], str(column.get("type") or ""),
                        bool(column.get("not_null", False)), int(column.get("pk", 0)),
                        exp.column(column["name"], table=alias, quoted=True).sql(dialect="sqlite"))


def _binding_key(field):
    return (field.table.casefold(), field.alias.casefold(), field.column.casefold())


def _bind(node, sources):
    if node.is_star or node.db or node.catalog:
        raise UnsupportedEdit("Only a single physical field can be bound")
    matches = [_field(alias, table, column) for alias, table in sources
               for column in table["columns"]
               if column["name"].casefold() == node.name.casefold()
               and (not node.table or alias.casefold() == node.table.casefold())]
    if len(matches) != 1:
        raise UnsupportedEdit("Unknown or ambiguous physical column")
    return matches[0]


def _inspect(sql, schema):
    tree = _select(sql)
    if (len(list(tree.find_all(exp.Select))) != 1
            or any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))
            or any(tree.args.get(key) for key in ("qualify", "windows", "laterals", "operation_modifiers"))
            or _positional_clause(tree)):
        raise UnsupportedEdit("Nested scopes, windows and positional clauses are unsupported")
    if not isinstance(schema, list):
        raise UnsupportedEdit("Expected the official physical schema list")
    for table in schema:
        if len({c["name"].casefold() for c in table["columns"]}) != len(table["columns"]):
            raise UnsupportedEdit("Ambiguous schema columns")
    if any(join.args.get("using") or str(join.args.get("method", "")).upper() == "NATURAL"
           for join in tree.args.get("joins", [])):
        raise UnsupportedEdit("USING and NATURAL joins have implicit column bindings")
    if any(not isinstance(star.parent, exp.Count) for star in tree.find_all(exp.Star)):
        raise UnsupportedEdit("Expanded or unbound star outputs are unsupported")
    sources = _physical_sources(tree, schema)
    aliases = {expression.alias.casefold() for expression in tree.expressions if expression.alias}
    select_nodes = {id(node) for expression in tree.expressions for node in expression.walk()}
    for column in tree.find_all(exp.Column):
        if not column.table and column.name.casefold() in aliases and id(column) not in select_nodes:
            raise UnsupportedEdit("SELECT-alias references or collisions are unsupported")
        _bind(column, sources)
    if grounding_issues(sql, schema):
        raise UnsupportedEdit("All names in the complete source must be grounded")
    return tree, sources


def _path(node, tree):
    parts = []
    while node is not tree:
        part = node.arg_key
        if node.index is not None:
            part += "[" + str(node.index) + "]"
        parts.append(part)
        node = node.parent
    return tuple(reversed(parts))


def _expression(node, tree):
    # Keep a complete SELECT expression, WHERE/HAVING condition or ORDER item.
    # This exposes the actual local context without inventing its interpretation.
    while node.parent is not tree and not isinstance(node.parent, (exp.Where, exp.Having, exp.Order)):
        node = node.parent
    return node.sql(dialect="sqlite")


def _slots(sql, tree, sources):
    normalized = tree.sql(dialect="sqlite")
    return [BindingSlot(_identity("SLOT_", [normalized, _path(node, tree)]), clause,
                        node.sql(dialect="sqlite"), _expression(node, tree),
                        _bind(node, sources), sql, _path(node, tree))
            for clause, node in _field_nodes(tree)]


def list_binding_slots(sql, schema) -> list[BindingSlot]:
    """Enumerate SELECT/WHERE/HAVING/ORDER occurrences, including aggregate args.

GROUP keys and JOIN conditions are deliberately not editable. Source fields must
already bind unambiguously; this first slice does not repair ungrounded syntax.
Slot IDs bind normalized source content and AST path, not enumeration position.
"""
    try:
        tree, sources = _inspect(sql, schema)
        return _slots(sql, tree, sources)
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return []


def _literal_hints(node, field):
    parent = node.parent
    comparisons = (exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE, exp.Like, exp.Is)
    if not isinstance(parent, comparisons):
        return ()
    other = parent.expression if parent.this is node else parent.this
    literal = other.this if isinstance(other, exp.Neg) else other
    if not isinstance(literal, (exp.Literal, exp.Null)):
        return ()
    kind = ("NULL" if isinstance(literal, exp.Null) else "text" if literal.is_string else "numeric")
    return (f"Comparison literal {other.sql(dialect='sqlite')} has {kind} syntax; "
            f"replacement field declares {field.data_type or 'unspecified type'}. "
            "This is context only: SQLite affinity/coercion and NULL semantics require execution.",)


def _numeric_argument(node):
    while node.parent is not None and not isinstance(node.parent, exp.Select):
        node = node.parent
        if isinstance(node, (exp.Sum, exp.Avg)):
            return True
    return False


def build_binding_options(sql, schema, slot_id) -> list[BindingOption]:
    """Offer exact KEEP plus fully grounded replacements in the current sources.

Replacement IDs depend on bound field content; schema/candidate order is not its
identity. A caller may separately assign short display IDs. No question text,
public example, scorer data or field-name heuristic is consulted.
"""
    try:
        tree, sources = _inspect(sql, schema)
        slots = _slots(sql, tree, sources)
        index = next((i for i, slot in enumerate(slots) if slot.id == slot_id), None)
        if index is None:
            return []
        slot = slots[index]
        node = _field_nodes(tree)[index][1]
        spec = build_task({"row": {"issue_sql": sql}, "schema": schema,
                           "operation": "field", "target_id": f"T{index + 1}"})
        candidate_ids = {candidate.sql: candidate.id for candidate in spec.candidates}
        preconditions = (
            "one grounded physical SELECT scope; no nested scopes, windows or alias references",
            "only the specified column occurrence changes; sources, JOINs and other AST nodes remain",
            "field meaning, row multiplicity and final correctness remain unverified",
        )
        options = [BindingOption("KEEP", sql, "Keep this exact query and field occurrence unchanged.",
                                 slot.target_sql, slot.current_field, True, preconditions,
                                 _literal_hints(node, slot.current_field), slot.expression_sql)]
        fields = sorted((_field(alias, table, column) for alias, table in sources
                         for column in table["columns"]), key=_binding_key)
        for field in fields:
            if _binding_key(field) == _binding_key(slot.current_field):
                continue
            if _numeric_argument(node) and not _numeric(field.data_type):
                continue
            edited = apply_decision(spec, candidate_ids[field.sql])
            if edited.status != "edited":
                continue
            # Validate the entire generated query, not only the replacement name.
            changed, _ = _inspect(edited.sql, schema)
            changed_node = _field_nodes(changed)[index][1]
            options.append(BindingOption(
                _identity("FIELD_", _binding_key(field)), edited.sql,
                f"Replace only {slot.target_sql} in {slot.clause.upper()} with {field.sql} "
                f"({field.table}.{field.column}, declared {field.data_type or 'unspecified type'}).",
                field.sql, field, False, preconditions, _literal_hints(node, field),
                _expression(changed_node, changed)))
        return options
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return []
