"""Bounded structural proposals and exact public-data probe descriptions.

These helpers never execute SQL, read a database, or accept a proposal as correct.
The controller must check every candidate with the official tool.
"""

import math

from sqlglot import exp

from agent_v2.submission import canonical, parse_query
from harness_lab.h05.editor import (
    UnsupportedEdit, _field_nodes, _physical_sources, list_field_targets,
)
from mp3_sql.common import result_fingerprint


def _simple_select(sql):
    tree = parse_query(sql)
    if (not isinstance(tree, exp.Select)
            or any(node is not tree for node in tree.find_all(exp.Select))
            or any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))
            or any(tree.args.get(key) for key in ("qualify", "windows", "laterals"))):
        raise ValueError("Only a single SELECT without nested scopes is supported")
    return tree


def _complete_result(value):
    if not isinstance(value, dict) or value.get("truncated") is not False:
        return None
    columns, rows = value.get("columns"), value.get("rows")
    if (not isinstance(columns, list) or not columns or not isinstance(rows, list)
            or type(value.get("row_count")) is not int or value["row_count"] != len(rows)):
        return None
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) != len(columns):
            return None
        for cell in row:
            if not (cell is None or isinstance(cell, (str, int, float))):
                return None
            if isinstance(cell, float) and not math.isfinite(cell):
                return None
    return {"ok": True, "columns": columns, "rows": rows}


def _distinct_candidate(tree, sql, check_event, example):
    if (tree.args.get("distinct") or tree.args.get("group") or tree.args.get("having")
            or next(tree.find_all(exp.AggFunc), None) is not None
            or not isinstance(check_event, dict)):
        return None
    if "sql" in check_event and canonical(check_event["sql"]) != canonical(sql):
        return None
    feedback = check_event.get("observation", check_event)
    if not isinstance(feedback, dict) or feedback.get("ok") is not True:
        return None
    actual, expected = _complete_result(feedback), _complete_result(example)
    if actual is None or expected is None:
        return None
    # Exact values determine duplicates. Fingerprint rounding must not collapse
    # two different SQLite REAL values into a fabricated duplicate.
    unique = list(dict.fromkeys(tuple(row) for row in actual["rows"]))
    if len(unique) == len(actual["rows"]):
        return None
    deduplicated = {**actual, "rows": unique}
    if result_fingerprint(deduplicated) != result_fingerprint(expected):
        return None
    candidate = tree.copy()
    candidate.set("distinct", exp.Distinct())
    return {"sql": candidate.sql(dialect="sqlite"), "kind": "distinct",
            "evidence": {"status": "public_result_hypothesis",
                         "complete_actual_rows": len(actual["rows"]),
                         "distinct_rows": len(unique),
                         "reason": "Removing exact duplicate rows matches the public example fingerprint",
                         "order_verified": False}}


def _aggregate(tree):
    if len(tree.expressions) != 1:
        return None
    projection = tree.expressions[0]
    aggregate = projection.this if isinstance(projection, exp.Alias) else projection
    if (not isinstance(aggregate, (exp.Sum, exp.Avg, exp.Min, exp.Max))
            or aggregate.args.get("expressions") or aggregate.this is None
            or isinstance(aggregate.this, (exp.Distinct, exp.Star))
            or len(list(tree.find_all(exp.AggFunc))) != 1):
        return None
    return aggregate


def _positive_limit(tree):
    limit = tree.args.get("limit")
    value = limit.expression if isinstance(limit, exp.Limit) else None
    return (isinstance(value, exp.Literal) and not value.is_string
            and value.this.isascii() and value.this.isdigit() and int(value.this) > 0)


def _fresh_name(tree, base):
    names = {node.name.casefold() for node in tree.find_all(exp.Identifier)}
    result, index = base, 1
    while result.casefold() in names:
        result, index = f"{base}_{index}", index + 1
    return result


def _topk_candidate(tree):
    aggregate = _aggregate(tree)
    if (aggregate is None or not tree.args.get("from") or not tree.args.get("order")
            or not _positive_limit(tree)
            or any(tree.args.get(key) for key in ("group", "having", "distinct", "offset"))):
        return None
    projection = tree.expressions[0]
    alias = projection.alias.casefold() if isinstance(projection, exp.Alias) else ""
    # Positional ordering, aggregate expressions, and aggregate output aliases
    # would acquire a different binding in the inner query. Do not guess it.
    for ordered in tree.args["order"].expressions:
        value = ordered.this
        while isinstance(value, (exp.Paren, exp.Neg)):
            value = value.this
        if (isinstance(value, exp.Literal)
                or next(ordered.find_all(exp.AggFunc), None) is not None
                or any(not column.table and column.name.casefold() == alias
                       for column in ordered.find_all(exp.Column))):
            return None
    value_name = _fresh_name(tree, "__v4_value")
    source_name = _fresh_name(tree, "__v4_topk")
    inner = tree.copy()
    inner.set("expressions", [exp.alias_(aggregate.this.copy(), value_name, quoted=True)])
    outer_aggregate = aggregate.copy()
    outer_aggregate.set("this", exp.column(value_name, table=source_name, quoted=True))
    outer_projection = outer_aggregate
    if isinstance(projection, exp.Alias):
        outer_projection = exp.Alias(this=outer_aggregate, alias=projection.args["alias"].copy())
    outer = exp.Select(expressions=[outer_projection]).from_(
        exp.Subquery(this=inner, alias=exp.TableAlias(this=exp.to_identifier(source_name, quoted=True))))
    return {"sql": outer.sql(dialect="sqlite"), "kind": "topk_before_aggregate",
            "evidence": {"status": "hypothesis",
                         "reason": "Apply the existing ORDER BY and positive LIMIT before the single aggregate",
                         "field_bindings_changed": False}}


def structural_candidates(sql, check_event, example):
    """Suggest only duplicate removal or a same-level top-k/aggregate rewrite.

The public example's column *count* and values may support duplicate removal;
its column labels never determine SQL semantics. Top-k is always a hypothesis.
"""
    try:
        tree = _simple_select(sql)
        candidates = [_distinct_candidate(tree, sql, check_event, example), _topk_candidate(tree)]
    except (ValueError, TypeError, KeyError, RecursionError):
        return []
    return [candidate for candidate in candidates if candidate is not None]


def _text_column(column):
    kind = str(column.get("type", "")).upper()
    return any(marker in kind for marker in ("CHAR", "CLOB", "TEXT"))


def literal_probe(sql, schema):
    """Describe exact literal counts in one bound physical table, never a sample.

The first supported WHERE equality provides one immutable h05 occurrence ID.
Each candidate count corresponds to a text column in that same table; the
current column is always included. Other conditions are deliberately absent:
counts only establish literal presence, not whether a field answers the task.
"""
    try:
        tree = _simple_select(sql)
        sources = _physical_sources(tree, schema)
        targets = list_field_targets(sql, schema)
        nodes = _field_nodes(tree)
        for target, (clause, node) in zip(targets, nodes):
            if clause != "where" or not isinstance(node.parent, exp.EQ):
                continue
            comparison = node.parent
            literal = comparison.expression if comparison.this is node else comparison.this
            if (not isinstance(literal, exp.Literal) or not literal.is_string
                    or not literal.this or len(literal.this) > 120):
                continue
            bound = [(alias, table) for alias, table in sources
                     if (alias.casefold() == node.table.casefold() if node.table else
                         any(column["name"].casefold() == node.name.casefold()
                             for column in table["columns"]))]
            if len(bound) != 1:
                continue
            alias, table = bound[0]
            current = [column for column in table["columns"]
                       if column["name"].casefold() == node.name.casefold() and _text_column(column)]
            if len(current) != 1:
                continue
            columns = current + [column for column in table["columns"]
                                 if _text_column(column)
                                 and column["name"].casefold() != node.name.casefold()]
            expressions, metadata = [], []
            for index, column in enumerate(columns[:8], 1):
                count_alias = f"__v4_count_{index}"
                match = exp.EQ(this=exp.column(column["name"], quoted=True), expression=literal.copy())
                count = exp.Count(this=exp.Case(ifs=[exp.If(this=match, true=exp.Literal.number(1))]))
                expressions.append(exp.alias_(count, count_alias, quoted=True))
                metadata.append({"target_id": target.id,
                                 "field": exp.column(column["name"], table=alias, quoted=True).sql(dialect="sqlite"),
                                 "column": column["name"], "table": table["name"],
                                 "count_alias": count_alias, "is_current": index == 1})
            query = exp.Select(expressions=expressions).from_(
                exp.Table(this=exp.to_identifier(table["name"], quoted=True)))
            return {"sql": query.sql(dialect="sqlite"), "source_sql": sql,
                    "target_id": target.id, "source_field": target.sql,
                    "current_count_alias": metadata[0]["count_alias"],
                    "literal": literal.this, "table": table["name"], "targets": metadata}
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError, UnsupportedEdit):
        return None
    return None


def _clause(tree, key):
    value = tree.args.get(key)
    return value.sql(dialect="sqlite", normalize=True) if value is not None else None


def _topk_shape(tree):
    if not isinstance(tree, exp.Select) or _aggregate(tree) is None:
        return False
    source = tree.args.get("from")
    inner = source.this if source is not None else None
    return (isinstance(inner, exp.Subquery) and isinstance(inner.this, exp.Select)
            and inner.this.args.get("order") is not None and _positive_limit(inner.this))


def retrieval_patterns(result):
    """Reduce retrieved issue/gold pairs to identifiers-free structural labels."""
    if isinstance(result, dict):
        result = result.get("items", result.get("observation", []))
    if not isinstance(result, list):
        return []
    patterns = set()
    for item in result:
        if not isinstance(item, dict):
            continue
        try:
            issue, gold = parse_query(item.get("issue_sql")), parse_query(item.get("gold_sql"))
            if not isinstance(issue, exp.Select) or not isinstance(gold, exp.Select):
                continue
            if (len(list(issue.find_all(exp.Select))) == 1 and not _topk_shape(issue)
                    and _topk_shape(gold)):
                patterns.add("aggregate-before-limit")
            # Other tags are only compared across single-scope queries. Never
            # transfer a foreign query, identifier, literal, or natural language.
            issue, gold = _simple_select(item["issue_sql"]), _simple_select(item["gold_sql"])
            if bool(issue.args.get("distinct")) != bool(gold.args.get("distinct")):
                patterns.add("distinct")
            if len(issue.expressions) != len(gold.expressions):
                patterns.add("projection_count")
            for key in ("where", "order", "limit"):
                if _clause(issue, key) != _clause(gold, key):
                    patterns.add(key)
        except (ValueError, TypeError, KeyError, RecursionError):
            continue
    return [pattern for pattern in ("distinct", "projection_count", "where", "order", "limit",
                                    "aggregate-before-limit") if pattern in patterns]
