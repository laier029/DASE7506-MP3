"""Program-scheduled local edits, real tool checks, and a protected incumbent."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_v2.submission import canonical, parse_query
from agent_v3.submission import DEFAULT_CONFIG as V3_CONFIG
from agent_v3.evidence import grounding_issues, sql_summary
from harness_lab.h04.runtime import LocalGenerator
from harness_lab.h05.editor import build_task, apply_decision, list_field_targets, UnsupportedEdit
from agent_v4.context import build_messages, parse_choice
from agent_v4.operators import literal_probe, retrieval_patterns, structural_candidates


DEFAULT_CONFIG = {**V3_CONFIG, "log_dir": "outputs/agent-v4-model-logs",
                  "max_model_calls": 6, "max_new_tokens": 128,
                  "enable_thinking": False, "do_sample": True,
                  "temperature": 0.6, "top_p": 0.95, "top_k": 20, "seed": 42}


def load_config(checkpoint=None):
    config = dict(DEFAULT_CONFIG)
    if checkpoint is not None:
        given = json.loads(Path(checkpoint).read_text(encoding="utf-8"))
        if not isinstance(given, dict) or set(given) - set(config):
            raise ValueError("Unknown or malformed v4 configuration")
        config.update(given)
    for key in ("use_model", "use_hints", "use_retrieval", "use_diagnostics"):
        if type(config[key]) is not bool:
            raise ValueError(f"{key} must be boolean")
    for key, maximum in (("max_model_calls", 6), ("max_new_tokens", 2048),
                         ("max_input_tokens", 30000), ("threads", 4)):
        if type(config[key]) is not int or not 1 <= config[key] <= maximum:
            raise ValueError(f"Invalid {key}")
    if config["enable_thinking"] is not False:
        raise ValueError("Round two uses non-thinking local choices")
    if not isinstance(config["log_dir"], str) or not config["log_dir"]:
        raise ValueError("A model audit directory is required")
    LocalGenerator(config)  # Validates identity/decoding without loading weights.
    return config


def evidence_rank(event, example):
    """Search priority only: public agreement is not a semantic proof."""
    result = event["observation"]
    if not result.get("ok"):
        return (1, 999, 999, 1, 999)
    arity_gap = abs(len(result.get("columns", [])) - len(example.get("columns", [])))
    row_gap = abs(result.get("row_count", 0) - example.get("row_count", 0))
    # Only compare complete public rows. Never infer absence from a preview.
    distance = 0
    incomplete = bool(result.get("truncated") or example.get("truncated"))
    if not incomplete:
        encode = lambda row: json.dumps(row, ensure_ascii=False, sort_keys=True)
        actual = Counter(map(encode, result.get("rows", [])))
        expected = Counter(map(encode, example.get("rows", [])))
        distance = sum((actual - expected).values()) + sum((expected - actual).values())
    return (0, arity_gap, row_gap, int(incomplete), distance)


class SqlRepairAgent:
    def __init__(self, config, generator=None):
        self.config = dict(config)
        self.generator = generator
        self.task_id = None
        self.model_calls = 0
        self.candidates = []
        self.attempted = set()
        self.unresolved = []
        self.probe_info = None

    def _log(self, record):
        directory = Path(self.config["log_dir"])
        directory.mkdir(parents=True, exist_ok=True)
        filename = hashlib.sha256(self.task_id.encode()).hexdigest()[:20] + ".jsonl"
        with (directory / filename).open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"task_id": self.task_id, **record},
                                    ensure_ascii=False, allow_nan=False) + "\n")

    def _action(self, tool, reason, **arguments):
        action = {"tool": tool, **arguments}
        self._log({"phase": "decision", "reason": reason, "action": action})
        return action

    def _add(self, sql, source, parent=None):
        key = canonical(sql)
        for candidate in self.candidates:
            if candidate["key"] == key:
                if source not in candidate["sources"]:
                    candidate["sources"].append(source)
                return candidate
        candidate = {"key": key, "sql": sql, "sources": [source],
                     "index": len(self.candidates), "parent": parent["key"] if parent else None,
                     "depth": parent["depth"] + 1 if parent else 0}
        self.candidates.append(candidate)
        return candidate

    def _sync(self, observation):
        self._add(observation["issue_sql"], "original")
        for event in observation["history"]:
            if event["tool"] == "repair_hint":
                for sql in event["observation"]:
                    self._add(sql, "hint")
        return {canonical(event["sql"]): event for event in observation["history"]
                if event["tool"] == "check"}

    @staticmethod
    def _source_rank(candidate):
        return (0 if "hint" in candidate["sources"] else
                1 if "original" in candidate["sources"] else 2, candidate["index"])

    def _finish(self, observation, checked, reason):
        available = [c for c in self.candidates if c["key"] in checked]
        matching = [c for c in available if checked[c["key"]]["observation"].get("matches_example") is True]
        if matching:
            # No model ID or prose can demote a checked match. Prefer the same
            # fixed hint ordering as the successful v3 tools-only baseline.
            chosen = min(matching, key=self._source_rank)
        elif available:
            chosen = min(available, key=lambda c: (evidence_rank(checked[c["key"]], observation["example"]),
                                                   self._source_rank(c)))
            self.unresolved.append("No candidate matched the public example within the search budget")
        else:
            raise ValueError("Cannot submit without an actual prior check")
        self._log({"phase": "finish", "reason": reason, "sources": chosen["sources"],
                   "matches_example": bool(matching), "unresolved": self.unresolved})
        return self._action("submit", reason, sql=checked[chosen["key"]]["sql"])

    def _can_model(self):
        return self.config["use_model"] and self.model_calls < self.config["max_model_calls"]

    def _frontier(self, checked, observation):
        # Keep parents as alternatives; newer equal-evidence local edits may be
        # explored, but final selection still uses the stable evidence order.
        candidates = [c for c in self.candidates if c["key"] in checked and c["depth"] < 3]
        return sorted(candidates, key=lambda c: (evidence_rank(checked[c["key"]], observation["example"]),
                                                 -c["depth"], self._source_rank(c)))

    def _prioritized_targets(self, candidate, schema, history):
        targets = list(list_field_targets(candidate["sql"], schema))
        priority = None
        if self.probe_info and self.probe_info["source_key"] == candidate["key"]:
            event = next((e for e in history if e["tool"] == "execute"
                          and e["sql"] == self.probe_info["sql"]), None)
            if event and event["observation"].get("ok") and event["observation"].get("rows"):
                result = event["observation"]
                counts = dict(zip(result["columns"], result["rows"][0]))
                current = counts.get(self.probe_info.get("current_count_alias"))
                if current == 0 and any(isinstance(value, (int, float)) and value > 0
                                        for name, value in counts.items() if name != "total_rows"):
                    priority = self.probe_info.get("target_id")
        return sorted(targets, key=lambda target: (target.id != priority,
                                                    {"select": 0, "where": 1, "having": 2, "order": 3}[target.clause]))

    def _next_spec(self, frontier, schema, observation):
        for candidate in frontier:
            summary = sql_summary(candidate["sql"])
            output_count = len(summary["outputs"])
            expected = len(observation["example"]["columns"])
            options = []
            if output_count > expected > 0 or output_count == expected >= 2:
                options.append(("projection", None))
            try:
                options.extend(("field", target.id) for target in
                               self._prioritized_targets(candidate, schema, observation["history"]))
            except UnsupportedEdit as error:
                self.unresolved.append(str(error))
            for operation, target in options:
                identity = (candidate["key"], operation, target)
                if identity in self.attempted:
                    continue
                self.attempted.add(identity)
                try:
                    spec = build_task({"row": {"issue_sql": observation["issue_sql"],
                                              "question": observation["task"]["question"],
                                              "ordered": observation["ordered"]},
                                       "schema": schema, "operation": operation,
                                       "working_sql": candidate["sql"], "target_id": target})
                except UnsupportedEdit as error:
                    self.unresolved.append(str(error))
                    continue
                return candidate, spec
        return None

    def _propose(self, candidate, spec, observation, schema, checked):
        self.model_calls += 1
        patterns = [pattern for event in observation["history"] if event["tool"] == "retrieve"
                    for pattern in retrieval_patterns(event["observation"])]
        probes = [event for event in observation["history"] if event["tool"] == "execute"]
        messages = build_messages(spec, observation["task"]["question"], schema,
                                  checked[candidate["key"]], observation["example"], probes, patterns)
        if self.generator is None:
            self.generator = LocalGenerator(self.config)
        record = {"phase": "generation", "kind": spec.operation, "call": self.model_calls,
                  "prompt": messages, "source_sql": spec.source_sql, "target_id": spec.target_id}
        try:
            result = self.generator.generate(messages, self.config["max_new_tokens"])
        except Exception as error:
            self._log({**record, "status": "runtime_error", "error": str(error)})
            raise
        record.update({key: value for key, value in result.items() if key != "text"})
        record["raw_output"] = result.get("text", "")
        record["config"] = {key: self.config[key] for key in
                            ("enable_thinking", "do_sample", "seed", "max_new_tokens")}
        record["config"].update({key: self.config[key] if self.config["do_sample"] else None
                                 for key in ("temperature", "top_p", "top_k")})
        reply = parse_choice(result, spec)
        if reply is None:
            self._log({**record, "status": "rejected", "reason": "invalid_or_incomplete_choice"})
            self.unresolved.append("A local choice was invalid or incomplete")
            return None
        edit = apply_decision(spec, reply)
        if edit.status != "edited":
            self._log({**record, "status": edit.status, "selection": reply})
            if edit.status == "unresolved":
                self.unresolved.append(f"Unresolved {spec.operation} at {spec.target_id}")
            return None
        issues = grounding_issues(edit.sql, schema)
        if spec.operation == "projection" and len(parse_query(edit.sql).expressions) != len(observation["example"]["columns"]):
            issues.append("Selected projection count differs from the observed output arity")
        if canonical(edit.sql) in checked:
            issues.append("This candidate was already checked")
        if issues:
            self._log({**record, "status": "rejected", "selection": reply, "reason": issues})
            self.unresolved.extend(issues)
            return None
        proposal = self._add(edit.sql, "model_" + spec.operation, candidate)
        self._log({**record, "status": "accepted", "selection": reply, "proposed_sql": edit.sql})
        return proposal

    def _structural(self, frontier, checked, observation, schema, *, allow_deferred=False):
        for parent in frontier:
            for proposal in structural_candidates(parent["sql"], checked[parent["key"]], observation["example"]):
                if proposal["kind"] != "distinct":
                    # Let a local field choice precede aggregate nesting; once
                    # nested, that deliberately small editor cannot bind it.
                    attempted_here = any(key == parent["key"] and operation == "field"
                                         for key, operation, _ in self.attempted)
                    if (not allow_deferred and self._can_model()
                            and not attempted_here and not parent["parent"]):
                        continue
                if canonical(proposal["sql"]) in checked or grounding_issues(proposal["sql"], schema):
                    continue
                candidate = self._add(proposal["sql"], "structure_" + proposal["kind"], parent)
                self._log({"phase": "proposal", "kind": proposal["kind"],
                           "evidence": proposal["evidence"], "sql": proposal["sql"],
                           "status": "unverified_hypothesis"})
                return candidate
        return None

    def act(self, observation):
        task_id = observation["task"]["id"]
        if self.task_id is None:
            self.task_id = task_id
        elif self.task_id != task_id:
            raise ValueError("Use a fresh agent for every task")
        checked = self._sync(observation)
        history, remaining = observation["history"], observation["remaining"]
        if remaining <= 0:
            return self._finish(observation, checked, "tool_budget_exhausted")
        schema_event = next((e for e in history if e["tool"] == "schema"), None)
        if schema_event is None:
            return self._action("schema", "read_structure_before_interpretation")
        schema = schema_event["observation"]
        if not any(e["tool"] == "check" and e["sql"] == observation["issue_sql"] for e in history):
            return self._action("check", "measure_exact_original", sql=observation["issue_sql"])
        if self.config["use_hints"] and not any(e["tool"] == "repair_hint" for e in history):
            return self._action("repair_hint", "collect_tool_proposals")
        hints = [c for c in self.candidates if "hint" in c["sources"]]
        matching_hints = [c for c in hints if c["key"] in checked
                          and checked[c["key"]]["observation"].get("matches_example") is True]
        if matching_hints:
            return self._finish(observation, checked, "preserve_checked_hint_match")
        for candidate in hints:
            if candidate["key"] in checked:
                continue
            outputs = sql_summary(candidate["sql"])["outputs"]
            arity_bad = (outputs and not any("*" == item or item.endswith(".*") for item in outputs)
                         and len(outputs) != len(observation["example"]["columns"]))
            if not arity_bad and not grounding_issues(candidate["sql"], schema):
                return self._action("check", "verify_hint_before_model_work", sql=candidate["sql"])
        if any(event["observation"].get("matches_example") is True for event in checked.values()):
            return self._finish(observation, checked, "protect_checked_incumbent")
        frontier = self._frontier(checked, observation)
        structural = self._structural(frontier, checked, observation, schema)
        if structural:
            return self._action("check", "verify_structural_hypothesis", sql=structural["sql"])
        if self._can_model():
            if (self.config["use_diagnostics"] and remaining >= 3
                    and not any(e["tool"] == "execute" for e in history)):
                for candidate in frontier:
                    feedback = checked[candidate["key"]]["observation"]
                    if feedback.get("ok") and feedback.get("row_count") == 0:
                        probe = literal_probe(candidate["sql"], schema)
                        if probe:
                            self.probe_info = {**probe, "source_key": candidate["key"]}
                            return self._action("execute", "measure_literal_binding_counts", sql=probe["sql"])
            if (self.config["use_retrieval"] and remaining >= 3 and self.model_calls == 0
                    and not any(e["tool"] == "retrieve" for e in history)):
                # The returned SQL is never a candidate. Only structural edit
                # labels are admitted to the subsequent local-choice context.
                query = observation["task"]["question"] + " " + observation["issue_sql"]
                return self._action("retrieve", "collect_structural_edit_patterns", query=query[:2000])
            while self._can_model():
                opportunity = self._next_spec(frontier, schema, observation)
                if opportunity is None:
                    break
                candidate, spec = opportunity
                proposal = self._propose(candidate, spec, observation, schema, checked)
                if proposal:
                    return self._action("check", "verify_local_model_edit", sql=proposal["sql"])
            # A no-op or exhausted model should not prevent a bounded program
            # proposal. These too consume a real check before any submission.
            structural = self._structural(frontier, checked, observation, schema, allow_deferred=True)
            if structural:
                return self._action("check", "verify_structural_hypothesis", sql=structural["sql"])
        return self._finish(observation, checked, "no_supported_untried_edit")


def create_agent(checkpoint=None):
    return SqlRepairAgent(load_config(checkpoint))
