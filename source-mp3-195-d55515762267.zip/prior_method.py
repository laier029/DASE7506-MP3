"""Official entry for the frozen semantic repair controller and one H65 adapter."""
import json
import sys
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from baseline_entry import create_agent as create_baseline
from harness_lab.intent_repair.reasoned import ReasonedAgent as Controller


@lru_cache(maxsize=1)
def parameters():
    folder = ROOT/'harness_lab/intent_repair'
    config = json.loads((folder/'rank.json').read_text())
    config['patterns'] = json.loads((folder/'patterns.json').read_text())
    return config


def create_agent(checkpoint=None):
    return Controller(create_baseline(checkpoint), parameters())
