"""Local SQL candidate validation, canonicalisation and ranking."""

from collections import defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
import re

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError, TokenError


MAX_SQL_BYTES = 16_000

NUMBER_WORDS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
}

QUANTITY_PATTERN = re.compile(
    r"\b(at\s+least|more\s+than|over|at\s+most|no\s+more\s+than|"
    r"less\s+than|fewer\s+than|exactly)\s+"
    r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b",
    re.IGNORECASE,
)

QUANTITY_OPERATORS = {
    "at least": ">=",
    "more than": ">",
    "over": ">",
    "at most": "<=",
    "no more than": "<=",
    "less than": "<",
    "fewer than": "<",
    "exactly": "=",
}


@dataclass(frozen=True)
class HintCandidate:
    sql: str
    canonical: str
    frequency: int
    similarity: float
    first_position: int


def _fallback_canonical(sql):
    return re.sub(r"\s+", " ", sql.strip()).casefold()


def parse_read_only_query(sql):
    """Return one SQLite query expression, or None for an invalid candidate."""
    if not isinstance(sql, str) or not sql.strip() or len(sql.encode("utf-8")) > MAX_SQL_BYTES:
        return None
    try:
        statements = sqlglot.parse(sql, read="sqlite")
    except (ParseError, TokenError, RecursionError):
        return None
    if len(statements) != 1 or not isinstance(statements[0], (exp.Select, exp.SetOperation)):
        return None
    if any(isinstance(node, (exp.Insert, exp.Update, exp.Delete, exp.Create, exp.Drop,
                             exp.Command, exp.Into)) for node in statements[0].walk()):
        return None
    return statements[0]


def canonical_sql(sql):
    """Create a deterministic key for semantic duplicate suppression."""
    expression = parse_read_only_query(sql)
    if expression is None:
        return _fallback_canonical(sql) if isinstance(sql, str) else ""
    try:
        return expression.sql(dialect="sqlite", pretty=False, normalize=True)
    except (TypeError, ValueError):
        return _fallback_canonical(sql)


def rank_hint_candidates(suggestions, issue_sql):
    """Deduplicate valid hints and rank consensus before edit similarity."""
    groups = defaultdict(list)
    for position, sql in enumerate(suggestions if isinstance(suggestions, list) else []):
        if parse_read_only_query(sql) is None:
            continue
        groups[canonical_sql(sql)].append((position, sql))

    ranked = []
    for canonical, occurrences in groups.items():
        first_position, representative = occurrences[0]
        similarity = SequenceMatcher(None, issue_sql, representative).ratio()
        ranked.append(HintCandidate(
            sql=representative,
            canonical=canonical,
            frequency=len(occurrences),
            similarity=similarity,
            first_position=first_position,
        ))
    return sorted(ranked, key=lambda item: (
        -item.frequency,
        -item.similarity,
        item.first_position,
        item.canonical,
    ))


def _plural_forms(word):
    word = word.casefold()
    irregular = {
        "person": {"person", "people"},
        "people": {"person", "people"},
        "child": {"child", "children"},
    }
    if word in irregular:
        return irregular[word]
    forms = {word}
    if word.endswith("ies") and len(word) > 3:
        forms.add(word[:-3] + "y")
    elif word.endswith("y") and len(word) > 1 and word[-2] not in "aeiou":
        forms.add(word[:-1] + "ies")
    elif word.endswith("s"):
        forms.add(word[:-1])
    else:
        forms.add(word + "s")
    return forms


def _quoted_identifier(value):
    return '"' + value.replace('"', '""') + '"'


def generate_schema_group_count_candidates(question, issue_sql, schema, ordered=False):
    """Generate a high-precision GROUP BY candidate when the counted entity is explicit."""
    if ordered or not isinstance(question, str):
        return []
    quantity = QUANTITY_PATTERN.search(question)
    if quantity is None:
        return []

    expression = parse_read_only_query(issue_sql)
    if not isinstance(expression, exp.Select) or len(expression.expressions) != 1:
        return []
    selected = expression.expressions[0]
    if isinstance(selected, exp.Alias):
        selected = selected.this
    if not isinstance(selected, exp.Column) or selected.name == "*":
        return []

    aliases = {}
    referenced_tables = []
    for table_expression in expression.find_all(exp.Table):
        table = schema.table(table_expression.name)
        if table is None:
            continue
        aliases[table_expression.alias_or_name.casefold()] = table.name
        aliases[table.name.casefold()] = table.name
        if table.name not in referenced_tables:
            referenced_tables.append(table.name)

    if selected.table:
        table_name = aliases.get(selected.table.casefold())
    else:
        possible = [name for name in referenced_tables if schema.has_column(name, selected.name)]
        table_name = possible[0] if len(possible) == 1 else None
    table = schema.table(table_name)
    if table is None or not schema.has_column(table.name, selected.name):
        return []
    if selected.name.casefold() in {_key.casefold() for _key in table.primary_keys}:
        return []

    tail = question[quantity.end():quantity.end() + 80].casefold()
    entity_word = re.split(r"[_\s]+", table.name.casefold())[-1]
    if not any(re.search(rf"\b{re.escape(form)}\b", tail)
               for form in _plural_forms(entity_word)):
        return []

    operator = QUANTITY_OPERATORS[re.sub(r"\s+", " ", quantity.group(1).casefold())]
    raw_number = quantity.group(2).casefold()
    number = int(raw_number) if raw_number.isdigit() else NUMBER_WORDS[raw_number]
    column_name = table.columns[selected.name.casefold()]
    quoted_column = _quoted_identifier(column_name)
    quoted_table = _quoted_identifier(table.name)
    return [
        f"SELECT {quoted_column} FROM {quoted_table} "
        f"GROUP BY {quoted_column} HAVING COUNT(*) {operator} {number}"
    ]

