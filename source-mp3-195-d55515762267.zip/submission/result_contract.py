"""Expected result shape derived from the public example columns."""

from dataclasses import dataclass
import re

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError, TokenError
from sqlglot.optimizer.scope import build_scope

from repair import canonical_sql, parse_read_only_query


AGGREGATE_TYPES = {
    exp.Avg: "AVG",
    exp.Count: "COUNT",
    exp.Max: "MAX",
    exp.Min: "MIN",
    exp.Sum: "SUM",
}


@dataclass(frozen=True)
class ProjectionSignature:
    kind: str
    name: str


@dataclass(frozen=True)
class ResultContract:
    columns: tuple

    @property
    def width(self):
        return len(self.columns)


@dataclass(frozen=True)
class ResultContractAudit:
    verdict: str
    expected: tuple
    observed: tuple

    @property
    def definitely_wrong(self):
        return self.verdict == "definite_error"


def _unwrap_alias(expression):
    return expression.this if isinstance(expression, exp.Alias) else expression


def projection_signature(expression):
    expression = _unwrap_alias(expression)
    for aggregate_type, name in AGGREGATE_TYPES.items():
        if isinstance(expression, aggregate_type):
            if aggregate_type is exp.Count:
                return ProjectionSignature("COUNT", "count")
            argument = expression.this
            if isinstance(argument, exp.Distinct):
                argument = argument.expressions[0] if argument.expressions else argument
            if isinstance(argument, exp.Column):
                value = argument.name.casefold()
            elif isinstance(argument, exp.Star):
                value = "*"
            else:
                value = argument.sql(dialect="sqlite", normalize=True).casefold()
            return ProjectionSignature(name, value)
    if isinstance(expression, exp.Column):
        return ProjectionSignature("COLUMN", expression.name.casefold())
    return ProjectionSignature(
        "EXPRESSION", expression.sql(dialect="sqlite", normalize=True).casefold())


def _signature_from_label(label):
    try:
        expression = sqlglot.parse_one(f"SELECT {label}", read="sqlite")
    except (ParseError, TokenError, RecursionError):
        return ProjectionSignature("LABEL", label.casefold())
    if not isinstance(expression, exp.Select) or len(expression.expressions) != 1:
        return ProjectionSignature("LABEL", label.casefold())
    return projection_signature(expression.expressions[0])


def build_result_contract(example):
    columns = example.get("columns") if isinstance(example, dict) else None
    if not isinstance(columns, list) or not columns or not all(
            isinstance(column, str) for column in columns):
        return None
    return ResultContract(tuple(_signature_from_label(column) for column in columns))


def audit_result_contract(sql, contract):
    expression = parse_read_only_query(sql)
    if contract is None or not isinstance(expression, exp.Select):
        return ResultContractAudit("unknown", contract.columns if contract else (), ())
    observed = tuple(projection_signature(item) for item in expression.expressions)
    verdict = "compatible" if observed == contract.columns else "definite_error"
    return ResultContractAudit(verdict, contract.columns, observed)


def _unique_source_column(expression, expected, schema):
    if expected.kind != "COLUMN":
        return None
    scope = build_scope(expression)
    if scope is None:
        return None
    matches = []
    for alias, source in scope.sources.items():
        if not isinstance(source, exp.Table):
            continue
        table = schema.table(source.name)
        if table is None or expected.name not in table.columns:
            continue
        matches.append(exp.column(table.columns[expected.name], table=alias))
    return matches[0] if len(matches) == 1 else None


def _singular(value):
    value = value.casefold()
    if value.endswith("ies") and len(value) > 3:
        return value[:-3] + "y"
    if value.endswith("s") and not value.endswith("ss") and len(value) > 2:
        return value[:-1]
    return value


def _preferred_qualifier(expression, column, schema):
    if not isinstance(column, exp.Column) or column.table:
        return None
    scope = build_scope(expression)
    if scope is None:
        return None
    matches = []
    for alias, source in scope.sources.items():
        if not isinstance(source, exp.Table):
            continue
        table = schema.table(source.name)
        if table is not None and schema.has_column(table.name, column.name):
            matches.append((alias, table.name))
    if len(matches) <= 1:
        return None
    column_prefix = re.split(r"[_\s]+", column.name.casefold())[0]
    preferred = [alias for alias, table_name in matches
                 if _singular(re.split(r"[_\s]+", table_name.casefold())[-1])
                 == _singular(column_prefix)]
    return preferred[0] if len(preferred) == 1 else None


def generate_result_contract_candidates(sql, contract, schema):
    expression = parse_read_only_query(sql)
    if contract is None or not isinstance(expression, exp.Select):
        return []

    selected = list(expression.expressions)
    signatures = [projection_signature(item) for item in selected]
    used = set()
    repaired_projection = []
    qualification_map = {}
    for expected in contract.columns:
        matched_index = next((index for index, signature in enumerate(signatures)
                              if index not in used and signature == expected), None)
        if matched_index is not None:
            used.add(matched_index)
            repaired_item = selected[matched_index].copy()
            raw_item = _unwrap_alias(repaired_item)
            qualifier = _preferred_qualifier(expression, raw_item, schema)
            if qualifier is not None:
                qualification_map[raw_item.name.casefold()] = qualifier
                raw_item.set("table", exp.to_identifier(qualifier))
            repaired_projection.append(repaired_item)
            continue
        source_column = _unique_source_column(expression, expected, schema)
        if source_column is None:
            return []
        repaired_projection.append(source_column)

    repaired = expression.copy()
    repaired.set("expressions", repaired_projection)
    removed_aliases = {
        item.alias.casefold(): item.this
        for index, item in enumerate(selected)
        if index not in used and isinstance(item, exp.Alias) and item.alias
    }
    for clause_name in ("group", "having", "order"):
        clause = repaired.args.get(clause_name)
        if clause is None:
            continue
        for column in list(clause.find_all(exp.Column)):
            if not column.table and column.name.casefold() in removed_aliases:
                column.replace(removed_aliases[column.name.casefold()].copy())
            elif not column.table and column.name.casefold() in qualification_map:
                column.set("table", exp.to_identifier(
                    qualification_map[column.name.casefold()]))
    repaired_sql = repaired.sql(dialect="sqlite")
    if canonical_sql(repaired_sql) == canonical_sql(sql):
        return []
    return [repaired_sql]
