"""Deterministic CPU-only SQL repair agent."""

import json
from pathlib import Path
import re
import sys

SUBMISSION_ROOT = str(Path(__file__).resolve().parent)
if SUBMISSION_ROOT not in sys.path:
    sys.path.insert(0, SUBMISSION_ROOT)

from aggregate_repair import generate_aggregate_candidates
from candidate_pool import build_candidate_pool
from diagnostics import (build_join_multiplicity_probe,
                         generate_join_dedup_candidate)
from evidence_diagnostics import (build_evidence_probe,
                                  generate_evidence_candidates)
from repair import canonical_sql, generate_schema_group_count_candidates
from retrieval_patterns import (generate_retrieved_pattern_candidates,
                                needs_pattern_retrieval,
                                pattern_retrieve_query)
from result_contract import (audit_result_contract, build_result_contract,
                             generate_result_contract_candidates)
from schema_context import build_schema_context, schema_references_are_valid
from schema_grounding import (generate_aggregate_measure_candidates,
                              generate_column_relocation_candidates,
                              generate_minimal_aggregate_source_candidates,
                              generate_related_inner_join_candidates,
                              generate_unique_join_path_candidates)
from semantic_repair import (generate_casefold_filter_candidates,
                             generate_identity_group_candidates,
                             generate_question_value_candidates,
                             generate_set_exclusion_candidates,
                             has_unrequested_select_distinct)
from semantic_context import (bind_intent_to_schema, build_semantic_contract,
                              extract_query_intent)
from semantic_hypotheses import (build_repair_hypotheses,
                                 build_temporal_source_hypotheses)


DEFAULT_CONFIG = {
    "use_hint": True,
    "submit_original_on_match": False,
    "max_hint_checks": 4,
    "use_schema": False,
    "max_schema_checks": 1,
    "use_semantic_audit": False,
    "use_retrieve": False,
    "use_execute_diagnostics": False,
    "use_result_contract": False,
    "max_result_contract_checks": 2,
    "use_relational_semantic_repairs": False,
    "max_relational_checks": 3,
    "use_schema_grounding_repairs": False,
    "max_schema_grounding_checks": 3,
    "use_evidence_diagnostics": False,
    "use_pattern_retrieval": False,
    "use_semantic_hypotheses": False,
    "use_semantic_scope_hypotheses": False,
    "use_temporal_endpoint_hypotheses": False,
}


def load_config(checkpoint):
    config = dict(DEFAULT_CONFIG)
    if checkpoint is not None:
        value = json.loads(Path(checkpoint).read_text(encoding="utf-8"))
        if not isinstance(value, dict) or set(value) - set(DEFAULT_CONFIG):
            raise ValueError("Unknown or malformed agent configuration")
        config.update(value)
    for key in ("use_hint", "submit_original_on_match", "use_schema",
                "use_semantic_audit", "use_retrieve", "use_execute_diagnostics",
                "use_result_contract", "use_relational_semantic_repairs",
                "use_schema_grounding_repairs", "use_evidence_diagnostics",
                "use_pattern_retrieval", "use_semantic_hypotheses",
                "use_semantic_scope_hypotheses",
                "use_temporal_endpoint_hypotheses"):
        if type(config[key]) is not bool:
            raise ValueError(f"{key} must be a boolean")
    if (type(config["max_hint_checks"]) is not int
            or not 0 <= config["max_hint_checks"] <= 4):
        raise ValueError("max_hint_checks must be an integer from 0 to 4")
    if (type(config["max_schema_checks"]) is not int
            or not 0 <= config["max_schema_checks"] <= 2):
        raise ValueError("max_schema_checks must be an integer from 0 to 2")
    if (type(config["max_result_contract_checks"]) is not int
            or not 0 <= config["max_result_contract_checks"] <= 4):
        raise ValueError("max_result_contract_checks must be an integer from 0 to 4")
    if (type(config["max_relational_checks"]) is not int
            or not 0 <= config["max_relational_checks"] <= 4):
        raise ValueError("max_relational_checks must be an integer from 0 to 4")
    if (type(config["max_schema_grounding_checks"]) is not int
            or not 0 <= config["max_schema_grounding_checks"] <= 4):
        raise ValueError("max_schema_grounding_checks must be an integer from 0 to 4")
    if config["use_semantic_audit"] and not config["use_schema"]:
        raise ValueError("use_semantic_audit requires use_schema")
    if ((config["use_retrieve"] or config["use_execute_diagnostics"])
            and not config["use_semantic_audit"]):
        raise ValueError("retrieve and execute diagnostics require semantic audit")
    if config["use_result_contract"] and not config["use_schema"]:
        raise ValueError("use_result_contract requires use_schema")
    if (config["use_relational_semantic_repairs"]
            and not config["use_semantic_audit"]):
        raise ValueError("relational semantic repairs require semantic audit")
    if (config["use_schema_grounding_repairs"]
            and not config["use_semantic_audit"]):
        raise ValueError("schema grounding repairs require semantic audit")
    if config["use_evidence_diagnostics"] and not config["use_schema"]:
        raise ValueError("evidence diagnostics require schema")
    if config["use_pattern_retrieval"] and not config["use_retrieve"]:
        raise ValueError("pattern retrieval requires retrieve")
    if config["use_semantic_hypotheses"] and not config["use_semantic_audit"]:
        raise ValueError("semantic hypotheses require semantic audit")
    if (config["use_semantic_scope_hypotheses"]
            and not config["use_semantic_hypotheses"]):
        raise ValueError("semantic scope hypotheses require semantic hypotheses")
    if (config["use_temporal_endpoint_hypotheses"]
            and not config["use_semantic_hypotheses"]):
        raise ValueError("temporal endpoint hypotheses require semantic hypotheses")
    return config


def _feedback(event):
    value = event.get("observation") if isinstance(event, dict) else None
    return value if isinstance(value, dict) else {}


def _find_event(history, tool):
    return next((event for event in history if event.get("tool") == tool), None)


def _find_original_feedback(history, issue_sql):
    return next((event for event in history
                 if event.get("tool") in ("check", "execute")
                 and event.get("sql") == issue_sql), None)


def _checked_sql(history):
    return {
        event["sql"]: _feedback(event)
        for event in history
        if event.get("tool") == "check" and isinstance(event.get("sql"), str)
    }


def _retrieved_records(event):
    observation = event.get("observation") if isinstance(event, dict) else None
    return observation if isinstance(observation, list) else []


def _retrieve_query(observation):
    query = f"{observation['task']['question']}\n{observation['issue_sql']}"
    return query[:2000]


def _matching_candidate(alternatives, checked):
    return next((candidate for candidate in alternatives
                 if checked.get(candidate.sql, {}).get("matches_example") is True), None)


def _unchecked_candidate(alternatives, checked):
    return next((candidate for candidate in alternatives
                 if candidate.sql not in checked), None)


def _diagnostic_target(pool, checked, bound_intent, schema):
    alternatives = [candidate for candidate in pool if candidate.source != "original"]
    original = next(candidate for candidate in pool if candidate.source == "original")
    for candidate in alternatives + [original]:
        if checked.get(candidate.sql, {}).get("ok") is not True:
            continue
        probe = build_join_multiplicity_probe(candidate.sql, bound_intent, schema)
        if probe is not None:
            return candidate.sql, probe
    return None, None


class SqlRepairAgent:
    def __init__(self, config):
        self.config = config

    def act(self, observation):
        issue_sql = observation["issue_sql"]
        history = observation["history"]
        remaining = observation["remaining"]
        intent = extract_query_intent(
            observation["task"]["question"], observation["ordered"])
        semantic_contract = build_semantic_contract(intent)
        result_contract = (build_result_contract(observation.get("example"))
                           if self.config["use_result_contract"] else None)

        schema_event = _find_event(history, "schema")
        if self.config["use_schema"] and schema_event is None:
            if remaining <= 0:
                return {"tool": "submit", "sql": issue_sql}
            return {"tool": "schema"}

        schema = build_schema_context(
            schema_event.get("observation") if schema_event is not None else [])
        bound_intent = bind_intent_to_schema(intent, schema)
        checked = _checked_sql(history)

        semantic_hypotheses = (build_repair_hypotheses(
            semantic_contract,
            issue_sql,
            schema,
            include_scope=self.config["use_semantic_scope_hypotheses"],
        )
            if self.config["use_semantic_hypotheses"] else [])

        generated_sqls = [hypothesis.sql for hypothesis in semantic_hypotheses]
        generated_sqls += generate_schema_group_count_candidates(
            observation["task"]["question"], issue_sql, schema, observation["ordered"])
        generated_sqls += generate_aggregate_candidates(bound_intent, issue_sql, schema)
        generated_sqls = generated_sqls[:self.config["max_schema_checks"]]

        hint_event = _find_event(history, "repair_hint")
        hint_suggestions = (
            hint_event.get("observation") if hint_event is not None else [])
        retrieve_event = _find_event(history, "retrieve")
        retrieved_records = _retrieved_records(retrieve_event)

        if self.config["use_temporal_endpoint_hypotheses"]:
            temporal_hypotheses = build_temporal_source_hypotheses(
                semantic_contract,
                hint_suggestions if isinstance(hint_suggestions, list) else [],
                schema,
            )
            semantic_hypotheses += temporal_hypotheses
            generated_sqls = [hypothesis.sql for hypothesis in temporal_hypotheses] + generated_sqls

        pattern_retrieval_needed = (
            self.config["use_pattern_retrieval"]
            and retrieve_event is None
            and isinstance(hint_suggestions, list)
            and needs_pattern_retrieval(
                observation["task"]["question"], hint_suggestions)
        )
        if self.config["use_pattern_retrieval"]:
            retrieved_pattern_candidates = generate_retrieved_pattern_candidates(
                observation["task"]["question"],
                hint_suggestions if isinstance(hint_suggestions, list) else [],
                retrieved_records,
                schema,
            )
            generated_sqls = retrieved_pattern_candidates + generated_sqls

        if result_contract is not None:
            result_sources = [issue_sql] + list(generated_sqls)
            if isinstance(hint_suggestions, list):
                result_sources.extend(hint_suggestions)
            result_sources.extend(
                record.get("gold_sql") for record in retrieved_records
                if isinstance(record, dict) and isinstance(record.get("gold_sql"), str))
            seen_contract_repairs = {canonical_sql(sql) for sql in generated_sqls}
            contract_repairs = []
            for source_sql in result_sources:
                for repaired_sql in generate_result_contract_candidates(
                        source_sql, result_contract, schema):
                    key = canonical_sql(repaired_sql)
                    if key and key not in seen_contract_repairs:
                        seen_contract_repairs.add(key)
                        contract_repairs.append(repaired_sql)
            generated_sqls += contract_repairs[:self.config["max_result_contract_checks"]]

        if self.config["use_schema_grounding_repairs"]:
            grounding_sources = [issue_sql] + list(generated_sqls)
            if isinstance(hint_suggestions, list):
                grounding_sources.extend(hint_suggestions)
            grounding_sources.extend(
                record.get("gold_sql") for record in retrieved_records
                if isinstance(record, dict) and isinstance(record.get("gold_sql"), str))
            seen_grounding = {canonical_sql(issue_sql)}
            seen_grounding.update(canonical_sql(sql) for sql in generated_sqls)
            grounding_repairs = []
            for source_sql in grounding_sources:
                candidates = []
                has_frequency = re.search(
                    r"\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten)"
                    r"\s+times?\b",
                    observation["task"]["question"],
                    re.IGNORECASE,
                )
                if bound_intent.intent.quantity is None and has_frequency is None:
                    candidates += generate_column_relocation_candidates(
                        source_sql, schema)
                candidates += generate_unique_join_path_candidates(source_sql, schema)
                candidates += generate_minimal_aggregate_source_candidates(
                    observation["task"]["question"], source_sql, schema)
                candidates += generate_related_inner_join_candidates(
                    observation["task"]["question"], source_sql)
                candidates += generate_aggregate_measure_candidates(
                    observation["task"]["question"], source_sql, schema)
                for repaired_sql in candidates:
                    key = canonical_sql(repaired_sql)
                    if (key and key not in seen_grounding
                            and schema_references_are_valid(repaired_sql, schema)):
                        seen_grounding.add(key)
                        grounding_repairs.append(repaired_sql)
            generated_sqls = (
                grounding_repairs[:self.config["max_schema_grounding_checks"]]
                + generated_sqls
            )

        if self.config["use_relational_semantic_repairs"]:
            relational_sources = [issue_sql] + list(generated_sqls)
            if isinstance(hint_suggestions, list):
                relational_sources.extend(hint_suggestions)
            relational_sources.extend(
                record.get("gold_sql") for record in retrieved_records
                if isinstance(record, dict) and isinstance(record.get("gold_sql"), str))
            seen_repairs = {canonical_sql(issue_sql)}
            seen_repairs.update(canonical_sql(sql) for sql in generated_sqls)
            relational_repairs = []
            for source_sql in relational_sources:
                candidates = []
                candidates += generate_set_exclusion_candidates(
                    observation["task"]["question"], source_sql, schema)
                candidates += generate_identity_group_candidates(
                    observation["task"]["question"], source_sql, schema)
                for repaired_sql in candidates:
                    key = canonical_sql(repaired_sql)
                    if (key and key not in seen_repairs
                            and schema_references_are_valid(repaired_sql, schema)):
                        seen_repairs.add(key)
                        relational_repairs.append(repaired_sql)
            generated_sqls = (
                relational_repairs[:self.config["max_relational_checks"]]
                + generated_sqls
            )

        pool = build_candidate_pool(
            issue_sql,
            generated_sqls,
            hint_suggestions,
            retrieved_records,
            bound_intent,
            schema,
            self.config["max_hint_checks"],
            self.config["use_semantic_audit"],
        )

        if self.config["use_relational_semantic_repairs"]:
            seen_feedback_repairs = {canonical_sql(sql) for sql in generated_sqls}
            feedback_repairs = []
            for candidate in list(pool[1:]) + list(pool[:1]):
                feedback = checked.get(candidate.sql)
                feedback_candidates = generate_question_value_candidates(
                    observation["task"]["question"], candidate.sql, feedback,
                    observation.get("example"))
                feedback_candidates += generate_casefold_filter_candidates(
                    observation["task"]["question"], candidate.sql, feedback,
                    observation.get("example"))
                for repaired_sql in feedback_candidates:
                    key = canonical_sql(repaired_sql)
                    if (key and key not in seen_feedback_repairs
                            and schema_references_are_valid(repaired_sql, schema)):
                        seen_feedback_repairs.add(key)
                        feedback_repairs.append(repaired_sql)
            if feedback_repairs:
                generated_sqls += feedback_repairs[:2]
                pool = build_candidate_pool(
                    issue_sql,
                    generated_sqls,
                    hint_suggestions,
                    retrieved_records,
                    bound_intent,
                    schema,
                    self.config["max_hint_checks"],
                    self.config["use_semantic_audit"],
                )

        hypothesis_needs_evidence = any(
            hypothesis.missing_evidence for hypothesis in semantic_hypotheses)
        evidence_probe = (build_evidence_probe(
            observation["task"]["question"], pool, schema)
            if (self.config["use_evidence_diagnostics"]
                and (not semantic_hypotheses or hypothesis_needs_evidence)) else None)
        evidence_event = next((event for event in history
                               if event.get("tool") == "execute"
                               and evidence_probe is not None
                               and event.get("sql") == evidence_probe.sql), None)
        if evidence_event is not None:
            evidence_candidates = generate_evidence_candidates(
                evidence_probe,
                _feedback(evidence_event),
                observation["task"]["question"],
                schema,
            )
            if evidence_candidates:
                generated_sqls = evidence_candidates + generated_sqls
                pool = build_candidate_pool(
                    issue_sql,
                    generated_sqls,
                    hint_suggestions,
                    retrieved_records,
                    bound_intent,
                    schema,
                    self.config["max_hint_checks"],
                    self.config["use_semantic_audit"],
                )

        diagnostic_base, diagnostic_sql = _diagnostic_target(
            pool, checked, bound_intent, schema)
        any_execute_event = _find_event(history, "execute")
        diagnostic_event = next((event for event in history
                                 if event.get("tool") == "execute"
                                 and event.get("sql") == diagnostic_sql), None)
        if diagnostic_event is not None and diagnostic_base is not None:
            generated_sqls += generate_join_dedup_candidate(
                diagnostic_base, bound_intent, schema, _feedback(diagnostic_event))
            pool = build_candidate_pool(
                issue_sql,
                generated_sqls,
                hint_suggestions,
                retrieved_records,
                bound_intent,
                schema,
                self.config["max_hint_checks"],
                self.config["use_semantic_audit"],
            )

        original = pool[0]
        alternatives = list(pool[1:])
        if result_contract is not None:
            alternatives = [candidate for candidate in alternatives
                            if not audit_result_contract(
                                candidate.sql, result_contract).definitely_wrong]
        original_contract_wrong = bool(
            result_contract is not None
            and audit_result_contract(issue_sql, result_contract).definitely_wrong)
        original_is_definitely_wrong = (
            (self.config["use_semantic_audit"] and original.audit.definitely_wrong)
            or original_contract_wrong)

        if original_is_definitely_wrong:
            generated = [candidate for candidate in alternatives
                         if candidate.source == "generated"]
            matching = _matching_candidate(generated, checked)
            if matching is not None:
                return {"tool": "submit", "sql": matching.sql}
            unchecked = _unchecked_candidate(generated, checked)
            if unchecked is not None and remaining > 0:
                return {"tool": "check", "sql": unchecked.sql}

        original_event = _find_original_feedback(history, issue_sql)
        if original_event is None:
            if remaining <= 0:
                return {"tool": "submit", "sql": issue_sql}
            return {"tool": "check", "sql": issue_sql}
        original_feedback = _feedback(original_event)

        if (self.config["use_relational_semantic_repairs"]
                and original_feedback.get("matches_example") is True):
            alternatives = [
                candidate for candidate in alternatives
                if not has_unrequested_select_distinct(
                    observation["task"]["question"], candidate.sql)
            ]

        if (not original_is_definitely_wrong
                and self.config["submit_original_on_match"]
                and original_feedback.get("matches_example") is True):
            return {"tool": "submit", "sql": issue_sql}

        if not self.config["use_hint"] or self.config["max_hint_checks"] == 0:
            return self._final_action(
                issue_sql, original, alternatives, original_feedback, checked,
                original_is_definitely_wrong)

        if hint_event is None:
            if remaining <= 0:
                return self._final_action(
                    issue_sql, original, alternatives, original_feedback, checked,
                    original_is_definitely_wrong)
            return {"tool": "repair_hint"}

        if (evidence_probe is not None
                and evidence_event is None
                and remaining >= 2):
            return {"tool": "execute", "sql": evidence_probe.sql}

        if pattern_retrieval_needed and remaining >= 2:
            return {
                "tool": "retrieve",
                "query": pattern_retrieve_query(observation["task"]["question"]),
            }

        strong_keys = {
            canonical_sql(hypothesis.sql) for hypothesis in semantic_hypotheses
            if hypothesis.confidence == "strong"
        }
        strong_candidates = [candidate for candidate in alternatives
                             if candidate.canonical in strong_keys]
        strong_matching = _matching_candidate(strong_candidates, checked)
        if strong_matching is not None:
            return {"tool": "submit", "sql": strong_matching.sql}
        strong_unchecked = _unchecked_candidate(strong_candidates, checked)
        if strong_unchecked is not None and remaining > 0:
            return {"tool": "check", "sql": strong_unchecked.sql}

        matching = _matching_candidate(alternatives, checked)
        if matching is not None:
            return {"tool": "submit", "sql": matching.sql}

        unchecked = _unchecked_candidate(alternatives, checked)
        if unchecked is not None and remaining > 0:
            return {"tool": "check", "sql": unchecked.sql}

        if (self.config["use_execute_diagnostics"]
                and diagnostic_sql is not None
                and any_execute_event is None
                and remaining >= 2):
            return {"tool": "execute", "sql": diagnostic_sql}

        if (self.config["use_retrieve"]
                and retrieve_event is None
                and any_execute_event is None
                and remaining >= 2
                and original.audit.verdict in ("unknown", "suspicious")
                and original_feedback.get("matches_example") is not True):
            return {"tool": "retrieve", "query": _retrieve_query(observation)}

        return self._final_action(
            issue_sql, original, alternatives, original_feedback, checked,
            original_is_definitely_wrong)

    @staticmethod
    def _final_action(issue_sql, original, alternatives, original_feedback, checked,
                      original_is_definitely_wrong):
        if (not original_is_definitely_wrong
                and original_feedback.get("matches_example") is True):
            return {"tool": "submit", "sql": issue_sql}
        for candidate in alternatives:
            if checked.get(candidate.sql, {}).get("ok") is True:
                return {"tool": "submit", "sql": candidate.sql}
        if (not original_is_definitely_wrong
                and original_feedback.get("ok") is True):
            return {"tool": "submit", "sql": issue_sql}
        if alternatives:
            return {"tool": "submit", "sql": alternatives[0].sql}
        return {"tool": "submit", "sql": issue_sql}


def create_agent(checkpoint=None):
    return SqlRepairAgent(load_config(checkpoint))
