"""Schema-grounded column, join-path and aggregate-source repairs."""

from collections import deque
from dataclasses import dataclass
import re

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from repair import canonical_sql, parse_read_only_query


@dataclass(frozen=True)
class PathEdge:
    source_table: str
    source_column: str
    target_table: str
    target_column: str


def _identifier_tokens(value):
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", value)
    tokens = re.findall(r"[a-z0-9]+", value.casefold())
    return tuple(token[:-1] if token.endswith("s") and len(token) > 3 else token
                 for token in tokens)


def _edges(schema):
    adjacency = {table.name.casefold(): [] for table in schema.tables.values()}
    for child in schema.tables.values():
        for child_column, parent_name, parent_column in child.foreign_keys:
            parent = schema.table(parent_name)
            if parent is None:
                continue
            adjacency[child.name.casefold()].append(PathEdge(
                child.name, child_column, parent.name, parent_column))
            adjacency[parent.name.casefold()].append(PathEdge(
                parent.name, parent_column, child.name, child_column))
    return adjacency


def _shortest_paths(schema, start_table, end_table, max_edges=2):
    start = schema.table(start_table)
    end = schema.table(end_table)
    if start is None or end is None:
        return []
    if start.name.casefold() == end.name.casefold():
        return [[]]
    adjacency = _edges(schema)
    queue = deque([(start.name, [], {start.name.casefold()})])
    paths = []
    best_length = None
    while queue:
        table_name, path, visited = queue.popleft()
        if best_length is not None and len(path) >= best_length:
            continue
        if len(path) >= max_edges:
            continue
        for edge in adjacency.get(table_name.casefold(), ()):
            target_key = edge.target_table.casefold()
            if target_key in visited:
                continue
            next_path = path + [edge]
            if target_key == end.name.casefold():
                best_length = len(next_path)
                paths.append(next_path)
            else:
                queue.append((edge.target_table, next_path, visited | {target_key}))
    return [path for path in paths if len(path) == best_length]


def _direct_sources(expression, schema):
    scope = build_scope(expression)
    if scope is None:
        return {}
    sources = {}
    for alias, source in scope.sources.items():
        if isinstance(source, exp.Table):
            table = schema.table(source.name)
            if table is not None:
                sources[alias.casefold()] = (alias, table)
    return sources


def _unique_column_target(column_name, schema):
    exact_tables = schema.tables_for_column(column_name)
    if len(exact_tables) == 1:
        table = schema.table(exact_tables[0])
        return table, table.columns[column_name.casefold()]

    wanted = set(_identifier_tokens(column_name))
    matches = []
    for table in schema.tables.values():
        table_tokens = set(_identifier_tokens(table.name))
        for candidate in table.columns.values():
            column_tokens = set(_identifier_tokens(candidate))
            if (wanted
                    and wanted <= table_tokens | column_tokens
                    and wanted & column_tokens):
                matches.append((table, candidate))
    return matches[0] if len(matches) == 1 else (None, None)


def _path_from_sources(schema, sources, target_table, max_edges=2):
    possibilities = []
    for alias, table in sources.values():
        for path in _shortest_paths(schema, table.name, target_table.name, max_edges):
            possibilities.append((len(path), alias, path))
    if not possibilities:
        return None, None
    shortest = min(length for length, _, _ in possibilities)
    best = [(alias, path) for length, alias, path in possibilities
            if length == shortest]
    return best[0] if len(best) == 1 else (None, None)


def _append_path_joins(expression, start_alias, path, final_alias=None):
    current_alias = start_alias
    joins = list(expression.args.get("joins") or ())
    for index, edge in enumerate(path):
        is_final = index == len(path) - 1
        target_alias = final_alias if is_final and final_alias else edge.target_table
        table_expression = exp.to_table(edge.target_table)
        if target_alias.casefold() != edge.target_table.casefold():
            table_expression.set(
                "alias", exp.TableAlias(this=exp.to_identifier(target_alias)))
        joins.append(exp.Join(
            this=table_expression,
            on=exp.EQ(
                this=exp.column(edge.source_column, table=current_alias),
                expression=exp.column(edge.target_column, table=target_alias),
            ),
        ))
        current_alias = target_alias
    expression.set("joins", joins)
    return current_alias


def generate_column_relocation_candidates(sql, schema):
    """Move invalid or missing-table columns to one uniquely grounded table."""
    expression = parse_read_only_query(sql)
    if (not isinstance(expression, exp.Select)
            or any(expression.find_all(exp.Subquery))):
        return []
    sources = _direct_sources(expression, schema)
    if not sources:
        return []
    table_aliases = {table.name.casefold(): alias for alias, table in sources.values()}
    select_aliases = {
        alias.alias.casefold() for alias in expression.expressions
        if isinstance(alias, exp.Alias) and alias.alias
    }
    repairs = {}
    target_tables = {}
    columns = list(expression.find_all(exp.Column))
    for index, column in enumerate(columns):
        if not column.table and column.name.casefold() in select_aliases:
            continue
        current = sources.get(column.table.casefold()) if column.table else None
        if current is not None and schema.has_column(current[1].name, column.name):
            continue
        if not column.table:
            present = [table for _, table in sources.values()
                       if schema.has_column(table.name, column.name)]
            if present:
                continue
        referenced_table = schema.table(column.table) if column.table else None
        if (referenced_table is not None
                and schema.has_column(referenced_table.name, column.name)):
            target_table = referenced_table
            target_column = referenced_table.columns[column.name.casefold()]
        else:
            target_table, target_column = _unique_column_target(column.name, schema)
        if target_table is None:
            continue
        repairs[index] = (target_table, target_column)
        target_tables[target_table.name.casefold()] = target_table
    if not repairs:
        return []

    repaired = expression.copy()
    repaired_columns = list(repaired.find_all(exp.Column))
    aliases_for_targets = {}
    for target_key, target_table in target_tables.items():
        existing_alias = table_aliases.get(target_key)
        if existing_alias is not None:
            aliases_for_targets[target_key] = existing_alias
            continue
        start_alias, path = _path_from_sources(schema, sources, target_table)
        if start_alias is None or not path:
            return []
        aliases_for_targets[target_key] = _append_path_joins(
            repaired, start_alias, path)
    for index, (target_table, target_column) in repairs.items():
        repaired_columns[index].replace(exp.column(
            target_column,
            table=aliases_for_targets[target_table.name.casefold()],
        ))
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def generate_unique_join_path_candidates(sql, schema):
    """Replace one unsupported direct join with a unique two-edge FK path."""
    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select):
        return []
    joins = expression.args.get("joins") or ()
    from_clause = expression.args.get("from")
    root_source = from_clause.this if isinstance(from_clause, exp.From) else None
    if len(joins) != 1 or not isinstance(root_source, exp.Table):
        return []
    target_source = joins[0].this
    if not isinstance(target_source, exp.Table):
        return []
    root_table = schema.table(root_source.name)
    target_table = schema.table(target_source.name)
    if root_table is None or target_table is None:
        return []
    paths = _shortest_paths(schema, root_table.name, target_table.name, max_edges=2)
    if len(paths) != 1 or len(paths[0]) != 2:
        return []

    repaired = expression.copy()
    repaired.set("joins", [])
    _append_path_joins(
        repaired,
        root_source.alias_or_name,
        paths[0],
        final_alias=target_source.alias_or_name,
    )
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def _aggregate_column(aggregate):
    argument = aggregate.this
    if isinstance(argument, exp.Distinct):
        argument = argument.expressions[0] if argument.expressions else None
    while isinstance(argument, (exp.Cast, exp.Paren)):
        argument = argument.this
    return argument if isinstance(argument, exp.Column) else None


def generate_minimal_aggregate_source_candidates(question, sql, schema):
    """Remove a non-contributing join that can only distort one aggregate."""
    expression = parse_read_only_query(sql)
    if (not isinstance(expression, exp.Select)
            or len(expression.expressions) != 1
            or expression.args.get("group") is not None
            or expression.args.get("having") is not None
            or not expression.args.get("joins")):
        return []
    selected = expression.expressions[0]
    selected = selected.this if isinstance(selected, exp.Alias) else selected
    if not isinstance(selected, (exp.Sum, exp.Count)):
        return []
    column = _aggregate_column(selected)
    if column is None or not column.table:
        return []
    sources = _direct_sources(expression, schema)
    target = sources.get(column.table.casefold())
    from_clause = expression.args.get("from")
    root_source = from_clause.this if isinstance(from_clause, exp.From) else None
    if (target is None or not isinstance(root_source, exp.Table)
            or root_source.alias_or_name.casefold() != target[0].casefold()):
        return []
    where = expression.args.get("where")
    if where is not None and any(
            predicate_column.table
            and predicate_column.table.casefold() != target[0].casefold()
            for predicate_column in where.find_all(exp.Column)):
        return []

    if isinstance(selected, exp.Sum):
        safe_to_remove = True
    else:
        safe_to_remove = isinstance(selected.this, exp.Distinct)
        root_table = target[1]
        for join in expression.args.get("joins") or ():
            joined = join.this if isinstance(join.this, exp.Table) else None
            joined_table = schema.table(joined.name) if joined is not None else None
            if joined_table is None:
                safe_to_remove = False
                break
            if _shortest_paths(schema, root_table.name, joined_table.name, 1):
                safe_to_remove = False
                break
    if not safe_to_remove:
        return []

    repaired = expression.copy()
    repaired.set("joins", [])
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def generate_related_inner_join_candidates(question, sql):
    """Require an existing relation when a counted right entity is 'related'."""
    if (not isinstance(question, str)
            or not re.search(r"\brelated\s+to\s+each\b", question, re.IGNORECASE)):
        return []
    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select):
        return []
    joins = expression.args.get("joins") or ()
    if len(joins) != 1 or str(joins[0].args.get("side") or "").casefold() != "left":
        return []
    joined = joins[0].this
    if not isinstance(joined, exp.Table):
        return []
    joined_alias = joined.alias_or_name.casefold()
    counts = list(expression.find_all(exp.Count))
    if len(counts) != 1:
        return []
    counted_column = _aggregate_column(counts[0])
    if (counted_column is None or not counted_column.table
            or counted_column.table.casefold() != joined_alias):
        return []

    repaired = expression.copy()
    repaired.args["joins"][0].set("side", None)
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def generate_aggregate_measure_candidates(question, sql, schema):
    """Prefer the same-table aggregate measure named explicitly in the question."""
    if not isinstance(question, str):
        return []
    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select):
        return []
    sources = _direct_sources(expression, schema)
    question_tokens = set(_identifier_tokens(question))
    replacements = []
    aggregate_types = (exp.Avg, exp.Sum, exp.Min, exp.Max)
    for aggregate in expression.find_all(*aggregate_types):
        column = _aggregate_column(aggregate)
        if column is None:
            continue
        source = sources.get(column.table.casefold()) if column.table else None
        if source is None:
            possible = [value for value in sources.values()
                        if schema.has_column(value[1].name, column.name)]
            source = possible[0] if len(possible) == 1 else None
        if source is None or not schema.has_column(source[1].name, column.name):
            continue
        current_tokens = set(_identifier_tokens(column.name))
        current_score = len(current_tokens & question_tokens)
        choices = []
        for candidate in source[1].columns.values():
            candidate_tokens = set(_identifier_tokens(candidate))
            if not current_tokens & candidate_tokens:
                continue
            score = len(candidate_tokens & question_tokens)
            if score > current_score:
                choices.append((score, candidate))
        if not choices:
            continue
        best_score = max(score for score, _ in choices)
        best = [candidate for score, candidate in choices if score == best_score]
        if len(best) == 1:
            replacements.append((column, source[0], best[0]))
    if not replacements:
        return []
    replacement_specs = {
        (target_alias.casefold(), target_column.name.casefold(),
         replacement_name.casefold())
        for target_column, target_alias, replacement_name in replacements
    }
    if len(replacement_specs) != 1:
        return []

    repaired = expression.copy()
    original_columns = list(expression.find_all(exp.Column))
    repaired_columns = list(repaired.find_all(exp.Column))
    for target_column, target_alias, replacement_name in replacements:
        target_index = next((index for index, value in enumerate(original_columns)
                             if value is target_column), None)
        if target_index is None:
            return []
        repaired_columns[target_index].replace(
            exp.column(replacement_name, table=target_alias))
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]
