"""Schema and question-intent audit for SQL candidates."""

from dataclasses import dataclass

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from repair import parse_read_only_query


COMPARISONS = {
    exp.EQ: "=",
    exp.GT: ">",
    exp.GTE: ">=",
    exp.LT: "<",
    exp.LTE: "<=",
}

REVERSED_COMPARISONS = {
    "=": "=",
    ">": "<",
    ">=": "<=",
    "<": ">",
    "<=": ">=",
}

AGGREGATE_EXPRESSIONS = {
    "AVG": exp.Avg,
    "COUNT": exp.Count,
    "MAX": exp.Max,
    "MIN": exp.Min,
    "SUM": exp.Sum,
}

STRUCTURAL_FINDING_CODES = {"INVALID_QUERY", "UNKNOWN_COLUMN", "UNKNOWN_TABLE"}


@dataclass(frozen=True)
class AuditFinding:
    code: str
    severity: str
    expected: str
    observed: str


@dataclass(frozen=True)
class SqlAuditReport:
    verdict: str
    findings: tuple

    @property
    def definitely_wrong(self):
        return self.verdict == "definite_error"

    @property
    def structurally_invalid(self):
        return any(finding.code in STRUCTURAL_FINDING_CODES for finding in self.findings)


def _schema_findings(expression, schema):
    findings = []
    cte_names = {cte.alias_or_name.casefold() for cte in expression.find_all(exp.CTE)}
    select_aliases = {
        alias.alias.casefold() for alias in expression.find_all(exp.Alias)
        if alias.alias
    }
    aliases = {}
    for table_expression in expression.find_all(exp.Table):
        table_name = table_expression.name
        if table_name.casefold() in cte_names:
            continue
        table = schema.table(table_name)
        if table is None:
            findings.append(AuditFinding(
                "UNKNOWN_TABLE", "definite", "a table in the schema", table_name))
            continue
        aliases[table_expression.alias_or_name.casefold()] = table.name
        aliases[table.name.casefold()] = table.name

    has_cte = bool(cte_names)
    for column in expression.find_all(exp.Column):
        if column.table:
            table_name = aliases.get(column.table.casefold())
            if table_name is not None and not schema.has_column(table_name, column.name):
                findings.append(AuditFinding(
                    "UNKNOWN_COLUMN", "definite",
                    f"a column of {table_name}", column.name))
        elif (column.name.casefold() not in select_aliases
              and not has_cte
              and not schema.tables_for_column(column.name)):
            findings.append(AuditFinding(
                "UNKNOWN_COLUMN", "definite", "a column in the schema", column.name))
    return findings


def _direct_source_tables(select, schema):
    scope = build_scope(select)
    if scope is None:
        return {}
    sources = {}
    for alias, source in scope.sources.items():
        if isinstance(source, exp.Table):
            table = schema.table(source.name)
            if table is not None:
                sources[alias.casefold()] = table.name
                sources[table.name.casefold()] = table.name
    return sources


def _counted_table(count, schema):
    select = count.find_ancestor(exp.Select)
    if select is None:
        return None
    sources = _direct_source_tables(select, schema)
    argument = count.this
    if isinstance(argument, exp.Distinct):
        return None
    if isinstance(argument, exp.Column) and argument.table:
        return sources.get(argument.table.casefold())
    unique_sources = set(sources.values())
    if len(unique_sources) == 1:
        return next(iter(unique_sources))
    return None


def _count_comparison(count):
    node = count.parent
    while node is not None and not isinstance(node, exp.Having):
        operator = COMPARISONS.get(type(node))
        if operator is not None:
            if node.this is count and isinstance(node.expression, exp.Literal):
                raw_value = node.expression.this
                if str(raw_value).isdigit():
                    return operator, int(raw_value)
            if node.expression is count and isinstance(node.this, exp.Literal):
                raw_value = node.this.this
                if str(raw_value).isdigit():
                    return REVERSED_COMPARISONS[operator], int(raw_value)
        node = node.parent
    return None


def _semantic_findings(expression, bound_intent, schema):
    quantity = bound_intent.intent.quantity
    if quantity is None:
        return []

    findings = []
    counts = list(expression.find_all(exp.Count))
    observed_tables = {
        table_name for table_name in (_counted_table(count, schema) for count in counts)
        if table_name is not None
    }
    if (bound_intent.counted_table is not None and observed_tables
            and bound_intent.counted_table.casefold()
            not in {name.casefold() for name in observed_tables}):
        findings.append(AuditFinding(
            "COUNTED_ENTITY_MISMATCH",
            "definite",
            bound_intent.counted_table,
            ", ".join(sorted(observed_tables)),
        ))

    comparisons = [value for value in (_count_comparison(count) for count in counts)
                   if value is not None]
    expected_comparison = (quantity.operator, quantity.threshold)
    if comparisons and expected_comparison not in comparisons:
        findings.append(AuditFinding(
            "QUANTITY_CONSTRAINT_MISMATCH",
            "definite",
            f"{quantity.operator} {quantity.threshold}",
            ", ".join(f"{operator} {threshold}"
                      for operator, threshold in comparisons),
        ))

    if len(bound_intent.projection_columns) == 1 and counts:
        expected_table, expected_column = bound_intent.projection_columns[0]
        groups = [group_expression for group in expression.find_all(exp.Group)
                  for group_expression in group.expressions]
        group_columns = [column for group_expression in groups
                         for column in group_expression.find_all(exp.Column)]
        if (groups and not any(column.name.casefold() == expected_column.casefold()
                               for column in group_columns)):
            findings.append(AuditFinding(
                "GROUPING_TARGET_MISMATCH",
                "warning",
                f"{expected_table}.{expected_column}",
                ", ".join(group.sql(dialect="sqlite") for group in groups),
            ))
    return findings


def _top_one_direction(expression):
    if not isinstance(expression, exp.Select):
        return None
    limit = expression.args.get("limit")
    limit_value = limit.args.get("expression") if isinstance(limit, exp.Limit) else None
    order = expression.args.get("order")
    if (not isinstance(limit_value, exp.Literal) or str(limit_value.this) != "1"
            or not isinstance(order, exp.Order) or not order.expressions):
        return None
    ordered = order.expressions[0]
    if not isinstance(ordered, exp.Ordered):
        return None
    return "max" if ordered.args.get("desc") is True else "min"


def _aggregate_findings(expression, bound_intent):
    aggregate = bound_intent.intent.aggregate
    required = set(aggregate.required_functions)
    if bound_intent.aggregate_counted_table is not None:
        required.add("COUNT")

    present = {
        name for name, expression_type in AGGREGATE_EXPRESSIONS.items()
        if any(expression.find_all(expression_type))
    }
    top_one = _top_one_direction(expression)
    findings = []
    for function_name in sorted(required):
        alternative_top_one = (
            function_name == "MAX" and top_one == "max"
            or function_name == "MIN" and top_one == "min")
        if function_name not in present and not alternative_top_one:
            findings.append(AuditFinding(
                "MISSING_AGGREGATE",
                "definite",
                function_name,
                ", ".join(sorted(present)) if present else "no aggregate",
            ))

    if (aggregate.superlative is not None
            and top_one != aggregate.superlative
            and not ({"max": "MAX", "min": "MIN"}[aggregate.superlative] in present)):
        findings.append(AuditFinding(
            "MISSING_SUPERLATIVE_SELECTION",
            "definite",
            f"top-1 {aggregate.superlative}",
            top_one or "no top-1 selection",
        ))
    return findings


def audit_sql(sql, bound_intent, schema):
    expression = parse_read_only_query(sql)
    if expression is None:
        finding = AuditFinding("INVALID_QUERY", "definite", "one read-only query", "invalid SQL")
        return SqlAuditReport("definite_error", (finding,))

    findings = _schema_findings(expression, schema)
    findings.extend(_semantic_findings(expression, bound_intent, schema))
    findings.extend(_aggregate_findings(expression, bound_intent))
    if any(finding.severity == "definite" for finding in findings):
        verdict = "definite_error"
    elif findings:
        verdict = "suspicious"
    elif (bound_intent.counted_table is not None
          or bound_intent.aggregate_counted_table is not None
          or bound_intent.intent.aggregate.required_functions
          or bound_intent.intent.aggregate.superlative is not None
          or bound_intent.projection_columns
          or bound_intent.intent.ordered):
        verdict = "compatible"
    else:
        verdict = "unknown"
    return SqlAuditReport(verdict, tuple(findings))
