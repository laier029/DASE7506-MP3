"""High-confidence repairs for relational filtering and grouping semantics."""

import re

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from repair import canonical_sql, parse_read_only_query


DISTINCT_WORDS = re.compile(r"\b(?:distinct|different|unique)\b", re.IGNORECASE)
SET_EXCLUSION_INTENT = re.compile(
    r"\bnever\b|\bnot\s+(?:living|residing)\b", re.IGNORECASE)
MOST_COMMON_INTENT = re.compile(r"\b(?:most|least)\s+common\b", re.IGNORECASE)


def question_requests_distinct(question):
    return bool(isinstance(question, str) and DISTINCT_WORDS.search(question))


def has_unrequested_select_distinct(question, sql):
    expression = parse_read_only_query(sql)
    return bool(
        isinstance(expression, exp.Select)
        and expression.args.get("distinct") is not None
        and not question_requests_distinct(question)
    )


def _root_table_and_alias(expression, schema):
    from_clause = expression.args.get("from")
    source = from_clause.this if isinstance(from_clause, exp.From) else None
    if not isinstance(source, exp.Table):
        return None, None, None
    table = schema.table(source.name)
    if table is None:
        return None, None, None
    return source, table, source.alias_or_name


def _projection_belongs_to_root(expression, root_table, root_alias):
    if not expression.expressions:
        return False
    for selected in expression.expressions:
        selected = selected.this if isinstance(selected, exp.Alias) else selected
        if not isinstance(selected, exp.Column):
            return False
        if selected.table:
            if selected.table.casefold() not in {
                    root_alias.casefold(), root_table.name.casefold()}:
                return False
        elif selected.name.casefold() not in root_table.columns:
            return False
    return True


def _positive_exclusion_predicate(condition, allow_positive):
    if isinstance(condition, exp.NEQ):
        return exp.EQ(this=condition.this.copy(), expression=condition.expression.copy())
    if isinstance(condition, exp.Not) and isinstance(
            condition.this, (exp.In, exp.Like, exp.ILike)):
        return condition.this.copy()
    if allow_positive and isinstance(condition, (exp.EQ, exp.In, exp.Like, exp.ILike)):
        return condition.copy()
    return None


def generate_set_exclusion_candidates(question, sql, schema):
    """Rewrite row-level negation as universe EXCEPT excluded entities."""
    if not isinstance(question, str) or not SET_EXCLUSION_INTENT.search(question):
        return []
    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select):
        return []
    root_source, root_table, root_alias = _root_table_and_alias(expression, schema)
    if root_source is None or not _projection_belongs_to_root(
            expression, root_table, root_alias):
        return []
    where = expression.args.get("where")
    if not isinstance(where, exp.Where):
        return []
    allow_positive = bool(re.search(r"\bnever\b", question, re.IGNORECASE))
    positive = _positive_exclusion_predicate(where.this, allow_positive)
    if positive is None:
        return []

    universe = exp.select(*(item.copy() for item in expression.expressions)).from_(
        root_source.copy())
    universe.set("distinct", None)
    excluded = expression.copy()
    excluded.set("distinct", None)
    excluded.set("order", None)
    excluded.set("limit", None)
    excluded.args["where"].set("this", positive)
    repaired = exp.Except(this=universe, expression=excluded, distinct=True)
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def _source_aliases(expression, schema):
    scope = build_scope(expression)
    if scope is None:
        return {}
    aliases = {}
    for alias, source in scope.sources.items():
        if isinstance(source, exp.Table):
            table = schema.table(source.name)
            if table is not None:
                aliases[alias.casefold()] = table
                aliases[table.name.casefold()] = table
    return aliases


def generate_identity_group_candidates(question, sql, schema):
    """Group a most-common entity by its primary key instead of its label."""
    if not isinstance(question, str) or not MOST_COMMON_INTENT.search(question):
        return []
    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select) or len(expression.expressions) != 1:
        return []
    selected = expression.expressions[0]
    selected = selected.this if isinstance(selected, exp.Alias) else selected
    group = expression.args.get("group")
    order = expression.args.get("order")
    limit = expression.args.get("limit")
    limit_value = limit.args.get("expression") if isinstance(limit, exp.Limit) else None
    if (not isinstance(selected, exp.Column)
            or not selected.table
            or not isinstance(group, exp.Group)
            or len(group.expressions) != 1
            or not isinstance(order, exp.Order)
            or not any(order.find_all(exp.Count))
            or not isinstance(limit_value, exp.Literal)
            or str(limit_value.this) != "1"):
        return []
    grouped = group.expressions[0]
    if (not isinstance(grouped, exp.Column)
            or grouped.name.casefold() != selected.name.casefold()
            or grouped.table.casefold() != selected.table.casefold()):
        return []

    aliases = _source_aliases(expression, schema)
    table = aliases.get(selected.table.casefold())
    if (table is None or len(table.primary_keys) != 1
            or selected.name.casefold() == table.primary_keys[0].casefold()):
        return []
    primary_key = table.primary_keys[0]
    joins_on_key = False
    for join in expression.args.get("joins") or ():
        on_expression = join.args.get("on")
        if on_expression is None:
            continue
        if any(
                column.table
                and column.table.casefold() == selected.table.casefold()
                and column.name.casefold() == primary_key.casefold()
                for column in on_expression.find_all(exp.Column)):
            joins_on_key = True
            break
    if not joins_on_key:
        return []

    repaired = expression.copy()
    repaired.args["group"].set(
        "expressions", [exp.column(primary_key, table=selected.table)])
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def _text_equalities(expression):
    equalities = []
    for where in expression.find_all(exp.Where):
        for equality in where.find_all(exp.EQ):
            pairs = ((equality.this, equality.expression),
                     (equality.expression, equality.this))
            pair = next(((column, literal) for column, literal in pairs
                         if isinstance(column, exp.Column)
                         and isinstance(literal, exp.Literal)
                         and literal.is_string), None)
            if pair is not None:
                equalities.append((equality, *pair))
    return equalities


def generate_question_value_candidates(question, sql, feedback, example):
    """Repair one literal when the question exposes its stored text format."""
    if (not isinstance(question, str)
            or not isinstance(feedback, dict)
            or feedback.get("ok") is not True
            or feedback.get("matches_example") is True
            or not isinstance(example, dict)
            or not isinstance(example.get("row_count"), int)
            or example["row_count"] <= 0):
        return []
    expression = parse_read_only_query(sql)
    if not isinstance(expression, (exp.Select, exp.SetOperation)):
        return []
    equalities = _text_equalities(expression)
    if len(equalities) != 1:
        return []
    _, column, literal = equalities[0]
    literal_text = str(literal.this)
    column_key = column.name.casefold()

    replacement = None
    if column_key == "team" and not literal_text.casefold().startswith("team "):
        match = re.search(
            rf"\bteam\s+{re.escape(literal_text)}\b", question, re.IGNORECASE)
        if match is not None:
            replacement = exp.EQ(
                this=column.copy(), expression=exp.Literal.string(match.group(0)))
    elif ("duration" in column_key and literal.is_string
          and literal_text.isdigit()
          and re.search(rf"\b{re.escape(literal_text)}\s+minutes?\b",
                        question, re.IGNORECASE)):
        replacement = exp.Like(
            this=column.copy(), expression=exp.Literal.string(f"{literal_text}:%"))
    if replacement is None:
        return []

    repaired = expression.copy()
    repaired_equalities = _text_equalities(repaired)
    if len(repaired_equalities) != 1:
        return []
    repaired_equalities[0][0].replace(replacement)
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]


def generate_casefold_filter_candidates(question, sql, feedback, example):
    """Retry one mismatching textual equality case-insensitively."""
    if (not isinstance(feedback, dict)
            or feedback.get("ok") is not True
            or feedback.get("matches_example") is True
            or not isinstance(example, dict)
            or not isinstance(example.get("row_count"), int)
            or example["row_count"] <= 0):
        return []
    expression = parse_read_only_query(sql)
    if not isinstance(expression, (exp.Select, exp.SetOperation)):
        return []
    equalities = _text_equalities(expression)
    if len(equalities) != 1:
        return []
    equality, column, literal = equalities[0]
    literal_text = str(literal.this)
    if (len(literal_text) < 2 or not isinstance(question, str)
            or literal_text.casefold() not in question.casefold()):
        return []

    repaired = expression.copy()
    repaired_equalities = _text_equalities(repaired)
    if len(repaired_equalities) != 1:
        return []
    repaired_equality, repaired_column, repaired_literal = repaired_equalities[0]
    repaired_equality.replace(exp.EQ(
        this=exp.Lower(this=repaired_column.copy()),
        expression=exp.Lower(this=repaired_literal.copy()),
    ))
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(sql) else [repaired_sql]
