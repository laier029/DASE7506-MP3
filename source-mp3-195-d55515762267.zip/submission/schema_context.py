"""Compact, read-only representation of the schema tool observation."""

from dataclasses import dataclass

from sqlglot import exp

from repair import parse_read_only_query


def _key(value):
    return value.casefold()


@dataclass(frozen=True)
class TableContext:
    name: str
    columns: dict
    primary_keys: tuple
    foreign_keys: tuple


class SchemaContext:
    def __init__(self, tables):
        self.tables = {_key(table.name): table for table in tables}
        self.column_to_tables = {}
        for table in tables:
            for column in table.columns.values():
                self.column_to_tables.setdefault(_key(column), []).append(table.name)

    def table(self, name):
        return self.tables.get(_key(name)) if isinstance(name, str) else None

    def has_column(self, table_name, column_name):
        table = self.table(table_name)
        return bool(table and _key(column_name) in table.columns)

    def tables_for_column(self, column_name):
        if not isinstance(column_name, str):
            return ()
        return tuple(self.column_to_tables.get(_key(column_name), ()))


def build_schema_context(observation):
    if not isinstance(observation, list):
        return SchemaContext([])
    tables = []
    for raw_table in observation:
        if not isinstance(raw_table, dict) or not isinstance(raw_table.get("name"), str):
            continue
        columns = {}
        primary_keys = []
        for raw_column in raw_table.get("columns", []):
            if not isinstance(raw_column, dict) or not isinstance(raw_column.get("name"), str):
                continue
            name = raw_column["name"]
            columns[_key(name)] = name
            if raw_column.get("pk"):
                primary_keys.append(name)
        foreign_keys = []
        for foreign_key in raw_table.get("foreign_keys", []):
            if isinstance(foreign_key, dict) and all(
                    isinstance(foreign_key.get(field), str)
                    for field in ("table", "from", "to")):
                foreign_keys.append((foreign_key["from"], foreign_key["table"],
                                     foreign_key["to"]))
        tables.append(TableContext(
            name=raw_table["name"],
            columns=columns,
            primary_keys=tuple(primary_keys),
            foreign_keys=tuple(foreign_keys),
        ))
    return SchemaContext(tables)


def schema_references_are_valid(sql, schema):
    """Conservatively reject only definite table or qualified-column errors."""
    expression = parse_read_only_query(sql)
    if expression is None:
        return False

    cte_names = {_key(cte.alias_or_name) for cte in expression.find_all(exp.CTE)}
    aliases = {}
    for table_expression in expression.find_all(exp.Table):
        table_name = table_expression.name
        if _key(table_name) in cte_names:
            continue
        table = schema.table(table_name)
        if table is None:
            return False
        aliases[_key(table_expression.alias_or_name)] = table.name
        aliases[_key(table.name)] = table.name

    for column in expression.find_all(exp.Column):
        qualifier = column.table
        if qualifier and _key(qualifier) in aliases:
            if not schema.has_column(aliases[_key(qualifier)], column.name):
                return False
    return True

