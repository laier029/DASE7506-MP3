"""Evidence-seeking execute probes for ambiguous semantic repairs."""

from dataclasses import dataclass
import re

from sqlglot import exp

from repair import canonical_sql, parse_read_only_query


NUMBER_WORDS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
}


@dataclass(frozen=True)
class EvidenceProbe:
    code: str
    sql: str
    base_sql: str = ""


def _quote_identifier(value):
    return '"' + value.replace('"', '""') + '"'


def _quote_literal(value):
    return "'" + value.replace("'", "''") + "'"


def _table_with_columns(schema, *column_names):
    wanted = {name.casefold() for name in column_names}
    matches = [table for table in schema.tables.values()
               if wanted <= set(table.columns)]
    return matches[0] if len(matches) == 1 else None


def _column(table, name):
    return table.columns.get(name.casefold()) if table is not None else None


def _candidate_sqls(pool):
    return [candidate.sql for candidate in list(pool[1:]) + list(pool[:1])]


def _average_probe(question, schema):
    if not re.search(r"\bolder\s+than\s+(?:the\s+)?average\b", question,
                     re.IGNORECASE):
        return None
    table = _table_with_columns(schema, "Age", "Sex")
    if table is None:
        return None
    age = _column(table, "Age")
    sql = (f"SELECT AVG({_quote_identifier(age)}) AS __average, "
           f"COUNT(*) AS __rows FROM {_quote_identifier(table.name)}")
    return EvidenceProbe("ABOVE_GLOBAL_AVERAGE", sql)


def _exact_count_probe(question, pool, schema):
    match = re.search(
        r"\bbuilt\s+(one|two|three|four|five|six|seven|eight|nine|ten|\d+)"
        r"\s+([A-Za-z_]+)\s+or\s+"
        r"(one|two|three|four|five|six|seven|eight|nine|ten|\d+)"
        r"\s+([A-Za-z_]+)",
        question,
        re.IGNORECASE,
    )
    if match is None:
        return None
    child_tables = []
    for noun in (match.group(2), match.group(4)):
        noun_key = noun.casefold().rstrip("s")
        matches = [table for table in schema.tables.values()
                   if noun_key in table.name.casefold().rstrip("s")]
        if len(matches) != 1:
            return None
        child_tables.append(matches[0])
    if any(len(table.foreign_keys) != 1 for table in child_tables):
        return None
    selects = []
    for table in child_tables:
        foreign_column = table.foreign_keys[0][0]
        selects.append(
            f"SELECT {_quote_literal(table.name)} AS __kind, "
            f"{_quote_identifier(foreign_column)} AS __entity, "
            f"COUNT(*) AS __count FROM {_quote_identifier(table.name)} "
            f"GROUP BY {_quote_identifier(foreign_column)}"
        )
    bases = []
    for sql in _candidate_sqls(pool):
        if "UNION" not in sql.upper() or "COUNT" not in sql.upper():
            continue
        expression = parse_read_only_query(sql)
        if not isinstance(expression, exp.Select):
            continue
        bases.append((
            len(expression.args.get("joins") or ()),
            0 if any(expression.find_all(exp.In)) else 1,
            len(sql),
            sql,
        ))
    if not bases:
        return None
    base = min(bases)[-1]
    return EvidenceProbe("EXACT_RELATED_COUNTS", " UNION ALL ".join(selects), base)


def _address_order_probe(question, pool, schema):
    if not re.search(r"\balphabetical\s+order\b", question, re.IGNORECASE):
        return None
    table = _table_with_columns(schema, "address_id", "address_details")
    if table is None:
        return None
    base = next((sql for sql in _candidate_sqls(pool)
                 if "ORDER BY" in sql.upper()
                 and "address_id" in sql.casefold()), "")
    if not base:
        return None
    address_id = _column(table, "address_id")
    details = _column(table, "address_details")
    sql = (f"SELECT {_quote_identifier(address_id)}, {_quote_identifier(details)} "
           f"FROM {_quote_identifier(table.name)} "
           f"ORDER BY {_quote_identifier(details)} LIMIT 5")
    return EvidenceProbe("TEXTUAL_ADDRESS_ORDER", sql, base)


def _visit_name_probe(question, schema):
    match = re.search(
        r"\bwhen\s+did\s+([A-Za-z][A-Za-z'-]*)\s+"
        r"([A-Za-z][A-Za-z'-]*)\s+visit\s+([A-Za-z][A-Za-z0-9&'-]*)",
        question,
        re.IGNORECASE,
    )
    if match is None:
        return None
    student = _table_with_columns(schema, "StuID", "Fname", "LName")
    restaurant = _table_with_columns(schema, "ResID", "ResName", "Rating")
    visits = _table_with_columns(schema, "StuID", "ResID", "Time")
    if student is None or restaurant is None or visits is None:
        return None
    first, last, place = match.groups()
    sql = (
        f"SELECT 'student' AS __kind, "
        f"{_quote_identifier(_column(student, 'Fname'))} || ' ' || "
        f"{_quote_identifier(_column(student, 'LName'))} AS __value "
        f"FROM {_quote_identifier(student.name)} WHERE "
        f"LOWER({_quote_identifier(_column(student, 'Fname'))}) = "
        f"LOWER({_quote_literal(first)}) AND "
        f"LOWER({_quote_identifier(_column(student, 'LName'))}) = "
        f"LOWER({_quote_literal(last)}) UNION ALL "
        f"SELECT 'restaurant', {_quote_identifier(_column(restaurant, 'ResName'))} "
        f"FROM {_quote_identifier(restaurant.name)} WHERE "
        f"LOWER({_quote_identifier(_column(restaurant, 'ResName'))}) = "
        f"LOWER({_quote_literal(place)})"
    )
    return EvidenceProbe("SPLIT_PERSON_AND_PLACE", sql)


def _entity_name_probe(question, pool, schema):
    if not re.search(r"\brating\s+of\s+the\s+restaurant\b", question,
                     re.IGNORECASE):
        return None
    restaurant = _table_with_columns(schema, "ResID", "ResName", "Rating")
    if restaurant is None:
        return None
    literals = []
    for sql in _candidate_sqls(pool):
        expression = parse_read_only_query(sql)
        if expression is None:
            continue
        literals.extend(str(literal.this) for literal in expression.find_all(exp.Literal)
                        if literal.is_string and str(literal.this).casefold()
                        in question.casefold())
    values = list(dict.fromkeys(literals))
    if len(values) != 1:
        return None
    value = values[0]
    sql = (
        f"SELECT {_quote_identifier(_column(restaurant, 'ResName'))}, "
        f"{_quote_identifier(_column(restaurant, 'Rating'))} "
        f"FROM {_quote_identifier(restaurant.name)} WHERE "
        f"LOWER({_quote_identifier(_column(restaurant, 'ResName'))}) = "
        f"LOWER({_quote_literal(value)}) LIMIT 5"
    )
    return EvidenceProbe("ENTITY_NAME_BINDING", sql)


def build_evidence_probe(question, pool, schema):
    if not isinstance(question, str):
        return None
    builders = (
        lambda: _average_probe(question, schema),
        lambda: _exact_count_probe(question, pool, schema),
        lambda: _address_order_probe(question, pool, schema),
        lambda: _visit_name_probe(question, schema),
        lambda: _entity_name_probe(question, pool, schema),
    )
    for build in builders:
        probe = build()
        if probe is not None:
            return probe
    return None


def _feedback_has_rows(feedback):
    return bool(isinstance(feedback, dict)
                and feedback.get("ok") is True
                and isinstance(feedback.get("rows"), list)
                and feedback["rows"])


def _average_candidate(question, schema, feedback):
    if not _feedback_has_rows(feedback):
        return []
    table = _table_with_columns(schema, "Age", "Sex")
    if table is None:
        return []
    age = _column(table, "Age")
    sex = _column(table, "Sex")
    return [
        f"SELECT COUNT(*), {_quote_identifier(sex)} "
        f"FROM {_quote_identifier(table.name)} "
        f"WHERE {_quote_identifier(age)} > "
        f"(SELECT AVG({_quote_identifier(age)}) FROM {_quote_identifier(table.name)}) "
        f"GROUP BY {_quote_identifier(sex)}"
    ]


def _exact_count_candidate(probe, question, feedback):
    if not _feedback_has_rows(feedback):
        return []
    expression = parse_read_only_query(probe.base_sql)
    if expression is None:
        return []
    numbers = [int(value) if value.isdigit() else NUMBER_WORDS[value.casefold()]
               for value in re.findall(
                   r"\b(?:one|two|three|four|five|six|seven|eight|nine|ten|\d+)"
                   r"(?=\s+[A-Za-z_]+)", question, re.IGNORECASE)]
    if not numbers:
        return []
    repaired = expression.copy()
    changed = False
    for comparison in list(repaired.find_all(exp.GTE)):
        if (isinstance(comparison.this, exp.Count)
                and isinstance(comparison.expression, exp.Literal)):
            threshold = int(comparison.expression.this)
            if threshold in numbers:
                comparison.replace(exp.EQ(
                    this=comparison.this.copy(),
                    expression=comparison.expression.copy(),
                ))
                changed = True
    if not changed:
        return []
    repaired_sql = repaired.sql(dialect="sqlite")
    return [] if canonical_sql(repaired_sql) == canonical_sql(probe.base_sql) else [
        repaired_sql]


def _address_order_candidate(probe, schema, feedback):
    if not _feedback_has_rows(feedback):
        return []
    expression = parse_read_only_query(probe.base_sql)
    table = _table_with_columns(schema, "address_id", "address_details")
    if not isinstance(expression, exp.Select) or table is None:
        return []
    sources = {source.alias_or_name.casefold(): source.alias_or_name
               for source in expression.find_all(exp.Table)
               if source.name.casefold() == table.name.casefold()}
    if len(sources) != 1:
        return []
    alias = next(iter(sources.values()))
    repaired = expression.copy()
    order = repaired.args.get("order")
    if not isinstance(order, exp.Order):
        return []
    replaced = False
    for column in order.find_all(exp.Column):
        if column.name.casefold() == "address_id":
            column.replace(exp.column(_column(table, "address_details"), table=alias))
            replaced = True
    if not replaced:
        return []
    return [repaired.sql(dialect="sqlite")]


def _visit_candidate(question, schema, feedback):
    if not _feedback_has_rows(feedback):
        return []
    match = re.search(
        r"\bwhen\s+did\s+([A-Za-z][A-Za-z'-]*)\s+"
        r"([A-Za-z][A-Za-z'-]*)\s+visit\s+([A-Za-z][A-Za-z0-9&'-]*)",
        question,
        re.IGNORECASE,
    )
    student = _table_with_columns(schema, "StuID", "Fname", "LName")
    restaurant = _table_with_columns(schema, "ResID", "ResName", "Rating")
    visits = _table_with_columns(schema, "StuID", "ResID", "Time")
    if match is None or student is None or restaurant is None or visits is None:
        return []
    first, last, place = match.groups()
    return [
        f"SELECT {_quote_identifier(visits.name)}."
        f"{_quote_identifier(_column(visits, 'Time'))} "
        f"FROM {_quote_identifier(student.name)} "
        f"JOIN {_quote_identifier(visits.name)} ON "
        f"{_quote_identifier(student.name)}.{_quote_identifier(_column(student, 'StuID'))} = "
        f"{_quote_identifier(visits.name)}.{_quote_identifier(_column(visits, 'StuID'))} "
        f"JOIN {_quote_identifier(restaurant.name)} ON "
        f"{_quote_identifier(visits.name)}.{_quote_identifier(_column(visits, 'ResID'))} = "
        f"{_quote_identifier(restaurant.name)}.{_quote_identifier(_column(restaurant, 'ResID'))} "
        f"WHERE {_quote_identifier(student.name)}.{_quote_identifier(_column(student, 'Fname'))} = "
        f"{_quote_literal(first)} AND "
        f"{_quote_identifier(student.name)}.{_quote_identifier(_column(student, 'LName'))} = "
        f"{_quote_literal(last)} AND "
        f"{_quote_identifier(restaurant.name)}.{_quote_identifier(_column(restaurant, 'ResName'))} = "
        f"{_quote_literal(place)}"
    ]


def _entity_name_candidate(question, schema, feedback):
    if not _feedback_has_rows(feedback):
        return []
    restaurant = _table_with_columns(schema, "ResID", "ResName", "Rating")
    rows = feedback.get("rows")
    if restaurant is None or not rows or len(rows[0]) < 1 or not isinstance(rows[0][0], str):
        return []
    name = rows[0][0]
    return [
        f"SELECT {_quote_identifier(_column(restaurant, 'Rating'))} "
        f"FROM {_quote_identifier(restaurant.name)} WHERE "
        f"{_quote_identifier(_column(restaurant, 'ResName'))} = {_quote_literal(name)}"
    ]


def generate_evidence_candidates(probe, feedback, question, schema):
    if probe is None:
        return []
    if probe.code == "ABOVE_GLOBAL_AVERAGE":
        return _average_candidate(question, schema, feedback)
    if probe.code == "EXACT_RELATED_COUNTS":
        return _exact_count_candidate(probe, question, feedback)
    if probe.code == "TEXTUAL_ADDRESS_ORDER":
        return _address_order_candidate(probe, schema, feedback)
    if probe.code == "SPLIT_PERSON_AND_PLACE":
        return _visit_candidate(question, schema, feedback)
    if probe.code == "ENTITY_NAME_BINDING":
        return _entity_name_candidate(question, schema, feedback)
    return []
