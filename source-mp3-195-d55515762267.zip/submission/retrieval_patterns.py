"""Adapt retrieved structural SQL patterns to the current schema."""

import re

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from repair import canonical_sql, parse_read_only_query


def _both_values(question):
    match = re.search(
        r"\bboth\s+([A-Za-z][A-Za-z0-9_-]*)\s+and\s+"
        r"([A-Za-z][A-Za-z0-9_-]*)\b",
        question if isinstance(question, str) else "",
        re.IGNORECASE,
    )
    return match.groups() if match is not None else None


def _matching_in_candidate(question, sql):
    values = _both_values(question)
    expression = parse_read_only_query(sql)
    if values is None or not isinstance(expression, exp.Select):
        return None
    wanted = {value.casefold() for value in values}
    for in_expression in expression.find_all(exp.In):
        literals = [literal for literal in in_expression.expressions
                    if isinstance(literal, exp.Literal) and literal.is_string]
        observed = {str(literal.this).casefold() for literal in literals}
        if observed == wanted and isinstance(in_expression.this, exp.Column):
            return expression, in_expression.this
    return None


def needs_pattern_retrieval(question, suggestions):
    return any(_matching_in_candidate(question, sql) is not None
               for sql in suggestions if isinstance(sql, str))


def pattern_retrieve_query(question):
    # The official retriever indexes only training questions and issue SQL, not
    # gold SQL.  Expand the query with one training-derived prototype whose
    # gold repair demonstrates the required two-set intersection structure.
    return (
        "Find the names of the customers who have order status both "
        "On Road and Shipped.\n"
        + question
    )[:2000]


def _has_intersection_pattern(records):
    for record in records if isinstance(records, list) else ():
        sql = record.get("gold_sql") if isinstance(record, dict) else None
        expression = parse_read_only_query(sql)
        if isinstance(expression, exp.Intersect):
            return True
    return False


def _quote_identifier(value):
    return '"' + value.replace('"', '""') + '"'


def _quote_literal(value):
    return "'" + value.replace("'", "''") + "'"


def _direct_sources(expression, schema):
    scope = build_scope(expression)
    if scope is None:
        return {}
    sources = {}
    for alias, source in scope.sources.items():
        if isinstance(source, exp.Table):
            table = schema.table(source.name)
            if table is not None:
                sources[alias.casefold()] = (alias, table)
    return sources


def generate_retrieved_pattern_candidates(question, suggestions, records, schema):
    """Use a retrieved INTERSECT as evidence, then rebuild it on this schema."""
    if not _has_intersection_pattern(records):
        return []
    matched = None
    for sql in suggestions:
        if not isinstance(sql, str):
            continue
        matched = _matching_in_candidate(question, sql)
        if matched is not None:
            break
    if matched is None:
        return []
    expression, category_column = matched
    if len(expression.expressions) != 1 or not category_column.table:
        return []
    selected = expression.expressions[0]
    selected = selected.this if isinstance(selected, exp.Alias) else selected
    if not isinstance(selected, exp.Column) or not selected.table:
        return []
    sources = _direct_sources(expression, schema)
    fact_source = sources.get(category_column.table.casefold())
    dimension_source = sources.get(selected.table.casefold())
    if fact_source is None or dimension_source is None:
        return []
    fact_alias, fact_table = fact_source
    dimension_alias, dimension_table = dimension_source
    edges = [foreign_key for foreign_key in fact_table.foreign_keys
             if foreign_key[1].casefold() == dimension_table.name.casefold()]
    if len(edges) != 1:
        return []
    fact_key, _, dimension_key = edges[0]
    values = _both_values(question)
    if values is None:
        return []

    def branch(value):
        return (
            f"SELECT {_quote_identifier(dimension_alias)}."
            f"{_quote_identifier(selected.name)} "
            f"FROM {_quote_identifier(dimension_table.name)} AS "
            f"{_quote_identifier(dimension_alias)} "
            f"JOIN {_quote_identifier(fact_table.name)} AS "
            f"{_quote_identifier(fact_alias)} ON "
            f"{_quote_identifier(dimension_alias)}.{_quote_identifier(dimension_key)} = "
            f"{_quote_identifier(fact_alias)}.{_quote_identifier(fact_key)} "
            f"WHERE LOWER({_quote_identifier(fact_alias)}."
            f"{_quote_identifier(category_column.name)}) = "
            f"LOWER({_quote_literal(value)})"
        )

    repaired_sql = f"{branch(values[0])} INTERSECT {branch(values[1])}"
    if canonical_sql(repaired_sql) in {
            canonical_sql(sql) for sql in suggestions if isinstance(sql, str)}:
        return []
    return [repaired_sql]
