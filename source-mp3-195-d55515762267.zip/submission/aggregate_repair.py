"""High-confidence aggregate repair candidates."""

import re

from sqlglot import exp

from repair import parse_read_only_query


def _column_key(column):
    return (column.table.casefold(), column.name.casefold())


def _unwrap_alias(expression):
    return expression.this if isinstance(expression, exp.Alias) else expression


def _limit_is_one(select):
    limit = select.args.get("limit")
    value = limit.args.get("expression") if isinstance(limit, exp.Limit) else None
    return isinstance(value, exp.Literal) and str(value.this) == "1"


def _column_is_named_in_question(column, question):
    words = set(re.findall(r"[a-z0-9]+", question.casefold()))
    column_words = re.findall(r"[a-z0-9]+", column.name.casefold().replace("_", " "))
    return bool(column_words) and all(word in words for word in column_words)


def generate_aggregate_candidates(bound_intent, issue_sql, _schema):
    """Repair raw-value top-one SQL when the question asks for a grouped total."""
    aggregate = bound_intent.intent.aggregate
    if "SUM" not in aggregate.required_functions or aggregate.superlative not in ("max", "min"):
        return []

    expression = parse_read_only_query(issue_sql)
    if not isinstance(expression, exp.Select) or any(expression.find_all(exp.Sum)):
        return []
    if not _limit_is_one(expression) or expression.args.get("group") is not None:
        return []

    order = expression.args.get("order")
    if not isinstance(order, exp.Order) or len(order.expressions) != 1:
        return []
    ordered = order.expressions[0]
    if not isinstance(ordered, exp.Ordered) or not isinstance(ordered.this, exp.Column):
        return []
    descending = ordered.args.get("desc") is True
    if (aggregate.superlative == "max") != descending:
        return []

    measure = ordered.this
    if not _column_is_named_in_question(measure, bound_intent.intent.question):
        return []

    dimensions = []
    found_measure = False
    for selected in expression.expressions:
        raw_selected = _unwrap_alias(selected)
        if isinstance(raw_selected, exp.Column) and _column_key(raw_selected) == _column_key(measure):
            found_measure = True
        elif isinstance(raw_selected, exp.Column):
            dimensions.append(raw_selected.copy())
        else:
            return []
    if not found_measure or not dimensions:
        return []

    repaired = expression.copy()
    summed_measure = exp.Sum(this=measure.copy())
    repaired.set("expressions", dimensions + [summed_measure.copy()])
    repaired.set("group", exp.Group(expressions=[dimension.copy()
                                                 for dimension in dimensions]))
    repaired.set("order", exp.Order(expressions=[exp.Ordered(
        this=summed_measure.copy(),
        desc=aggregate.superlative == "max",
        nulls_first=False,
    )]))
    return [repaired.sql(dialect="sqlite")]
