"""Build and rank a unified pool of SQL repair candidates."""

from dataclasses import dataclass

from query_plan import build_query_plan
from repair import canonical_sql, rank_hint_candidates
from semantic_audit import SqlAuditReport, audit_sql


SOURCE_ORDER = {
    "generated": 0,
    "hint": 1,
    "retrieved": 2,
    "original": 3,
}


@dataclass(frozen=True)
class CandidateRecord:
    sql: str
    source: str
    canonical: str
    plan: object
    audit: object
    consensus: int = 1
    similarity: float = 0.0
    position: int = 0


def build_candidate_pool(issue_sql, generated_sqls, hint_suggestions,
                         retrieved_records, bound_intent, schema,
                         max_hint_candidates=4, audit_enabled=True):
    def report_for(sql):
        return (audit_sql(sql, bound_intent, schema) if audit_enabled
                else SqlAuditReport("unknown", ()))

    original_plan = build_query_plan(issue_sql)
    original = CandidateRecord(
        sql=issue_sql,
        source="original",
        canonical=canonical_sql(issue_sql),
        plan=original_plan,
        audit=report_for(issue_sql),
    )
    records = [original]
    seen = {original.canonical}

    def add(sql, source, consensus=1, similarity=0.0, position=0):
        if not isinstance(sql, str):
            return
        canonical = canonical_sql(sql)
        if not canonical or canonical in seen:
            return
        plan = build_query_plan(sql)
        if plan is None:
            return
        report = report_for(sql)
        if report.structurally_invalid:
            return
        if source in ("generated", "retrieved") and report.definitely_wrong:
            return
        if (source == "retrieved" and original_plan is not None
                and plan.output_count != original_plan.output_count):
            return
        seen.add(canonical)
        records.append(CandidateRecord(
            sql=sql,
            source=source,
            canonical=canonical,
            plan=plan,
            audit=report,
            consensus=consensus,
            similarity=similarity,
            position=position,
        ))

    for position, sql in enumerate(generated_sqls or ()):
        add(sql, "generated", position=position)

    for candidate in rank_hint_candidates(
            hint_suggestions, issue_sql)[:max_hint_candidates]:
        add(candidate.sql, "hint", candidate.frequency,
            candidate.similarity, candidate.first_position)

    for position, record in enumerate(
            retrieved_records if isinstance(retrieved_records, list) else ()):
        if isinstance(record, dict):
            add(record.get("gold_sql"), "retrieved", position=position)

    alternatives = sorted(records[1:], key=lambda candidate: (
        candidate.audit.definitely_wrong,
        SOURCE_ORDER[candidate.source],
        -candidate.consensus,
        -candidate.similarity,
        candidate.position,
        candidate.canonical,
    ))
    return tuple([original] + alternatives)
