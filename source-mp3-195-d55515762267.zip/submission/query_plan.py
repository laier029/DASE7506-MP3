"""Compact structural representation of a SQL query."""

from dataclasses import dataclass

from sqlglot import exp

from repair import parse_read_only_query


AGGREGATE_TYPES = {
    exp.Avg: "AVG",
    exp.Count: "COUNT",
    exp.Max: "MAX",
    exp.Min: "MIN",
    exp.Sum: "SUM",
}


@dataclass(frozen=True)
class QueryPlan:
    output_expressions: tuple
    tables: tuple
    joins: tuple
    filters: tuple
    group_by: tuple
    aggregates: tuple
    having: tuple
    distinct: bool
    order_by: tuple
    limit: int | None

    @property
    def output_count(self):
        return len(self.output_expressions)


def _literal_integer(expression):
    if isinstance(expression, exp.Literal) and str(expression.this).isdigit():
        return int(expression.this)
    return None


def build_query_plan(sql):
    expression = parse_read_only_query(sql)
    if expression is None:
        return None

    root = expression if isinstance(expression, exp.Select) else None
    output_expressions = tuple(
        selected.sql(dialect="sqlite") for selected in (root.expressions if root else ()))
    tables = tuple(dict.fromkeys(
        table.name for table in expression.find_all(exp.Table)))
    joins = tuple(
        (
            join.args.get("kind") or "INNER",
            join.this.sql(dialect="sqlite"),
            join.args["on"].sql(dialect="sqlite") if join.args.get("on") else None,
        )
        for join in expression.find_all(exp.Join)
    )
    filters = tuple(
        where.this.sql(dialect="sqlite") for where in expression.find_all(exp.Where))
    group_by = tuple(
        item.sql(dialect="sqlite")
        for group in expression.find_all(exp.Group)
        for item in group.expressions
    )
    aggregates = tuple(sorted({
        aggregate_name
        for aggregate_type, aggregate_name in AGGREGATE_TYPES.items()
        for _ in expression.find_all(aggregate_type)
    }))
    having = tuple(
        clause.this.sql(dialect="sqlite") for clause in expression.find_all(exp.Having))

    order_by = ()
    limit = None
    distinct = False
    if root is not None:
        distinct = root.args.get("distinct") is not None
        order = root.args.get("order")
        if isinstance(order, exp.Order):
            order_by = tuple(item.sql(dialect="sqlite") for item in order.expressions)
        limit_expression = root.args.get("limit")
        if isinstance(limit_expression, exp.Limit):
            limit = _literal_integer(limit_expression.args.get("expression"))

    return QueryPlan(
        output_expressions=output_expressions,
        tables=tables,
        joins=joins,
        filters=filters,
        group_by=group_by,
        aggregates=aggregates,
        having=having,
        distinct=distinct,
        order_by=order_by,
        limit=limit,
    )
