"""Bounded diagnostic probes and repairs for Join row multiplication."""

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from repair import parse_read_only_query


def _counted_entity(bound_intent):
    return bound_intent.aggregate_counted_table or bound_intent.counted_table


def _entity_source(expression, bound_intent, schema):
    entity_name = _counted_entity(bound_intent)
    table = schema.table(entity_name)
    if table is None or len(table.primary_keys) != 1:
        return None
    scope = build_scope(expression)
    if scope is None:
        return None
    matches = []
    for alias, source in scope.sources.items():
        if isinstance(source, exp.Table) and source.name.casefold() == table.name.casefold():
            matches.append((alias, table.primary_keys[0]))
    return matches[0] if len(matches) == 1 else None


def build_join_multiplicity_probe(sql, bound_intent, schema):
    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select) or not expression.args.get("joins"):
        return None
    if not any(isinstance(count.this, exp.Star)
               for count in expression.find_all(exp.Count)):
        return None
    source = _entity_source(expression, bound_intent, schema)
    if source is None:
        return None
    alias, primary_key = source
    entity_key = exp.column(primary_key, table=alias)

    probe = expression.copy()
    probe.set("expressions", [
        exp.alias_(exp.Count(this=exp.Star()), "__joined_rows", quoted=True),
        exp.alias_(
            exp.Count(this=exp.Distinct(expressions=[entity_key.copy()])),
            "__distinct_entities",
            quoted=True,
        ),
    ])
    for field in ("distinct", "group", "having", "order", "limit"):
        probe.set(field, None)
    return probe.sql(dialect="sqlite")


def generate_join_dedup_candidate(sql, bound_intent, schema, feedback):
    if not isinstance(feedback, dict) or feedback.get("ok") is not True:
        return []
    rows = feedback.get("rows")
    if (not isinstance(rows, list) or not rows or not isinstance(rows[0], list)
            or len(rows[0]) < 2):
        return []
    joined_rows, distinct_entities = rows[0][0], rows[0][1]
    if (not isinstance(joined_rows, (int, float))
            or not isinstance(distinct_entities, (int, float))
            or joined_rows <= distinct_entities):
        return []

    expression = parse_read_only_query(sql)
    if not isinstance(expression, exp.Select):
        return []
    source = _entity_source(expression, bound_intent, schema)
    if source is None:
        return []
    alias, primary_key = source
    repaired = expression.copy()
    counts = list(repaired.find_all(exp.Count))
    replaceable = [count for count in counts if isinstance(count.this, exp.Star)]
    if not replaceable:
        return []
    for count in replaceable:
        count.replace(exp.Count(this=exp.Distinct(
            expressions=[exp.column(primary_key, table=alias)])))
    return [repaired.sql(dialect="sqlite")]
