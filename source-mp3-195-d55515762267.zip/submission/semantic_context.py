"""Deterministic question intent extraction and schema binding."""

from dataclasses import dataclass
import re


NUMBER_WORDS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
}

QUANTITY_PATTERN = re.compile(
    r"\b(at\s+least|more\s+than|over|at\s+most|no\s+more\s+than|"
    r"less\s+than|fewer\s+than|exactly)\s+"
    r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b",
    re.IGNORECASE,
)

QUANTITY_OPERATORS = {
    "at least": ">=",
    "more than": ">",
    "over": ">",
    "at most": "<=",
    "no more than": "<=",
    "less than": "<",
    "fewer than": "<",
    "exactly": "=",
}

COUNT_NOUN_PREFIXES = {"different", "distinct", "individual", "separate", "unique"}

SUM_MEASURE_PATTERN = re.compile(
    r"\b(?:sum\s+of|total\s+(?:amount|balance|cost|damage|deaths?|hours?|income|"
    r"population|price|revenue|salary|sales|stock))\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class QuantityIntent:
    operator: str
    threshold: int
    counted_noun: str | None


@dataclass(frozen=True)
class AggregateIntent:
    required_functions: tuple
    superlative: str | None
    counted_noun: str | None


@dataclass(frozen=True)
class QueryIntent:
    question: str
    projection_text: str
    quantity: QuantityIntent | None
    aggregate: AggregateIntent
    ordered: bool


@dataclass(frozen=True)
class BoundIntent:
    intent: QueryIntent
    counted_table: str | None
    aggregate_counted_table: str | None
    projection_columns: tuple


@dataclass(frozen=True)
class SemanticFilter:
    entity: str
    attribute: str
    operator: str
    value: str


@dataclass(frozen=True)
class SemanticContract:
    """Small, explicit contract for high-confidence question semantics."""

    code: str | None
    target: str
    subject: str | None
    filters: tuple
    grain: str | None
    aggregation: str | None
    set_logic: str | None
    temporal: str | None
    ordered: bool


def _identifier_tokens(value):
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", value)
    return tuple(re.findall(r"[a-z0-9]+", value.casefold()))


def _singular(token):
    irregular = {
        "children": "child",
        "men": "man",
        "people": "person",
        "women": "woman",
    }
    if token in irregular:
        return irregular[token]
    if token.endswith("ies") and len(token) > 3:
        return token[:-3] + "y"
    if token.endswith("ses") and len(token) > 3:
        return token[:-2]
    if token.endswith("s") and not token.endswith("ss") and len(token) > 2:
        return token[:-1]
    return token


def _normalised_tokens(value):
    return tuple(_singular(token) for token in _identifier_tokens(value))


def _first_content_noun(text):
    for word in re.findall(r"[A-Za-z][A-Za-z0-9_-]*", text):
        if word.casefold() not in COUNT_NOUN_PREFIXES:
            return word
    return None


def extract_query_intent(question, ordered=False):
    question = question if isinstance(question, str) else ""
    match = QUANTITY_PATTERN.search(question)
    quantity = None
    projection_text = question
    if match is not None:
        projection_text = question[:match.start()]
        raw_number = match.group(2).casefold()
        quantity = QuantityIntent(
            operator=QUANTITY_OPERATORS[re.sub(r"\s+", " ", match.group(1).casefold())],
            threshold=int(raw_number) if raw_number.isdigit() else NUMBER_WORDS[raw_number],
            counted_noun=_first_content_noun(question[match.end():]),
        )

    question_key = question.casefold()
    required_functions = []
    if re.search(r"\baverage\b", question_key):
        required_functions.append("AVG")
    if SUM_MEASURE_PATTERN.search(question):
        required_functions.append("SUM")

    how_many = re.search(r"\bhow\s+many\b", question, re.IGNORECASE)
    aggregate_counted_noun = (
        _first_content_noun(question[how_many.end():]) if how_many is not None else None)

    superlative = None
    if re.search(r"\b(?:maximum|highest|largest)\s+(?:average|total)\b", question_key):
        superlative = "max"
    elif re.search(r"\b(?:minimum|lowest|smallest)\s+(?:average|total)\b", question_key):
        superlative = "min"
    else:
        if re.search(r"\bmaximum\b", question_key):
            required_functions.append("MAX")
        if re.search(r"\bminimum\b", question_key):
            required_functions.append("MIN")

    aggregate = AggregateIntent(
        required_functions=tuple(dict.fromkeys(required_functions)),
        superlative=superlative,
        counted_noun=aggregate_counted_noun,
    )
    return QueryIntent(
        question=question,
        projection_text=projection_text,
        quantity=quantity,
        aggregate=aggregate,
        ordered=bool(ordered),
    )


def build_semantic_contract(intent):
    """Extract only semantic roles that can be stated without schema guesses."""
    question = intent.question
    visit = re.search(
        r"^\s*when\s+did\s+([A-Za-z][A-Za-z'-]*)\s+"
        r"([A-Za-z][A-Za-z'-]*)\s+visit\s+(.+?)\s*\?\s*$",
        question,
        re.IGNORECASE,
    )
    if visit is not None:
        first, last, restaurant = visit.groups()
        return SemanticContract(
            code="PERSON_VISITS_PLACE",
            target="time",
            subject="visit",
            filters=(
                SemanticFilter("student", "first_name", "=", first),
                SemanticFilter("student", "last_name", "=", last),
                SemanticFilter("restaurant", "name", "=", restaurant),
            ),
            grain="visit event",
            aggregation=None,
            set_logic=None,
            temporal="when",
            ordered=intent.ordered,
        )

    rating = re.search(
        r"^\s*what\s+is\s+the\s+rating\s+of\s+the\s+restaurant\s+"
        r"(.+?)\s*\?\s*$",
        question,
        re.IGNORECASE,
    )
    if rating is not None:
        return SemanticContract(
            code="ENTITY_ATTRIBUTE_BY_NAME",
            target="rating",
            subject="restaurant",
            filters=(
                SemanticFilter("restaurant", "name", "=", rating.group(1)),
            ),
            grain="restaurant",
            aggregation=None,
            set_logic=None,
            temporal=None,
            ordered=intent.ordered,
        )

    first_contact_at_max = re.search(
        r"\blast\s+name\s+of\s+the\s+first\s+individual\s+contacted\b.*"
        r"\bmaximum\s+uk\s+vat\s+number\b",
        question,
        re.IGNORECASE,
    )
    if first_contact_at_max is not None:
        return SemanticContract(
            code="FIRST_CONTACT_AT_MAX_ENTITY",
            target="individual last name",
            subject="organization contact",
            filters=(SemanticFilter(
                "organization", "uk_vat_number", "=", "maximum"),),
            grain="one contact individual",
            aggregation="MAX",
            set_logic=None,
            temporal="first contact",
            ordered=True,
        )

    all_roles = re.search(
        r"^\s*list\s+the\s+(.+?)\s+of\s+all\s+the\s+(.+?)\s*[.?]\s*$",
        question,
        re.IGNORECASE,
    )
    if all_roles is not None:
        target, subject = all_roles.groups()
        return SemanticContract(
            code="ALL_ROLE_ENTITIES",
            target=target,
            subject=subject,
            filters=(),
            grain=subject,
            aggregation=None,
            set_logic="all",
            temporal=None,
            ordered=intent.ordered,
        )

    how_many = re.search(r"^\s*how\s+many\b", question, re.IGNORECASE)
    requests_distinct = re.search(
        r"\b(?:distinct|different|unique)\b", question, re.IGNORECASE)
    if how_many is not None and requests_distinct is None:
        return SemanticContract(
            code="ROW_COUNT",
            target="count",
            subject=intent.aggregate.counted_noun,
            filters=(),
            grain="source row",
            aggregation="COUNT",
            set_logic=None,
            temporal=None,
            ordered=intent.ordered,
        )

    aggregate = intent.aggregate
    return SemanticContract(
        code=None,
        target=intent.projection_text,
        subject=None,
        filters=(),
        grain=None,
        aggregation=(aggregate.required_functions[0]
                     if len(aggregate.required_functions) == 1 else None),
        set_logic=None,
        temporal=None,
        ordered=intent.ordered,
    )


def bind_intent_to_schema(intent, schema):
    def unique_table_for_noun(noun):
        if not noun:
            return None
        counted_key = _singular(noun.casefold())
        matches = []
        for table in schema.tables.values():
            table_tokens = _normalised_tokens(table.name)
            if counted_key in table_tokens:
                matches.append(table.name)
        return matches[0] if len(matches) == 1 else None

    counted_table = unique_table_for_noun(
        intent.quantity.counted_noun if intent.quantity is not None else None)
    aggregate_counted_table = unique_table_for_noun(intent.aggregate.counted_noun)

    question_tokens = set(_normalised_tokens(intent.projection_text))
    projection_columns = []
    for table in schema.tables.values():
        for column in table.columns.values():
            column_tokens = _normalised_tokens(column)
            if column_tokens and all(token in question_tokens for token in column_tokens):
                projection_columns.append((table.name, column))

    return BoundIntent(
        intent=intent,
        counted_table=counted_table,
        aggregate_counted_table=aggregate_counted_table,
        projection_columns=tuple(projection_columns),
    )
