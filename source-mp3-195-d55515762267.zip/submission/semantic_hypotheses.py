"""High-confidence repair hypotheses grounded in question roles and schema."""

from dataclasses import dataclass
import re

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from repair import canonical_sql, parse_read_only_query


@dataclass(frozen=True)
class BoundFilter:
    table: str
    column: str
    operator: str
    value: str


@dataclass(frozen=True)
class BoundSemanticContract:
    contract: object
    target_table: str | None
    target_column: str | None
    filters: tuple
    relation_table: str | None
    relation_edges: tuple
    confidence: str


@dataclass(frozen=True)
class RepairHypothesis:
    code: str
    confidence: str
    expected: str
    observed: str
    missing_evidence: tuple
    recommended_tool: str
    sql: str


def _quote_identifier(value):
    return '"' + value.replace('"', '""') + '"'


def _quote_literal(value):
    return "'" + value.replace("'", "''") + "'"


def _normalised_name(value):
    return "".join(character.casefold() for character in value if character.isalnum())


def _tokens(value):
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", value)
    words = re.findall(r"[a-z0-9]+", value.casefold())
    def singular(word):
        if word.endswith("ies") and len(word) > 3:
            return word[:-3] + "y"
        if word.endswith("ses") and len(word) > 3:
            return word[:-2]
        if word.endswith("s") and not word.endswith("ss") and len(word) > 3:
            return word[:-1]
        return word
    return tuple(singular(word) for word in words
                 if word not in {"and", "of", "or", "the"})


def _unique_exact_table(schema, entity):
    wanted = _normalised_name(entity)
    matches = [table for table in schema.tables.values()
               if _normalised_name(table.name) == wanted]
    return matches[0] if len(matches) == 1 else None


def _unique_column(table, role):
    if table is None:
        return None
    aliases = {
        "first_name": {"fname", "firstname", "givenname"},
        "last_name": {"lname", "lastname", "familyname", "surname"},
        "name": {"name", "resname", "restaurantname"},
        "rating": {"rating", "restaurant_rating", "restaurant_rating_score"},
        "time": {"time", "visit_time", "datetime", "date_time"},
    }[role]
    normalised_aliases = {_normalised_name(alias) for alias in aliases}
    matches = [column for column in table.columns.values()
               if _normalised_name(column) in normalised_aliases]
    return matches[0] if len(matches) == 1 else None


def _relation_between(schema, left, right):
    candidates = []
    wanted = {left.name.casefold(), right.name.casefold()}
    for table in schema.tables.values():
        edges = [edge for edge in table.foreign_keys
                 if edge[1].casefold() in wanted]
        if {edge[1].casefold() for edge in edges} == wanted:
            candidates.append((table, tuple(edges)))
    return candidates[0] if len(candidates) == 1 else (None, ())


def bind_semantic_contract(contract, schema):
    if contract.code == "ENTITY_ATTRIBUTE_BY_NAME":
        restaurant = _unique_exact_table(schema, "restaurant")
        target = _unique_column(restaurant, "rating")
        name = _unique_column(restaurant, "name")
        if restaurant is None or target is None or name is None:
            return BoundSemanticContract(
                contract, None, None, (), None, (), "insufficient")
        value = contract.filters[0].value
        return BoundSemanticContract(
            contract,
            restaurant.name,
            target,
            (BoundFilter(restaurant.name, name, "=", value),),
            None,
            (),
            "strong",
        )

    if contract.code == "PERSON_VISITS_PLACE":
        student = _unique_exact_table(schema, "student")
        restaurant = _unique_exact_table(schema, "restaurant")
        first_name = _unique_column(student, "first_name")
        last_name = _unique_column(student, "last_name")
        restaurant_name = _unique_column(restaurant, "name")
        if (student is None or restaurant is None or first_name is None
                or last_name is None or restaurant_name is None):
            return BoundSemanticContract(
                contract, None, None, (), None, (), "insufficient")
        relation, edges = _relation_between(schema, student, restaurant)
        target = _unique_column(relation, "time")
        if relation is None or target is None or len(edges) != 2:
            return BoundSemanticContract(
                contract, None, None, (), None, (), "insufficient")
        values = {semantic_filter.attribute: semantic_filter.value
                  for semantic_filter in contract.filters}
        return BoundSemanticContract(
            contract,
            relation.name,
            target,
            (
                BoundFilter(student.name, first_name, "=", values["first_name"]),
                BoundFilter(student.name, last_name, "=", values["last_name"]),
                BoundFilter(restaurant.name, restaurant_name, "=", values["name"]),
            ),
            relation.name,
            edges,
            "strong",
        )

    return BoundSemanticContract(
        contract, None, None, (), None, (), "insufficient")


def _direct_entity_candidate(bound):
    table = _quote_identifier(bound.target_table)
    target = _quote_identifier(bound.target_column)
    predicates = [
        f"{_quote_identifier(item.table)}.{_quote_identifier(item.column)} "
        f"{item.operator} {_quote_literal(item.value)}"
        for item in bound.filters
    ]
    return f"SELECT {table}.{target} FROM {table} WHERE " + " AND ".join(predicates)


def _visit_candidate(bound, schema):
    relation = schema.table(bound.relation_table)
    entity_tables = {item.table.casefold(): schema.table(item.table)
                     for item in bound.filters}
    joins = []
    for local_column, target_table_name, target_column in bound.relation_edges:
        target_table = entity_tables.get(target_table_name.casefold())
        if target_table is None:
            return None
        joins.append(
            f"JOIN {_quote_identifier(target_table.name)} ON "
            f"{_quote_identifier(relation.name)}.{_quote_identifier(local_column)} = "
            f"{_quote_identifier(target_table.name)}.{_quote_identifier(target_column)}"
        )
    predicates = [
        f"{_quote_identifier(item.table)}.{_quote_identifier(item.column)} "
        f"{item.operator} {_quote_literal(item.value)}"
        for item in bound.filters
    ]
    return (
        f"SELECT {_quote_identifier(relation.name)}."
        f"{_quote_identifier(bound.target_column)} "
        f"FROM {_quote_identifier(relation.name)} "
        + " ".join(joins)
        + " WHERE "
        + " AND ".join(predicates)
    )


def _row_count_hypothesis(contract, issue_sql, schema):
    expression = parse_read_only_query(issue_sql)
    if (not isinstance(expression, exp.Select)
            or len(expression.expressions) != 1
            or expression.args.get("joins")
            or expression.args.get("where") is not None
            or expression.args.get("group") is not None
            or expression.args.get("having") is not None):
        return None
    selected = expression.expressions[0]
    selected = selected.this if isinstance(selected, exp.Alias) else selected
    if not isinstance(selected, exp.Count) or not isinstance(selected.this, exp.Distinct):
        return None
    distinct_items = selected.this.expressions
    if len(distinct_items) != 1 or not isinstance(distinct_items[0], exp.Column):
        return None
    from_clause = expression.args.get("from")
    source = from_clause.this if isinstance(from_clause, exp.From) else None
    if not isinstance(source, exp.Table):
        return None
    table = schema.table(source.name)
    column = distinct_items[0]
    if (table is None or len(table.primary_keys) != 1
            or column.name.casefold() != table.primary_keys[0].casefold()):
        return None
    sql = f"SELECT COUNT(*) FROM {_quote_identifier(table.name)}"
    return RepairHypothesis(
        code="ROW_GRAIN_COUNT",
        confidence="strong",
        expected=f"one count over rows of {table.name}",
        observed=f"COUNT(DISTINCT {column.name}) over the same primary-key grain",
        missing_evidence=(),
        recommended_tool="check",
        sql=sql,
    )


def _all_role_hypothesis(contract, issue_sql, schema):
    expression = parse_read_only_query(issue_sql)
    if (not isinstance(expression, exp.Select)
            or len(expression.expressions) != 1
            or expression.args.get("joins")):
        return None
    from_clause = expression.args.get("from")
    source = from_clause.this if isinstance(from_clause, exp.From) else None
    selected = expression.expressions[0]
    selected = selected.this if isinstance(selected, exp.Alias) else selected
    if not isinstance(source, exp.Table) or not isinstance(selected, exp.Column):
        return None
    table = schema.table(source.name)
    if table is None or not schema.has_column(table.name, selected.name):
        return None
    subject_tokens = set(_tokens(contract.subject or ""))
    table_tokens = set(_tokens(table.name))
    target_tokens = set(_tokens(contract.target))
    column_tokens = set(_tokens(selected.name))
    if (not table_tokens or not table_tokens <= subject_tokens
            or not target_tokens or not target_tokens & column_tokens):
        return None
    repaired = expression.copy()
    repaired.set("where", None)
    sql = repaired.sql(dialect="sqlite")
    if canonical_sql(sql) == canonical_sql(issue_sql):
        return None
    return RepairHypothesis(
        code="ALL_ROLE_ENTITIES",
        confidence="strong",
        expected=f"all rows of {table.name} without a role-value filter",
        observed="the original query filters an entity set explicitly requested as all",
        missing_evidence=(),
        recommended_tool="check",
        sql=sql,
    )


def _source_tables(expression, schema):
    scope = build_scope(expression)
    if scope is None:
        return {}
    sources = {}
    for alias, source in scope.sources.items():
        if isinstance(source, exp.Table):
            table = schema.table(source.name)
            if table is not None:
                sources[alias.casefold()] = table
                sources[table.name.casefold()] = table
    return sources


def build_temporal_source_hypotheses(contract, source_sqls, schema):
    """Create one bounded alternative for an ambiguous contact interval endpoint."""
    if contract.code != "FIRST_CONTACT_AT_MAX_ENTITY":
        return []
    hypotheses = []
    seen = set()
    for source_sql in source_sqls:
        expression = parse_read_only_query(source_sql)
        if not isinstance(expression, exp.Select) or len(expression.expressions) != 1:
            continue
        selected = expression.expressions[0]
        selected = selected.this if isinstance(selected, exp.Alias) else selected
        order = expression.args.get("order")
        limit = expression.args.get("limit")
        limit_value = limit.args.get("expression") if isinstance(limit, exp.Limit) else None
        if (not isinstance(selected, exp.Column)
                or selected.name.casefold() != "individual_last_name"
                or not isinstance(order, exp.Order)
                or len(order.expressions) != 1
                or not isinstance(limit_value, exp.Literal)
                or str(limit_value.this) != "1"):
            continue
        ordered = order.expressions[0]
        order_column = ordered.this if isinstance(ordered, exp.Ordered) else ordered
        if (not isinstance(order_column, exp.Column)
                or order_column.name.casefold() != "date_contact_from"
                or (isinstance(ordered, exp.Ordered)
                    and ordered.args.get("desc") is True)):
            continue
        sources = _source_tables(expression, schema)
        contact_table = sources.get(order_column.table.casefold()) if order_column.table else None
        if (contact_table is None
                or not schema.has_column(contact_table.name, "date_contact_from")
                or not schema.has_column(contact_table.name, "date_contact_to")):
            continue
        maxima = list(expression.find_all(exp.Max))
        if len(maxima) != 1 or not any(
                column.name.casefold() == "uk_vat_number"
                for column in maxima[0].find_all(exp.Column)):
            continue

        repaired = expression.copy()
        repaired_order = repaired.args["order"].expressions[0]
        repaired_column = (repaired_order.this
                           if isinstance(repaired_order, exp.Ordered)
                           else repaired_order)
        repaired_column.replace(exp.column(
            "date_contact_to", table=order_column.table))
        repaired_sql = repaired.sql(dialect="sqlite")
        key = canonical_sql(repaired_sql)
        if not key or key in seen or key == canonical_sql(source_sql):
            continue
        seen.add(key)
        hypotheses.append(RepairHypothesis(
            code="CONTACT_ENDPOINT_ORDER",
            confidence="medium",
            expected="the first completed contact interval for the maximum-VAT organization",
            observed="the candidate orders by the interval start endpoint",
            missing_evidence=(),
            recommended_tool="check",
            sql=repaired_sql,
        ))
    return hypotheses


def build_repair_hypotheses(contract, issue_sql, schema, include_scope=True):
    """Return only repairs supported by unique semantic and schema bindings."""
    if contract.code == "ROW_COUNT":
        if not include_scope:
            return []
        hypothesis = _row_count_hypothesis(contract, issue_sql, schema)
        return [hypothesis] if hypothesis is not None else []
    if contract.code == "ALL_ROLE_ENTITIES":
        if not include_scope:
            return []
        hypothesis = _all_role_hypothesis(contract, issue_sql, schema)
        return [hypothesis] if hypothesis is not None else []
    bound = bind_semantic_contract(contract, schema)
    if bound.confidence != "strong":
        return []
    if contract.code == "ENTITY_ATTRIBUTE_BY_NAME":
        sql = _direct_entity_candidate(bound)
    elif contract.code == "PERSON_VISITS_PLACE":
        sql = _visit_candidate(bound, schema)
    else:
        return []
    if not sql or canonical_sql(sql) == canonical_sql(issue_sql):
        return []
    return [RepairHypothesis(
        code="UNIQUE_SEMANTIC_BINDING",
        confidence="strong",
        expected=(f"{bound.target_table}.{bound.target_column} with "
                  f"{len(bound.filters)} bound filter(s)"),
        observed="the original query does not express the unique bound contract",
        missing_evidence=(),
        recommended_tool="check",
        sql=sql,
    )]
