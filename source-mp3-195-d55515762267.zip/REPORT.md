# SQL Repair Agent

DASE7506 Mini-project 3 | Second submission | 27 November 2026

The frozen agent answered **195 of 240 TEST questions (81.25%)** and **117 of 120 validation questions (97.50%)**. The official scorer replays the tool trace and requires the submitted SQL to match the expected result on all three database instances. The previous submission scored 181/240. The 14-question increase is a difference between whole-bank scores. All examples and per-question comparisons below use TRAIN.

## From the question to a checked repair

**Establish a provisional answer.** The controller reads the schema, checks the draft against the public example and retains a query it can submit. The program can propose local SQL edits. For cases with a recorded risk and remaining tool budget, it can also request one complete SQLite query from the frozen H65 adapter. The model sees the question, full public schema, original draft, public check, example and ordering requirement. The program parses the response and controls each subsequent action.

**Locate the disagreement.** The controller records what columns to return, what one result row represents, which records qualify, and whether grouping, ordering or exclusion is required. It compares these requirements with the candidate's SELECT, joins, filters and aggregates. A public match can leave two interpretations plausible, especially when the sample is empty. The controller can revisit a matching query when it identifies a specific disagreement with the question.

**Use evidence within the budget.** Each episode retains its own tool history. Identical checks reuse recorded observations. The public repair_hint supplies fixed suggestions after a check or execution of the exact draft. A targeted execute can inspect an uncertain field value. A separate local index built from 305 fitting TRAIN questions retrieves nine related, anonymized repair patterns to help prioritize operations such as grouping and sorting. The controller draws actual table and column names from the current schema.

**Check a proposed change.** The final stage can build each side of a condition separately, join tables along declared relationships and combine qualifying populations. It considers up to two distinct proposals using the remaining budget. A new proposal must match the public example before this stage adopts it. With insufficient evidence or budget, it returns the provisional SQL. The entire episode allows eight charged calls and one free submission.

**TRAIN example.** A question asks for the date and ID of claims with more than two settlements or the highest claimed amount. The old query compared payment amounts and payment dates. The repair counts settlement rows per claim and computes the maximum on the claims table. In an independent fixture, one low-value claim has three settlements, and two claims tie for the highest amount without any settlements. The expected answer contains all three. The repaired query returns those three rows.

## Controlled evaluation

The harness fitting panel used 305 TRAIN questions from 75 databases. The development and regression panels used 79 questions from 19 databases and 96 from 24, respectively. These panels are database-disjoint from fitting and have been used in earlier experiments. Validation served as a regression check before the final offline TEST run. The choice of controller was frozen before that run.

**Ablation 1. Which conditions can the controller represent?** The same provisional-answer pipeline, H65 weights and eight-call budget were used throughout. Each row retains the preceding capabilities. Results count actual final submissions passing all three instances.

| Controller | Fit / 305 | Development / 79 | Regression / 96 |
|---|---:|---:|---:|
| Preceding frozen controller | 252 | 73 | 85 |
| Add union, intersection and exclusion of qualifying groups | 254 | 73 | 85 |
| Add independently ranked or counted alternatives | 254 | 74 | 86 |
| Restrict a comparison to the class named in the question | 254 | 75 | 86 |
| Final field-binding and impossible-intersection guards | 254 | 75 | 86 |

On the 175 development and regression questions, the final stage checked five additional queries, adopted all five and gained three correct submissions with zero regressions. The three gains occurred in three databases. Across all three TRAIN panels, eleven independently specified fixtures cover the five gains. The last row tied the preceding row on correctness and saved one fitting-panel check. Both this controller and its immediate predecessor scored 195/240 on TEST.

**Ablation 2. What does live generation contribute?** With the final harness and the same public tools available, disabling live H65 generation yielded 73/79 and 84/96. Enabling it yielded 75/79 and 86/96. On matched questions, H65 added five correct submissions and lost one, for a net gain of four. The public hint tool remained available in both arms.

**Where repair still fails.** For the 14 remaining incorrect submissions on those two TRAIN panels, the queries already checked by the controller contained zero three-instance-correct answers. A separate TRAIN audit obtained all official hints and also found zero correct hints on those 14 questions. Changing only which of these queries is selected would therefore have recovered none of them. Other failure cases include choosing the wrong relationship role and confusing one row per entity with one row per distinct displayed value. Independently constructed data can distinguish a particular interpretation, while sparse public data can leave it unresolved.

## Model, cost and reproduction

**Model and training data.** The sole live model is Qwen/Qwen3-0.6B at revision `c1899de289a04d12100db370d81485cdf75e47ca`, with 596,049,920 base parameters and 1,146,880 unmerged adapter parameters, 597,196,800 in total. H65 was trained on 257 unique official TRAIN questions from 74 fitting databases. Targets comprised 196 repairs and 61 preserved queries. Only the A/B matrices in q_proj and v_proj were trained, with rank 8, alpha 16, seed 42 and 76 updates. The final harness experiment reused these weights. Training records, configuration, label provenance and the training log are in `training/`.

**Official runtime.** Offline Linux used four CPU threads, one prediction worker and the official scorer. Greedy non-thinking inference generated at most one completion per task, with a 384-new-token cap.

| Measured resource | Validation / 120 | TEST / 240 |
|---|---:|---:|
| Questions with a live generation | 98 | 182 |
| Generated tokens, total / maximum per completion | 2,184 / 83 | 4,781 / 384 |
| Mean charged tool calls per question | 4.425 | 4.6125 |
| Prediction / scoring wall time, seconds | 649.8 / 8.7 | 1,123.1 / 17.4 |
| Prediction / scoring CPU time, seconds | 2,297.1 / 32.5 | 3,958.5 / 66.8 |
| Peak prediction RSS, GiB | 4.61 | 4.68 |

**Untrusted inputs.** Questions, schema text, retrieved material, hints, generated text and database values can contain instructions or misleading SQL. The controller packages observations as data, constructs tool actions in code and passes SQL through read-only parsing and the official execution limits. Network access is disabled during inference. A misleading instruction can still induce a legal query with the wrong meaning.

**Reproduction.** Extract the source and adapter separately. Provision the pinned base snapshot and dependencies, then follow `REPRODUCE.md` using the unchanged official Starter. The entry is `method.py` with `create_agent(checkpoint=None)`. Set `MP3_BASE_MODEL` and `MP3_ADAPTER_DIR` to absolute local paths. The loader uses local safetensors and disables remote code. The archive contains the original predictions and full official scores in `outputs/`, with run statistics, TRAIN comparisons and model receipts in `evidence/`.

**Attribution.** Codex assisted with experimental design, implementation, verification and report preparation. The benchmark is the course's Spider-derived dataset. Distribution details and upstream acknowledgements appear in `NOTICE`.
