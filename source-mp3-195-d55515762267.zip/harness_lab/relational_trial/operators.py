"""Relational repairs grounded in public schema, question, example and the current query."""
import re

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.diagnosis_trial.compiler import (
    _base, _column, _edges, _mentions, _physical, _q, _render, _require, compile_diagnosis,
)
from harness_lab.h41.intent import by_name, primary, tokens
from harness_lab.h60.agent import sql_candidate
from harness_lab.h61.agent import comparable_sql
from harness_lab.h69.binding import _conjuncts
from mp3_sql.sqlite_tool import validate_sql
from submission.semantic_context import NUMBER_WORDS

NUM = r'(?:\d+|' + '|'.join(NUMBER_WORDS) + ')'


def threshold(question):
    hits = re.findall(r'\b(more than|at least) (' + NUM + r')\b', question.lower())
    if len(hits) != 1:
        return None
    op, val = hits[0]
    return ('>' if op == 'more than' else '>=', int(val) if val.isdecimal() else NUMBER_WORDS[val])


def classified(question):
    q = question.lower()
    if threshold(q):
        if (re.search(r'\b(all (those|these|their)|for those|for these|for each)\b', q)
                or ('?' in q.rstrip('?') and re.search(r'\b(those|these|their)\b', q))):
            return 'details'
        return 'qualified'
    if re.search(r"\b(without|does not have|do not have|has no|have no)\b", q):
        return 'absent'
    if re.search(r'\b(who|that have|that had|with at least one)\b', q):
        return 'exists'
    return None


def plain_projection(tree, scope):
    refs = [_physical(e.unalias(), scope) for e in tree.expressions]
    _require(refs and all(refs) and len({r[0] for r in refs}) == 1, 'one output entity required')
    return refs[0][0]


def bridge_details(row, tree, scope):
    # A count of related identities and an explicit request for those identities' attributes.
    q = row['question']
    cut = re.split(r'[?.!]|,', q, maxsplit=1)
    op, n = threshold(q)
    _require(len(cut) == 2 and not tree.args.get('where') and not tree.args.get('order')
             and not tree.args.get('distinct') and len(scope) == 1, 'unresolved conditions or detail relation')
    owner = plain_projection(tree, scope)
    schema = row['schema']
    first = tokens(re.split(r'\bmore than\b|\bat least\b', cut[0], flags=re.I)[0])
    entities = [t['name'] for t in schema if t['name'] != owner and _mentions(first, t['name'])]
    _require(len(entities) == 1 and _mentions(tokens(cut[1]), owner), 'group or output entity ambiguous')
    tail = re.split(r'\bmore than\b|\bat least\b', cut[0], flags=re.I)[-1]
    _require(_mentions(tokens(tail), owner), 'requested counted role differs from detail role')
    paths = [(a, b) for a in _edges(schema) for b in _edges(schema)
             if a[0][0] == b[0][0] and a[1][0] == entities[0] and b[1][0] == owner]
    _require(len(paths) == 1, 'no unique declared link table')
    (g, _), (d, p) = paths[0]
    out = ', '.join(_q('d')+'.'+_q(_physical(e.unalias(), scope)[1]) for e in tree.expressions)
    link, group, member = _q(g[0]), _q(g[1]), _q(d[1])
    return (f'SELECT {out} FROM {_q(owner)} AS d WHERE EXISTS (SELECT 1 FROM {link} AS l '
            f'WHERE l.{member} = d.{_q(p[1])} AND l.{group} IN (SELECT {group} FROM {link} '
            f'GROUP BY {group} HAVING COUNT(DISTINCT {member}) {op} {n}))')


def group_repair(row, mode):
    t, scope = _base(row['current_sql'], row['schema'])
    th = threshold(row['question'])
    _require(th and not any(t.args.get(k) for k in ('limit','offset','qualify','windows')),
             'unsupported group threshold or slicing')
    group, having = t.args.get('group'), t.args.get('having')
    _require(group and len(group.expressions) == 1 and having, 'single grouped count required')
    cond = having.this
    _require(isinstance(cond, exp.GT if th[0] == '>' else exp.GTE)
             and isinstance(cond.this, exp.Count) and isinstance(cond.expression, exp.Literal)
             and not cond.expression.is_string and cond.expression.this == str(th[1]), 'count threshold mismatch')
    groupcol = group.expressions[0]
    gr = _physical(groupcol, scope)
    _require(gr, 'unbound group key')
    owner = plain_projection(t, scope)
    if mode == 'qualified':
        key = primary(by_name(row['schema'], owner))
        _require(key and gr[0] == owner and len(scope) == 2 and insp_join(t,scope,row['schema']),
                 'missing entity key or cardinality evidence')
        alias = next(tb.alias_or_name for tb,tbl in scope.values() if tbl['name']==owner)
        # Replacing a display label by PK is safe only when the old group is one of the requested attributes.
        _require(any(_physical(e.unalias(),scope)==gr for e in t.expressions), 'unrelated grouped field')
        t.set('group', exp.Group(expressions=[_column(alias,key['name'])]))
        cols = row['example']['columns']
        if len(cols)==len(t.expressions)+1 and re.fullmatch(r'count\(\*\)',cols[-1],re.I):
            t.append('expressions',exp.Count(this=exp.Star()))
        return _render(t)
    if len(scope) == 1 and any(_physical(e.unalias(),scope) != gr for e in t.expressions):
        _require(not t.args.get('distinct') and not t.find(exp.Window), 'unresolved row multiplicity')
        inner = t.copy()
        inner.set('expressions',[groupcol.copy()])
        inner.set('order',None)
        t.set('group',None)
        t.set('having',None)
        return _render(t.where(groupcol.copy().isin(query=inner)))
    return bridge_details(row,t,scope)


def insp_join(tree,scope,schema):
    joins=tree.args.get('joins',[])
    if len(joins)!=1:
        return None
    j=joins[0]
    on=j.args.get('on')
    if j.side or j.method or j.kind not in ('','INNER') or not isinstance(on,exp.EQ):
        return None
    l,r=_physical(on.this,scope),_physical(on.expression,scope)
    if not l or not r or l[0]==r[0]:
        return None
    # Accept an existing, explicit same-name correlation even without a declared foreign key.
    if (l,r) in _edges(schema) or (r,l) in _edges(schema) or l[1].casefold()==r[1].casefold():
        return l,r
    return None


def absence(row):
    # Common NOT IN shape. A null in the lookup table must not suppress unrelated entities.
    tree=validate_sql(row['current_sql'])
    _require(isinstance(tree,exp.Select) and len(list(tree.find_all(exp.Select)))==2, 'not a simple anti-membership query')
    where=tree.args.get('where')
    pred=where.this if where else None
    _require(isinstance(pred,exp.Not) and isinstance(pred.this,exp.In) and isinstance(pred.this.this,exp.Column),
             'requires an explicit anti-membership condition')
    inner=pred.this.args['query'].this
    _require(isinstance(inner,exp.Select) and len(inner.expressions)==1 and isinstance(inner.expressions[0],exp.Column)
             and not any(inner.args.get(k) for k in ('limit','offset','where','group','having','joins','order','with'))
             and not tree.args.get('joins') and isinstance(tree.args['from'].this,exp.Table)
             and isinstance(inner.args['from'].this,exp.Table), 'unsupported nested scope or filter')
    ot,it=tree.args['from'].this,inner.args['from'].this
    outer_ref=(ot.name.casefold(),pred.this.this.name.casefold())
    inner_ref=(it.name.casefold(),inner.expressions[0].name.casefold())
    _require(any(tuple(x.casefold() for x in c)==inner_ref and tuple(x.casefold() for x in p)==outer_ref
                 for c,p in _edges(row['schema'])), 'anti-join keys lack schema support')
    _require(ot.alias_or_name.casefold()!=it.alias_or_name.casefold(),'alias shadowing')
    inner.set('distinct',None)
    inner.set('expressions',[exp.Literal.number(1)])
    inner=inner.where(exp.EQ(this=_column(it.alias_or_name,inner_ref[1]),expression=_column(ot.alias_or_name,outer_ref[1])))
    tree.set('where',exp.Where(this=exp.Not(this=exp.Exists(this=inner))))
    return _render(tree)


def membership(row,mode,old_diagnosis):
    if mode=='absent':
        return absence(row)
    sql=row['current_sql']
    if mode=='all' and old_diagnosis.get('action')=='edit':
        sql,reason=compile_diagnosis(old_diagnosis,row['schema'],sql)
        _require(sql,reason)
    t,scope=_base(sql,row['schema'])
    owner=plain_projection(t,scope)
    _require(insp_join(t,scope,row['schema']) and not any(t.args.get(k) for k in ('group','having','limit','offset','windows')),
             'one grounded relation without aggregation required')
    _require(not t.args.get('distinct'), 'distinct output values have different semantics')
    alias,tbl=next((tb.alias_or_name,tb) for tb,sc in scope.values() if sc['name']==owner)
    other=next(tb for tb,sc in scope.values() if sc['name']!=owner)
    # Ground every retained clause while the original aliases are still in scope.
    for col in t.find_all(exp.Column):
        ref=_physical(col,scope)
        _require(ref, 'ambiguous column')
        target=next(tb.alias_or_name for tb,sc in scope.values() if sc['name']==ref[0])
        col.set('table',exp.to_identifier(target,quoted=True))
    if t.args.get('order'):
        _require(all(c.table.casefold()==alias.casefold() for c in t.args['order'].find_all(exp.Column)),
                 'ordering depends on detail rows')
    outer,inner=[],[]
    for term in _conjuncts(t.args['where'].this) if t.args.get('where') else []:
        aliases={c.table.casefold() for c in term.find_all(exp.Column)}
        _require(len(aliases)==1,'predicate mixes populations')
        (outer if aliases=={alias.casefold()} else inner).append(term.copy())
    on=t.args['joins'][0].args['on'].copy()
    if mode=='all':
        _require(not inner,'removing relation would discard a filter')
    else:
        sub=exp.select('1').from_(other.copy()).where(on,*inner)
        outer.append(exp.Exists(this=sub))
    t.set('from',exp.From(this=tbl.copy()))
    t.set('joins',[])
    t.set('where',exp.Where(this=exp.and_(*outer)) if outer else None)
    return _render(t)


def propose(row, mode, old):
    if mode:
        try:
            sql=group_repair(row,mode) if mode in ('qualified','details') else membership(row,mode,old['diagnosis'])
            sql=sql_candidate(sql,row['schema'])
            if comparable_sql(sql)!=comparable_sql(row['current_sql']):
                return sql,mode
        except (ValueError,KeyError,TypeError,SqlglotError,RecursionError) as exc:
            return old['candidate'],f'{mode}: {exc}'
    return old['candidate'],'prior'
