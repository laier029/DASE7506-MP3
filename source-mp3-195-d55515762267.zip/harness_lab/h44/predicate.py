"""Question-grounded boundary worlds for a single explicit numeric row filter."""
import math
import operator
import re

from sqlglot import exp

from harness_lab.h33.controller import _query
from harness_lab.h41.intent import choose, entity_row, numeric_col, projection, text_col, tokens
from submission.semantic_context import NUMBER_WORDS, QUANTITY_OPERATORS


TEST = {'<':operator.lt, '<=':operator.le, '>':operator.gt, '>=':operator.ge, '=':operator.eq, '!=':operator.ne}
REVERSE = {'<':'>', '<=':'>=', '>':'<', '>=':'<=', '=':'=', '!=':'!='}
NEGATE = {'<':'>=', '<=':'>', '>':'<=', '>=':'<', '=':'!=', '!=':'='}
COMPARISON = {exp.LT:'<', exp.LTE:'<=', exp.GT:'>', exp.GTE:'>=', exp.EQ:'=', exp.NEQ:'!='}
WORDS = {**QUANTITY_OPERATORS, 'greater than':'>', 'above':'>', 'higher than':'>', 'exceeds':'>',
         'below':'<', 'under':'<', 'lower than':'<', 'equal to':'=', 'equals':'=', 'no less than':'>=',
         'no fewer than':'>=', 'no higher than':'<=', 'no lower than':'>=', 'does not exceed':'<='}
PHRASE = r'[a-z][\w-]*(?: [a-z][\w-]*){0,6}?'
NUMBER = r'-?(?:\d+(?:\.\d+)?|\.\d+)|' + '|'.join(NUMBER_WORDS)
BOUND = '|'.join(re.escape(word) for word in sorted(WORDS, key=len, reverse=True))
LEAD = r'(?:list|show|give|find|return|select|what (?:are|is)|which (?:are|is)) (?:me )?(?:all )?(?:the )?'
WHERE = (rf'(?:whose|where (?:the )?|with (?:an? |the )?|having (?:an? |the )?) *'
         rf'(?P<measure>{PHRASE}) (?:(?:that |which )?(?:is|are|was|were) )?(?P<neg>not )?(?P<op>{BOUND}) (?P<n>{NUMBER})')
SUBJECT = LEAD + rf'(?P<out>[\w, -]+?) (?:of|for|from) (?:all )?(?:the )?(?P<table>{PHRASE}) '
QUESTION = re.compile(SUBJECT + WHERE, re.I)
# An unqualified numeric age conventionally counts years. Other units require a
# matching unit in the column name. No conversion between units is inferred.
UNITS = {'year': ('age', 'old'), 'month': ('age', 'old'), 'kilogram': ('weight', 'in weight')}
UNIT_QUESTION = re.compile(SUBJECT + rf'(?:who|which|that) (?:is|are|was|were) (?P<neg>not )?'
                           rf'(?:(?P<op>{BOUND}) )?(?P<n>{NUMBER}) (?P<unit>{"|".join(UNITS)})s? '
                           rf'(?P<attribute>old|in weight)', re.I)


def unit_measure(table, unit, attribute):
    dimension, wording = UNITS[unit]
    if attribute != wording:
        return None
    options = [c for c in table['columns'] if dimension in tokens(c['name'])]
    if len(options) != 1 or not numeric_col(options[0]):
        return None
    name = tokens(options[0]['name'])
    entity = tokens(table['name'])
    if name[:len(entity)] == entity:
        name = name[len(entity):]
    if name in {(dimension, unit), (dimension, 'in', unit), (unit, dimension)}:
        return options[0]
    if (dimension, unit, name) == ('age', 'year', ('age',)):
        return options[0]
    return None


def number(text):
    if text in NUMBER_WORDS:
        return NUMBER_WORDS[text]
    value = float(text)
    if not math.isfinite(value) or abs(value) > 1_000_000_000:
        raise ValueError('Unbounded numeric literal')
    return int(value) if value.is_integer() else value


def column(node, table):
    if (not isinstance(node, exp.Column) or not isinstance(node.this, exp.Identifier) or node.db or node.catalog or
            node.table and node.table.casefold() != table.alias_or_name.casefold()):
        raise ValueError('A direct column from the one table is required')
    return node.name.casefold()


def predicate(node, table):
    if isinstance(node, exp.Paren):
        return predicate(node.this, table)
    if isinstance(node, exp.Not):
        col, op, value = predicate(node.this, table)
        return col, NEGATE[op], value
    op = COMPARISON.get(type(node))
    if op is None:
        raise ValueError('Unsupported predicate')
    left, right = node.this, node.expression
    if isinstance(right, exp.Column):
        left, right, op = right, left, REVERSE[op]
    sign = -1 if isinstance(right, exp.Neg) else 1
    if sign == -1:
        right = right.this
    if not isinstance(right, exp.Literal) or not right.is_number:
        raise ValueError('A numeric literal is required')
    return column(left, table), op, sign * number(right.this)


def shape(sql):
    tree = _query(sql)
    if not isinstance(tree, exp.Select) or any(v for k,v in tree.args.items()
            if k not in {'expressions','from','where','distinct'}):
        raise ValueError('A plain single-table SELECT is required')
    source = tree.args.get('from')
    table = source.this if source is not None else None
    if (not isinstance(table, exp.Table) or not isinstance(table.this, exp.Identifier) or
            any(v for k,v in table.args.items() if k not in {'this','alias'}) or
            (table.args.get('alias') and table.args['alias'].args.get('columns')) or
            (tree.args.get('distinct') and tree.args['distinct'].args.get('on'))):
        raise ValueError('Unsupported source or DISTINCT clause')
    outputs = tuple(column(p.unalias(), table) for p in tree.expressions)
    where = tree.args.get('where')
    return (table.name.casefold(), outputs, bool(tree.args.get('distinct'))), predicate(where.this, table) if where else None


def predicate_fixtures(question, schema, incumbent, proposed):
    """Return the same worlds when the incumbent and proposed query exchange places."""
    if not isinstance(question, str) or not isinstance(schema, list):
        return []
    sentence = ' '.join(question.casefold().split()).rstrip('?.!').strip()
    parsed = QUESTION.fullmatch(sentence) or UNIT_QUESTION.fullmatch(sentence)
    if not parsed:
        return []
    table = choose(schema, parsed['table'])
    if table is None:
        return []
    implicit = parsed.re is UNIT_QUESTION
    measure = unit_measure(table, parsed['unit'], parsed['attribute']) if implicit else projection(table, parsed['measure'])
    output_names = re.split(r'\s*,\s*(?:and )?|\s+and\s+', parsed['out'])
    outputs = [projection(table, re.sub(r'^the ', '', name)) for name in output_names]
    if not numeric_col(measure) or not outputs or not all(text_col(col) or numeric_col(col) for col in outputs):
        return []
    try:
        x, a = shape(incumbent)
        y, b = shape(proposed)
        threshold = number(parsed['n'])
    except (ValueError, RecursionError, OverflowError):
        return []
    measure_name = measure['name']
    if implicit and threshold < 0:
        return []
    if (x != y or x[:2] != (table['name'].casefold(), tuple(c['name'].casefold() for c in outputs)) or
            a == b or any(pred and pred[0] != measure_name.casefold() for pred in (a,b))):
        return []
    if any(fk['from'].casefold() == measure_name.casefold() for fk in table['foreign_keys']):
        return []
    op = WORDS[parsed['op']] if parsed['op'] is not None else '='
    if parsed['neg']:
        op = NEGATE[op]
    compare = TEST[op]
    cutoffs = sorted({threshold, *(p[2] for p in (a,b) if p)})
    if 'INT' in measure['type'].upper():
        values = sorted({v for t in cutoffs for v in (math.floor(t)-1, math.floor(t), math.ceil(t), math.ceil(t)+1)})
    else:
        values = sorted({*(v for t in cutoffs for v in (t-1,t,t+1)), *((l+r)/2 for l,r in zip(cutoffs,cutoffs[1:]))})
    if implicit:
        values = [v for v in values if v >= 0]
    # A semantically equivalent spelling has no separating witness on this numeric domain.
    if not any((not a or TEST[a[1]](v,a[2])) != (not b or TEST[b[1]](v,b[2])) for v in values):
        return []
    fixtures = []
    for sequence in (values, list(reversed(values))):
        rows, expected = [], []
        for i, value in enumerate(sequence, 1):
            row = entity_row(table, i)
            if row is None:
                return []
            row[measure_name] = value
            for col in outputs:
                row.setdefault(col['name'], f'Item-{i}' if text_col(col) else i)
            rows.append(row)
            if compare(value, threshold):
                expected.append([row[c['name']] for c in outputs])
        fixtures.append({'family':'numeric_predicate_boundary','reason':f'The request selects rows where {measure_name} {op} {threshold}.',
                         'rows':{table['name']:rows},'arity':len(outputs),'expected':expected})
    return fixtures
