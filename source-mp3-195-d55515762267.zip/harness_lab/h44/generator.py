"""Extend the frozen fixture designer on previously unsupported questions."""
from harness_lab.h41.relational import design_relational
from harness_lab.h44.join_count import join_count_fixtures
from harness_lab.h44.lookup import lookup_fixtures
from harness_lab.h44.predicate import predicate_fixtures


def design_fixtures(question, schema, incumbent, proposed):
    previous = design_relational(question, schema)
    if previous:
        return previous
    for design in (predicate_fixtures, join_count_fixtures, lookup_fixtures):
        fixtures = design(question, schema, incumbent, proposed)
        if fixtures:
            return fixtures
    return []
