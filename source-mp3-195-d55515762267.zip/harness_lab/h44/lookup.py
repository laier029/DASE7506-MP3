"""Exercise a multi-match entity lookup when a scalar subquery replaces a join."""
import re

from sqlglot import exp

from harness_lab.h41 import intent
from mp3_sql.sqlite_tool import validate_sql


def simple_select(node):
    return (isinstance(node, exp.Select) and len(node.expressions) == 1
            and isinstance(node.expressions[0], exp.Column)
            and isinstance(node.args.get("from"), exp.From)
            and isinstance(node.args["from"].this, exp.Table)
            and not any(v for k, v in node.args.items() if k not in {"expressions", "from", "joins", "where"}))


def column_of(node, table):
    return (isinstance(node, exp.Column)
            and (not node.table or node.table.casefold() == table.alias_or_name.casefold()))


def same_filters(tree, parent_ref, desired):
    if not isinstance(tree, exp.Where):
        return False
    terms = tree.this.flatten() if isinstance(tree.this, exp.And) else [tree.this]
    actual = set()
    for term in terms:
        if not isinstance(term, exp.EQ):
            return False
        col, val = term.this, term.expression
        if isinstance(col, exp.Literal):
            col, val = val, col
        if not column_of(col, parent_ref) or not isinstance(val, exp.Literal) or not val.is_string:
            return False
        actual.add((col.name.casefold(), val.this))
    return actual == {(key.casefold(), value) for key, value in desired.items()}


def question_filters(words, table):
    conditions = {}
    for phrase in re.split(r"\s+and\s+", words, flags=re.I):
        m = re.fullmatch(r'(?:the\s+)?([A-Za-z_ ]+?)\s+(?:(?:is|equals)\s+)?'
                         r'(?:"([^"]+)"|\'([^\']+)\'|([\w-]+))', phrase.strip(), re.I)
        if not m:
            return None
        col = intent.choose(table["columns"], m[1].strip())
        value = next(x for x in m.groups()[1:] if x is not None)
        if not intent.text_col(col) or col["pk"] or col["name"] in conditions or len(value) > 80:
            return None
        conditions[col["name"]] = value
    return conditions


def projected_values(col):
    if "DATE" in col["type"].upper() or "TIME" in col["type"].upper():
        return [f"2001-04-0{i}" for i in range(1, 4)]
    if intent.text_col(col) or intent.numeric_col(col):
        return [intent.key_value(col, i) for i in range(1, 4)]
    return None


def lookup_fixtures(question, schema, incumbent, proposed):
    m = re.fullmatch(r"(?:what are|list|show|find|return)\s+(?:all\s+)?(?:the\s+)?"
                     r"(?P<output>[\w ]+?)\s+for\s+(?:all\s+)?(?:the\s+)?(?P<parent>[\w ]+?)"
                     r"\s+with\s+(?P<filters>.+?)[?.!]?", question.strip(), re.I)
    if not m or not m["parent"].casefold().endswith("s"):
        return []
    parent = intent.choose(schema, m["parent"])
    if not parent:
        return []
    desired = question_filters(m["filters"], parent)
    pk = intent.primary(parent)
    if not desired or not pk:
        return []

    try:
        selects = [validate_sql(s) for s in (incumbent, proposed)]
    except ValueError:
        return []
    if not all(simple_select(q) for q in selects):
        return []
    joined = intent.unique([q for q in selects if len(q.args.get("joins", [])) == 1])
    scalar = intent.unique([q for q in selects if not q.args.get("joins")])
    if joined is None or scalar is None:
        return []

    outer = scalar.args["from"].this
    child = intent.by_name(schema, outer.name)
    if not child or child is parent:
        return []
    output = intent.projection(child, m["output"])
    # The wording must identify the output even if the two queries agree on the wrong table.
    eligible_sources = [t for t in schema if t is parent or any(
        link["table"].casefold() == parent["name"].casefold() for link in t["foreign_keys"])]
    if [t for t in eligible_sources if intent.projection(t, m["output"])] != [child]:
        return []
    links = [fk for fk in child["foreign_keys"]
             if fk["table"].casefold() == parent["name"].casefold() and fk["to"].casefold() == pk["name"].casefold()]
    fk = intent.unique(links)
    if not output or not fk or output["pk"] or output["name"] == fk["from"]:
        return []
    values = projected_values(output)
    if not values:
        return []

    join = joined.args["joins"][0]
    refs = [joined.args["from"].this, join.this]
    if not all(isinstance(t, exp.Table) for t in refs) or any(
            v for k, v in join.args.items() if k not in {"this", "on", "kind"}):
        return []
    p = intent.unique([t for t in refs if t.name.casefold() == parent["name"].casefold()])
    c = intent.unique([t for t in refs if t.name.casefold() == child["name"].casefold()])
    on = join.args.get("on")
    if p is None or c is None or join.kind not in {"", "INNER"} or not isinstance(on, exp.EQ):
        return []
    edge = {(node.table.casefold(), node.name.casefold()) for node in (on.this, on.expression)
            if isinstance(node, exp.Column)}
    if edge != {(p.alias_or_name.casefold(), pk["name"].casefold()), (c.alias_or_name.casefold(), fk["from"].casefold())}:
        return []
    if not same_filters(joined.args.get("where"), p, desired):
        return []
    if any(not column_of(q.expressions[0], ref) or q.expressions[0].name.casefold() != output["name"].casefold()
           for q, ref in ((joined, c), (scalar, outer))):
        return []
    where = scalar.args.get("where")
    if not where or not isinstance(where.this, exp.EQ):
        return []
    ref, sub = where.this.this, where.this.expression
    if isinstance(ref, exp.Subquery):
        ref, sub = sub, ref
    if not column_of(ref, outer) or ref.name.casefold() != fk["from"].casefold() or not isinstance(sub, exp.Subquery):
        return []
    inner = sub.this
    if not simple_select(inner) or inner.args.get("joins"):
        return []
    src = inner.args["from"].this
    if (src.name.casefold() != parent["name"].casefold() or not column_of(inner.expressions[0], src)
            or inner.expressions[0].name.casefold() != pk["name"].casefold()
            or not same_filters(inner.args.get("where"), src, desired)):
        return []

    families = []
    for unmatched in (0, 2):
        parents, children = [], []
        for n, value in enumerate(values):
            record, detail = intent.entity_row(parent, n + 1), intent.entity_row(child, n + 1)
            if not record or detail is None:
                return []
            record.update(desired)
            if n == unmatched:
                field = next(iter(desired))
                record[field] = "Other-" + desired[field]
            parents.append(record)
            detail.update({fk["from"]: record[pk["name"]], output["name"]: value})
            children.append(detail)
        allowed = {r[pk["name"]] for r in parents if all(r[k] == v for k, v in desired.items())}
        expected = [r[output["name"]] for r in children if r[fk["from"]] in allowed]
        families.append(intent.world("multiple_matching_parents", "All parent records meeting the named attributes "
                                     "contribute their linked rows, even when the attributes repeat.",
                                     {parent["name"]: parents, child["name"]: children}, expected))
    return families
