"""Witness a change in population when COUNT(DISTINCT property) gains a child join."""
import re

from sqlglot import exp

from harness_lab.h41 import intent
from mp3_sql.sqlite_tool import validate_sql


_PHRASE = r"[a-z][a-z_]*(?: [a-z][a-z_]*){0,5}?"
_QUESTION = re.compile(
    rf"(?:how many|what is the number of|count(?: the number of| the)?) "
    rf"(?:(?:different|distinct|unique) (?:kinds? of |types? of )?|(?:kinds|types) of )"
    rf"(?P<attr>{_PHRASE}) (?:are supported by|are (?:there )?in|are there among|"
    rf"among|across|in|of) (?:all (?:the )?|the )?(?P<owner>{_PHRASE})", re.I,
)


def only(node, fields):
    return all(key in fields or not value for key, value in node.args.items())


def binding(column, scope):
    """Resolve a qualified or uniquely unqualified column against this SELECT's tables."""
    column = column.unnest()
    if not isinstance(column, exp.Column) or not only(column, {"this", "table"}):
        return None
    found = []
    for alias, table in scope.items():
        if column.table and column.table.casefold() != alias:
            continue
        col = intent.by_name(table["columns"], column.name)
        if col:
            found.append((table["name"], col["name"]))
    return intent.unique(found)


def count_shape(sql, schema):
    try:
        tree = validate_sql(sql)
    except ValueError:
        return None
    if not isinstance(tree, exp.Select) or not only(tree, {"expressions", "from", "joins"}):
        return None
    source, joins = tree.args.get("from"), tree.args.get("joins", [])
    if not source or len(joins) > 1 or len(tree.expressions) != 1:
        return None
    count = tree.expressions[0].unalias()
    if not isinstance(count, exp.Count) or not only(count, {"this", "big_int"}):
        return None
    distinct = count.this
    if not isinstance(distinct, exp.Distinct) or not only(distinct, {"expressions"}) or len(distinct.expressions) != 1:
        return None
    scope = {}
    for ref in [source.this, *(join.this for join in joins)]:
        if (not isinstance(ref, exp.Table) or not isinstance(ref.this, exp.Identifier)
                or not only(ref, {"this", "alias"}) or
                (ref.args.get("alias") and not only(ref.args["alias"], {"this"}))):
            return None
        table = intent.by_name(schema, ref.name)
        alias = ref.alias_or_name.casefold()
        if not table or alias in scope or table in scope.values():
            return None
        scope[alias] = table
    target = binding(distinct.expressions[0], scope)
    if not target:
        return None
    if not joins:
        return target, None
    join = joins[0]
    eq = join.args.get("on")
    if (not only(join, {"this", "kind", "on"}) or join.kind not in ("", "INNER")
            or not isinstance(eq, exp.EQ)):
        return None
    ends = [binding(expr, scope) for expr in (eq.left, eq.right)]
    if not all(ends) or ends[0][0] == ends[1][0]:
        return None
    return target, frozenset(ends)


def join_count_fixtures(question, schema, incumbent, proposed):
    """Return two independent expected counts, or abstain when the question or edge is ambiguous."""
    m = _QUESTION.fullmatch(" ".join(question.split()).strip(" .?!"))
    if not m:
        return []
    owner = intent.choose(schema, m["owner"])
    attr = intent.projection(owner, m["attr"]) if owner else None
    if not attr or not (intent.text_col(attr) or intent.numeric_col(attr)) or owner["foreign_keys"]:
        return []
    # A separately named entity could turn "supported by" into a relationship query.
    if any(intent.tokens(t["name"]) == intent.tokens(m["attr"]) for t in schema):
        return []
    pk = intent.primary(owner)
    if not pk or intent.key_value(pk, 1) is None:
        return []
    target = (owner["name"], attr["name"])
    shapes = [count_shape(sql, schema) for sql in (incumbent, proposed)]
    if any(s is None or s[0] != target for s in shapes):
        return []
    edges = [s[1] for s in shapes if s[1] is not None]
    parent_end = (owner["name"], pk["name"])
    if len(edges) != 1 or parent_end not in edges[0]:
        return []
    child_name, child_key = next(iter(edges[0] - {parent_end}))
    child = intent.by_name(schema, child_name)
    links = [fk for fk in child["foreign_keys"] if fk["table"].casefold() == owner["name"].casefold()]
    link = intent.unique(links)
    if (not link or any(not fk["to"] for fk in child["foreign_keys"]) or link["to"].casefold() != pk["name"].casefold()
            or link["from"].casefold() != child_key.casefold() or
            len({fk["from"].casefold() for fk in child["foreign_keys"]}) != len(child["foreign_keys"])):
        return []
    child_pk = intent.primary(child)
    if child_pk and child_pk["name"] == child_key:
        return []  # These witnesses need to create two children for one parent.

    worlds = []
    for values, children in [((1, 1, 2, 3), (2, 1, 0, 0)), ((1, 2, 2, 2), (0, 0, 1, 2))]:
        rows = {owner["name"]: []}
        # Reuse the constraint-aware FK fixture builder; the temporary count is never a schema column.
        detail_count = object()
        for i, (value, n) in enumerate(zip(values, children), 1):
            item = intent.entity_row(owner, i)
            if attr != pk:
                item[attr["name"]] = intent.key_value(attr, value)
            item[detail_count] = n
            rows[owner["name"]].append(item)
        if not intent.add_count_details(schema, owner, child_name, rows, {"name":detail_count}):
            return []
        for item in rows[owner["name"]]:
            del item[detail_count]
        expected = len({item[attr["name"]] for item in rows[owner["name"]]})
        worlds.append(intent.world("join_count_distinct", "Count the different values of the named property "
                                   "across all requested entities, including those without a child row.", rows, [expected]))
    return worlds
