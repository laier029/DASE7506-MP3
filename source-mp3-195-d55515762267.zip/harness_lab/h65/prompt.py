"""One training and inference contract for an independent reading and a SQL repair."""
import json

from harness_lab.h60.agent import messages as first_messages


INTENT_CAP = 96
SQL_CAP = 384
INTENT_FIELDS = (("unit","Unit"),("relationship","Relationship"),("retain","Population"),("conditions","Constraints"))
INTENT_SYSTEM = (
    "Read the question independently using the SQLite schema. Give four short English lines. "
    "Unit: what one result row represents. Relationship: which relationship or role is requested. "
    "Population: which objects to include, including whether a related record must exist. "
    "Constraints: what conditions, aggregation or order the question explicitly requires. "
    "Use unknown for information the question does not establish. Do not write SQL."
)


def intent_messages(question, schema):
    return [{"role":"system","content":INTENT_SYSTEM},
            {"role":"user","content":json.dumps({"question":question,"schema":schema},ensure_ascii=False,separators=(",",":"))}]


def format_intent(intent):
    return "\n".join(f"{label}: {intent[key]}" for key,label in INTENT_FIELDS)


def repair_messages(question,schema,original_sql,original_check,example,ordered,intent=None):
    turns = first_messages(question,schema,original_sql,original_check,example,ordered)
    if intent:
        obj = json.loads(turns[1]["content"])
        obj["semantic_reading"] = intent
        turns[1]["content"] = json.dumps(obj,ensure_ascii=False,separators=(",",":"))
    return turns
