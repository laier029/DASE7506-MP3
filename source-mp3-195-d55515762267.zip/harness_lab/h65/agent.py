"""V16 incumbent, an independent SQL proposer and the unchanged H61 judge."""
import json
import os
from pathlib import Path
import re

from harness_lab.h61.agent import JointAgent, program
from harness_lab.h60.agent import checked, matched, shared_model
from harness_lab.h65.prompt import INTENT_CAP, SQL_CAP, repair_messages, intent_messages


QUESTION_RISKS = {
    "role":r"\b(affirmative|negative side|authori[sz]e\w*|approv\w*|supervis\w*|sender|recipient|home team|away team)\b",
    "unit":r"\b(distinct|different|unique|per|each|how many|number of)\b",
    "existence":r"\b(without|never|no|none|any|either|both|at least|at most|not|except|even if)\b",
    "universal":r"\b(all|every|only)\b"}
SQL_RISK = re.compile(r"\b(?:distinct|exists|except|intersect|group\s+by|having)\b", re.I)


def risks(question, incumbent, check):
    flags = []
    if not matched(check):
        flags.append("public_mismatch")
    elif check["row_count"] == 0:
        flags.append("public_empty")
    flags.extend(k for k,v in QUESTION_RISKS.items() if re.search(v,question,re.I))
    if SQL_RISK.search(incumbent):
        flags.append("sql_group_or_existence")
    return flags


class HybridAgent(JointAgent):
    def __init__(self, model, use_reading=False):
        super().__init__(program(), self, "verified")
        self.backend = model
        self.use_reading = use_reading
        self.intent_route = []
        self.intent_generation = None
        self.intent_text = None
        self.remaining = 0

    def act(self, obs):
        self.current_history = obs["history"]
        self.remaining = obs["remaining"]
        return super().act(obs)

    def dialog(self, turns, cap):
        ctx = json.loads(turns[1]["content"])
        self.intent_route = risks(ctx["question"], self.v16_sql, checked(self.current_history,self.v16_sql))
        if not self.remaining:
            return {"status":"budget_exhausted","text":"","raw_text":"","truncated":False,
                    "new_tokens":0,"seconds":0.0,"messages":turns}
        if self.use_reading and self.intent_route:
            self.intent_generation = self.backend.dialog(intent_messages(ctx["question"],ctx["schema"]),INTENT_CAP)
            reading = self.intent_generation
            if reading["status"] == "generated" and not reading["truncated"] and reading["text"].strip():
                self.intent_text = reading["text"].strip()
        if self.intent_text:
            turns = repair_messages(ctx["question"],ctx["schema"],ctx["original_sql"],ctx["original_check"],
                                    ctx["expected_example"],ctx["ordered"],self.intent_text)
        return self.backend.dialog(turns, SQL_CAP)


def create_agent(checkpoint=None):
    cfg = json.loads(Path(checkpoint).read_text()) if checkpoint else {}
    adapter = os.environ.get("MP3_ADAPTER_DIR") or cfg.get("adapter")
    if adapter and not Path(adapter).is_absolute() and checkpoint:
        adapter = (Path(checkpoint).parent / adapter).resolve()
    return HybridAgent(shared_model(str(adapter) if adapter else None),cfg.get("use_reading",False))
