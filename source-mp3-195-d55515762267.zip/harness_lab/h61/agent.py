"""Combine the complete V16 trajectory with one independent H60 SQL proposal."""
import json
from pathlib import Path
import time

# Resolve the shared submission package before the historical V16 loader prepends its own directory.
from harness_lab.h61.judge import judge
from agent_v16.submission import SqlRepairAgent, load_config
from harness_lab.h60.agent import CAP, checked, matched, messages, shared_model, sql_candidate
from mp3_sql.sqlite_tool import validate_sql

ROOT = Path(__file__).resolve().parents[2]
ADAPTER = ROOT / "outputs/h60-model-first/train/adapter"
POLICIES = ("v16-priority", "model-priority", "verified")


def comparable_sql(sql):
    try:
        return validate_sql(sql).sql(dialect="sqlite", normalize=True, comments=False)
    except (ValueError, RecursionError):
        return sql


class V16WithoutLogs(SqlRepairAgent):
    def _log(self, record):
        pass


def program(log_dir=None):
    cfg = load_config()
    if log_dir is None:
        return V16WithoutLogs(cfg)
    cfg["log_dir"] = str(log_dir)
    return SqlRepairAgent(cfg)


class JointAgent:
    def __init__(self, program, model, policy="verified"):
        if policy not in POLICIES:
            raise ValueError(f"Unknown candidate priority: {policy}")
        self.program = program
        self.model = model
        self.policy = policy
        self.v16_sql = None
        self.v16_calls = 0
        self.generation = None
        self.model_sql = None
        self.error = None
        self.record = None

    def act(self, obs):
        if self.v16_sql is None:
            action = self.program.act(obs)
            if action["tool"] != "submit":
                return action
            self.v16_sql = action["sql"]
            self.v16_calls = len(obs["history"])

        history = obs["history"]
        schema = next((e["observation"] for e in history if e["tool"] == "schema"), None)
        original = obs["issue_sql"]
        original_check = checked(history, original)
        a = checked(history, self.v16_sql)
        if a is None and obs["remaining"]:
            return {"tool":"check", "sql":self.v16_sql}
        if schema is None and obs["remaining"]:
            return {"tool":"schema"}
        if original_check is None and obs["remaining"]:
            return {"tool":"check", "sql":original}
        if self.generation is None and schema is not None and original_check is not None:
            turns = messages(obs["task"]["question"], schema, original, original_check,
                             obs["example"], obs["ordered"])
            self.generation = self.model.dialog(turns, cap=CAP)
            if self.generation["truncated"] or self.generation["status"] != "generated":
                self.error = "Incomplete model output"
            else:
                try:
                    self.model_sql = sql_candidate(self.generation["text"], schema)
                except (ValueError, RecursionError) as exc:
                    self.error = str(exc)

        b = checked(history, self.model_sql) if self.model_sql else None
        if self.model_sql and b is None and obs["remaining"]:
            return {"tool":"check", "sql":self.model_sql}
        choices = dict.fromkeys(POLICIES, "v16")
        evidence = {"choice":"abstain", "reason":"no_public_disagreement"}
        seconds = 0.
        if self.model_sql is None:
            status = "invalid_model" if self.generation is not None else "missing_check"
        elif a is None or b is None:
            status = "missing_check"
        elif comparable_sql(self.model_sql) == comparable_sql(self.v16_sql):
            status = "same_sql"
        elif matched(a) and matched(b):
            status = "both_match"
            choices["model-priority"] = "model"
            if self.policy == "verified":
                start = time.perf_counter()
                evidence = judge(obs["task"]["question"], schema, self.v16_sql, self.model_sql, obs["ordered"])
                seconds = time.perf_counter() - start
                if evidence["choice"] not in ("model", "v16", "abstain"):
                    raise ValueError("Unexpected witness verdict")
                if evidence["choice"] == "model":
                    choices["verified"] = "model"
        elif matched(b):
            status = "only_model_match"
            choices = dict.fromkeys(POLICIES, "model")
        elif matched(a):
            status = "only_v16_match"
        else:
            status = "neither_match"

        selected = {p:self.model_sql if choice=="model" else self.v16_sql for p,choice in choices.items()}
        self.record = {"id":obs["task"]["id"], "question":obs["task"]["question"], "original_sql":original,
                       "v16_sql":self.v16_sql, "model_sql":self.model_sql, "v16_check":a, "model_check":b,
                       "original_check":original_check, "trace_v16_calls":self.v16_calls, "tool_calls":len(history),
                       "attempted_generation":self.generation is not None, "candidate_error":self.error,
                       "status":status, "judge":evidence, "judge_seconds":seconds, "choices":choices, "selected":selected}
        return {"tool":"submit", "sql":selected[self.policy]}


def create_agent(checkpoint=None):
    path = Path(checkpoint).resolve() if checkpoint else None
    cfg = json.loads(path.read_text()) if path else {}
    base = path.parent if path else ROOT
    adapter = (base / cfg.get("adapter", ADAPTER)).resolve()
    log_dir = (base / cfg["log_dir"]).resolve() if cfg.get("log_dir") else None
    return JointAgent(program(log_dir), shared_model(str(adapter)), cfg.get("policy", "verified"))
