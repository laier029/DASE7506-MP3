"""Build bounded, question-grounded counterexamples using only the public schema."""
import re
from collections import Counter, defaultdict
from contextlib import closing
import sqlite3

from sqlglot import exp

from harness_lab.h41 import intent
from harness_lab.h41.verifier import matches
from harness_lab.h41.world import FUNCTIONS, compare_world, filler, query, quote
from harness_lab.h44.generator import design_fixtures
from mp3_sql.sqlite_tool import validate_sql


WORDS = r"[a-z][a-z_]*(?: [a-z][a-z_]*){0,5}?"
LEAD = r"(?:(?:list|show|give|find|return|select)(?: me)?|what (?:are|is)|which (?:are|is)) (?:all )?(?:the )?"
DISTINCT = re.compile(LEAD + rf"(?:distinct|different|unique) (?P<field>{WORDS}) (?:of|in|from|among) (?:the )?(?P<table>{WORDS})", re.I)
MODE = re.compile(LEAD + rf"most (?:popular|common|frequent) (?P<field>{WORDS}) (?:in|at|among) (?:the )?(?P<table>{WORDS})", re.I)
# role and relation must each name a schema table; the output field must be specified.
ROLE = re.compile(LEAD + rf"(?P<role>{WORDS}) (?:in|from|through|recorded in|listed in) (?:the )?(?P<link>{WORDS}) "
                  rf"(?:for|of|associated with) (?:the )?(?P<anchor>{WORDS}) (?:with|whose|having) (?:the )?"
                  r"(?:id|identifier|primary key)(?: is| equals| =)? (?P<id>-?[0-9]{1,8})", re.I)
OUTPUT = re.compile(r"(?:(?:list|show|give|return|select)(?: me)? (?:the )?)?"
                    + rf"(?P<owner>{WORDS})(?:'s|’s|s') (?P<field>{WORDS})", re.I)


def tokens(name):
    return intent.tokens(name)


def distinct_worlds(text, schema):
    for pattern, kind in ((DISTINCT, "explicit_distinct_values"), (MODE, "most_frequent_table_value")):
        m = pattern.fullmatch(text)
        if not m:
            continue
        t = intent.choose(schema, m["table"])
        c = intent.projection(t, m["field"]) if t else None
        if not c or c["pk"] or not (intent.text_col(c) or intent.numeric_col(c)):
            return []
        if any(f["from"].casefold()==c["name"].casefold() for f in t["foreign_keys"]):
            return []
        if pattern is MODE and any(c2["name"] != c["name"] and
                                   set(tokens(c2["name"])) & {"popularity","frequency","count","vote","score"}
                                   for c2 in t["columns"]):
            return []
        worlds = []
        for indexes in ([1,2,2,3], [2,1,3,1]):
            vals = [intent.key_value(c, i) for i in indexes]
            rows = [dict(intent.entity_row(t,k) or {}, **{c["name"]:v}) for k,v in enumerate(vals,1)]
            expected = list(dict.fromkeys(vals)) if pattern is DISTINCT else [Counter(vals).most_common(1)[0][0]]
            worlds.append(intent.world(kind, "Distinct display values" if pattern is DISTINCT else
                                       "The most frequent value is the unique mode of the named table rows.",
                                       {t["name"]:rows}, expected))
        return worlds
    return []


def role_intent(text, schema):
    parts = [s.strip() for s in re.split(r"[.!?]+\s*", text) if s.strip()]
    if not 1 <= len(parts) <= 2:
        return None
    m = ROLE.fullmatch(parts[0])
    column = None
    if len(parts)==1:
        # Also accept "show the names of reviewers in the endorsements for ...".
        lead = re.match(LEAD+rf"(?P<field>{WORDS}) of (?:all )?(?:the )?", parts[0], re.I)
        if lead:
            column = lead["field"]
            m = ROLE.fullmatch("list "+parts[0][lead.end():])
    if not m:
        return None
    role, bridge, anchor = [intent.choose(schema, m[k]) for k in ("role","link","anchor")]
    if not role or not bridge or not anchor or len({t["name"] for t in (role,bridge,anchor)})!=3:
        return None
    if len(parts)==2:
        proj = OUTPUT.fullmatch(parts[1])
        if proj is None or tokens(proj["owner"])!=tokens(role["name"]):
            return None
        column = proj["field"]
    attr = intent.projection(role,column) if column else None
    rp, ap = intent.primary(role), intent.primary(anchor)
    if (not attr or not rp or not ap or not intent.numeric_col(ap) or
            not (intent.text_col(attr) or intent.numeric_col(attr))):
        return None
    return role, bridge, anchor, rp, ap, attr, int(m["id"])


def relation_model(schema, needed):
    """Resolve public FK pairs; group composite edges only when all destination PK parts occur once."""
    tables = {t["name"].casefold():t for t in schema}
    todo = list(needed)
    edges = {}
    while todo:
        name = todo.pop()
        if name in edges:
            continue
        t = tables[name]
        by_parent = defaultdict(list)
        for f in t["foreign_keys"]:
            by_parent[f["table"].casefold()].append(f)
        edges[name] = []
        for parent, refs in by_parent.items():
            pk = sorted((c["pk"],c["name"]) for c in tables[parent]["columns"] if c["pk"])
            dest = [c for _,c in pk]
            pairs = [(intent.by_name(t["columns"],f["from"])["name"],
                      intent.by_name(tables[parent]["columns"],f["to"] or (dest[0] if len(dest)==1 else ""))["name"])
                     for f in refs]
            if len(dest)==1 and all(d==dest[0] for _,d in pairs):
                groups = [[pair] for pair in pairs]
            elif len(dest)>1 and Counter(d for _,d in pairs)==Counter(dest):
                groups = [sorted(pairs,key=lambda pair:dest.index(pair[1]))]
            else:
                raise ValueError("Unresolved grouped or non-primary foreign key")
            edges[name].extend((parent,group) for group in groups)
            todo.append(parent)
    return tables,edges


def role_worlds(text, schema, trees):
    spec = role_intent(text,schema)
    if spec is None:
        return []
    role,bridge,anchor,rp,ap,attr,literal = spec
    rk,bk,ak = (t["name"].casefold() for t in (role,bridge,anchor))
    needed = {t.name.casefold() for tree in trees for t in tree.find_all(exp.Table)} | {rk,bk,ak}
    tables,edges = relation_model(schema,needed)

    def reaches(table, field, goal, seen):
        if (table,field)==goal:
            return True
        if (table,field) in seen:
            return False
        return any(reaches(parent,d,goal,seen|{(table,field)}) for parent,pairs in edges[table]
                   for s,d in pairs if s==field)

    def bridge_key(table,pk):
        return intent.unique([c["name"] for c in bridge["columns"]
                              if reaches(bk,c["name"],(table,pk["name"]),set())])
    role_fk, anchor_fk = bridge_key(rk,rp), bridge_key(ak,ap)
    if not role_fk or not anchor_fk or role_fk==anchor_fk:
        return []
    worlds=[]
    for variant in (0,1):
        by_table={}
        def materialize(name,active):
            if name in by_table:
                return
            if name in active:
                raise ValueError("Cyclic relation")
            t = tables[name]
            for parent,_ in edges[name]:
                materialize(parent,active|{name})
            rows=[]
            for i in range(5):
                ordinal = i+1
                row = {c["name"]: filler(c,ordinal) for c in t["columns"]}
                if name==ak:
                    row[ap["name"]]=literal+((i+variant)%5)
                if name==rk and attr["name"]!=rp["name"]:
                    row[attr["name"]]=intent.key_value(attr,ordinal)
                assigned = {}
                for parent,pairs in edges[name]:
                    options = [r for r in by_table[parent] if all(s not in assigned or assigned[s]==r[d] for s,d in pairs)]
                    if not options:
                        raise ValueError("Conflicting public relationships")
                    n = i
                    if parent==ak:
                        n = ([0,0,1,2,4],[4,1,4,3,2])[variant][i]
                    if name==bk and parent==rk:
                        n = ([1,2,3,4,0],[2,0,2,3,4])[variant][i]
                    src=options[n%len(options)]
                    assigned.update((s,src[d]) for s,d in pairs)
                row.update(assigned)
                keys=[c["name"] for c in t["columns"] if c["pk"]]
                if keys and any(all(old[k]==row[k] for k in keys) for old in rows):
                    continue
                rows.append(row)
            if not rows:
                raise ValueError("Empty synthetic entity population")
            by_table[name]=rows
        for name in sorted(edges):
            materialize(name,set())
        members={r[role_fk] for r in by_table[bk] if r[anchor_fk]==literal}
        vals=[r[attr["name"]] for r in by_table[rk] if r[rp["name"]] in members]
        if not vals or len(members)==len(by_table[rk]):
            return []
        worlds.append({**intent.world("entity_id_through_named_relation",
                            "Select the named entities once per identity linked to the explicitly identified record, then project the requested field.",
                            {tables[k]["name"]:rs for k,rs in by_table.items()},vals), "edges":edges})
    return worlds


def role_results(schema, fixture, sqls):
    edges=fixture["edges"]
    tables={t["name"].casefold():t for t in schema}
    with closing(sqlite3.connect(":memory:")) as db:
        db.execute("PRAGMA foreign_keys=ON")
        for key,refs in edges.items():
            t=tables[key]
            cols=t["columns"]
            defs=[quote(c["name"])+" "+quote(c["type"])+(" NOT NULL" if c["pk"] or c["not_null"] else "") for c in cols]
            pk=[c["name"] for c in sorted(cols,key=lambda c:c["pk"]) if c["pk"]]
            if pk:
                defs.append("PRIMARY KEY ("+",".join(map(quote,pk))+")")
            for parent,pairs in refs:
                a,b=zip(*pairs)
                defs.append("FOREIGN KEY ("+",".join(map(quote,a))+") REFERENCES "+quote(tables[parent]["name"])+" ("+",".join(map(quote,b))+")")
            db.execute("CREATE TABLE "+quote(t["name"])+" ("+",".join(defs)+")")
        db.execute("BEGIN")
        db.execute("PRAGMA defer_foreign_keys=ON")
        for name,rows in fixture["rows"].items():
            cols=[c["name"] for c in tables[name.casefold()]["columns"]]
            db.executemany("INSERT INTO "+quote(name)+" VALUES ("+",".join("?" for _ in cols)+")",
                           [[r[c] for c in cols] for r in rows])
        db.commit()
        if db.execute("PRAGMA foreign_key_check").fetchone() or db.execute("PRAGMA integrity_check").fetchone()!=("ok",):
            raise ValueError("Synthetic constraints failed")
        db.execute("PRAGMA query_only=ON")
        def authorize(action,arg1,arg2,dbname,source):
            if (action in (sqlite3.SQLITE_SELECT,sqlite3.SQLITE_RECURSIVE) or
                action==sqlite3.SQLITE_READ and (arg1 or "").casefold() in edges or
                action==sqlite3.SQLITE_FUNCTION and (arg2 or arg1 or "").casefold() in FUNCTIONS):
                return sqlite3.SQLITE_OK
            return sqlite3.SQLITE_DENY
        db.set_authorizer(authorize)
        return [query(db,sql) for sql in sqls]


def judge(question,schema,v16_sql,model_sql,ordered=False):
    result={"choice":"abstain","reason":"no_grounded_expectation","family":None,"worlds":[]}
    if not model_sql or not v16_sql or model_sql.strip()==v16_sql.strip():
        return {**result,"reason":"no_distinct_pair"}
    try:
        sqls=(v16_sql,model_sql)
        trees=[validate_sql(s) for s in sqls]
        if trees[0]==trees[1]:
            return {**result,"reason":"same_query_structure"}
        text=" ".join(question.split()).strip().strip(".?!")
        designs=role_worlds(text,schema,trees) or distinct_worlds(text,schema) or design_fixtures(question,schema,*sqls)
        if not designs:
            return result
        result["family"]=designs[0]["family"]
        for fixture in designs:
            if "edges" in fixture:
                a,b=role_results(schema,fixture,sqls)
            else:
                pair=compare_world(schema,fixture["rows"],*sqls,ordered=ordered)
                if pair["status"]!="executed":
                    return {**result,"reason":"fixture_inconclusive","detail":pair["reason"]}
                a,b=pair["incumbent"],pair["candidate"]
            expected=fixture["expected"]
            results=[matches(q,expected,fixture["arity"],ordered) for q in (a,b)]
            result["worlds"].append({"expected":expected,"v16_rows":a["rows"],"model_rows":b["rows"],
                                     "v16_pass":results[0],"model_pass":results[1],"rationale":fixture["reason"],
                                     "synthetic_rows":fixture["rows"]})
        supports=[arm for arm in ("v16","model") if all(w[arm+"_pass"] is True for w in result["worlds"])]
        if len(supports)==1 and len(designs)>=2:
            result.update(choice=supports[0],reason="passes_all_constructed_worlds_and_other_fails")
        else:
            result["reason"]="insufficient_separation"
    except (ValueError,TypeError,KeyError,AttributeError,IndexError,sqlite3.Error,RecursionError,OverflowError) as exc:
        result.update(reason="fixture_inconclusive",detail=str(exc)[:180])
    return result
