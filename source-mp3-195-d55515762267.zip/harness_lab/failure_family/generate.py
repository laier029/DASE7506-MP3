"""Propose a public-schema access path while preserving the incumbent's other clauses."""
from collections import defaultdict, deque

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.diagnosis_trial.compiler import _base, _physical, _mentions
from harness_lab.h41.intent import tokens, primary
from harness_lab.h60.agent import sql_candidate
from harness_lab.h70.compiler import Edge, _graph, _t, _c
from mp3_sql.common import MAX_SQL_BYTES


def catalog(schema):
    graph = _graph({t['name'].casefold(): t for t in schema})
    owners = defaultdict(list)
    for table in schema:
        pk = primary(table)
        if pk:
            owners[pk['name'].casefold()].append((table, pk))
    inferred = set()
    for table in schema:
        declared = {f['from'].casefold() for f in table['foreign_keys']}
        for col in table['columns']:
            name = col['name'].casefold()
            if name in declared or len(tokens(col['name'])) < 2 or tokens(col['name'])[-1] != 'id':
                continue
            if len(owners[name]) != 1:
                continue
            parent, pk = owners[name][0]
            if parent == table or pk['type'].upper() != col['type'].upper():
                continue
            e = Edge(table['name'], col['name'], parent['name'], pk['name'])
            inferred.add(e)
            graph[e.child].append(e)
            graph[e.parent].append(e)
    return graph, inferred


def signature(e):
    return frozenset(((e.child, e.fk), (e.parent, e.pk)))


def path_from(connected, target, graph, inferred, old, words):
    queue = deque((node, (), {node}) for node in sorted(connected))
    paths = []
    while queue:
        node, path, seen = queue.popleft()
        for edge in graph[node]:
            nxt = edge.other(node)
            if nxt in seen or nxt in connected:
                continue
            route = (*path, (edge, nxt))
            if nxt == target:
                paths.append(route)
            elif len(route) < 3:
                queue.append((nxt, route, seen | {nxt}))
    def rank(route):
        edges = [edge for edge, _ in route]
        # An explicit role word can distinguish two foreign keys into the same entity.
        role_hits = set()
        for edge in edges:
            role_words = set(tokens(edge.fk)) - set(tokens(edge.pk)) - set(tokens(edge.parent)) - {'id','by','of','the'}
            role_hits.update(role_words & words)
        return (sum(edge in inferred for edge in edges), len(edges), -len(role_hits),
                -sum(signature(edge) in old for edge in edges))
    if paths:
        best = min(map(rank, paths))
        tied = [p for p in paths if rank(p) == best]
        if len(tied) == 1:
            return tied[0]
    return None


def proposal(row):
    schema, question = row['schema'], row['question']
    tree, scope = _base(row['current_sql'], schema)
    joins = tree.args.get('joins', [])
    if any(not isinstance(n.parent, exp.Count) for n in tree.find_all(exp.Star)):
        return None
    old = set()
    for join in joins:
        pred = join.args.get('on')
        if (join.side or join.method or join.kind not in ('','INNER') or not isinstance(pred, exp.EQ)
              or not all(isinstance(v, exp.Column) for v in (pred.this, pred.expression))):
            return None
        lhs, rhs = (_physical(v, scope) for v in (pred.this, pred.expression))
        if lhs and rhs:
            old.add(frozenset((lhs,rhs)))
    names = [t['name'] for _,t in scope.values()]
    graph, inferred = catalog(schema)
    labels = {item.alias.casefold() for item in tree.expressions if item.alias}
    needed = []
    refs = set()
    rebinding = False
    for col in list(tree.find_all(exp.Column)):
        if col.find_ancestor(exp.Join):
            continue
        ref = _physical(col, scope)
        if not ref:
            if not col.table and col.name.casefold() in labels and col.find_ancestor(exp.Order,exp.Group,exp.Having):
                continue
            owners = [(t['name'], f['name']) for t in schema for f in t['columns']
                      if f['name'].casefold() == col.name.casefold()]
            if len(owners) != 1:
                return None
            ref = owners[0]
            rebinding = True
        if ref[0] not in needed:
            needed.append(ref[0])
        refs.add(ref)
        col.replace(_c(*ref))
    qt = tokens(question)
    if not needed:
        return None
    for name in names:
        if name in needed:
            continue
        # A requested entity can already be represented by a referenced foreign key.
        represented = any(e.parent == name and (e.child,e.fk) in refs and signature(e) in old
                          for e in graph[name] if e not in inferred)
        if (_mentions(qt, name) and not represented) or (tree.find(exp.Star) and not represented):
            needed.append(name)
    # A missing attributive field in a one-table draft still belongs to its original subject.
    if len(names) == 1 and names[0] not in needed:
        needed.append(names[0])
    connected = {needed[0]}
    route = []
    for dst in needed[1:]:
        if dst in connected:
            continue
        steps = path_from(connected, dst, graph, inferred, old, set(qt))
        if not steps:
            return None
        route.extend(steps)
        connected.update(nxt for _, nxt in steps)
    if (not rebinding and set(names) == connected and len(joins) == len(route)
            and old == {signature(e) for e,_ in route}):
        return None
    tree.set('from', exp.From(this=_t(needed[0])))
    tree.set('joins', [])
    for edge, nxt in route:
        tree.join(_t(nxt), on=edge.predicate(), copy=False)
    sql = tree.sql(dialect='sqlite',comments=False)
    if len(sql.encode()) > MAX_SQL_BYTES:
        return None
    sql_candidate(sql,schema)
    return {'sql':sql,'added_sources':sorted(connected-set(names)),'removed_sources':sorted(set(names)-connected),
            'path':[e.role() for e,_ in route], 'inferred_edges':[e.role() for e,_ in route if e in inferred],
            'rebound_field':rebinding}


def generate(row):
    try:
        result = proposal(row)
    except (ValueError, SqlglotError, RecursionError):
        return []
    return [result] if result else []
