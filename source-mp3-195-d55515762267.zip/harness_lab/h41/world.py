"""Execute two read-only queries on one bounded, synthetic in-memory SQLite world."""
import math
import sqlite3

from mp3_sql.common import result_fingerprint
from mp3_sql.sqlite_tool import validate_sql


MAX_ROWS = 1024
MAX_STEPS = 400_000
# Deterministic scalar, aggregate and window functions. Clock-dependent functions abstain.
FUNCTIONS = set("""
    count sum avg total min max abs round coalesce ifnull nullif lower upper length trim ltrim rtrim
    substr substring replace instr like glob printf format typeof group_concat hex unicode char
    concat concat_ws iif sign ceil ceiling floor pow power sqrt log log10 ln json_extract json_array_length
    json_valid row_number rank dense_rank lag lead ntile first_value last_value nth_value cume_dist percent_rank
""".split())


def quote(name):
    if not isinstance(name, str) or '\x00' in name or len(name) > 256:
        raise ValueError('Invalid schema identifier or type')
    return '"' + name.replace('"', '""') + '"'


def filler(col, number):
    declared = col['type'].upper()
    if any(token in declared for token in ('CHAR', 'CLOB', 'TEXT')):
        return f'w{number}'
    if 'DATE' in declared or 'TIME' in declared:
        return f'2000-01-{(number - 1) % 28 + 1:02d}'
    if 'BOOL' in declared:
        return number % 2
    return number


def build(db, schema, rows):
    if (not isinstance(schema, list) or not 1 <= len(schema) <= 64 or not isinstance(rows, dict)
            or any(not isinstance(v, list) for v in rows.values()) or sum(map(len, rows.values())) > MAX_ROWS):
        raise ValueError('Invalid schema/rows or too many synthetic rows')
    tables = {t['name']: t for t in schema}
    if len(tables) != len(schema) or set(rows) - tables.keys():
        raise ValueError('Duplicate or unknown table')
    by_name = {name.casefold(): t for name, t in tables.items()}
    required = {}
    for name, table in tables.items():
        cols = table['columns']
        if not 1 <= len(cols) <= 100:
            raise ValueError('Unsupported schema width')
        names = {c['name'].casefold(): c for c in cols}
        pk = sorted((c['pk'], c['name']) for c in cols if c['pk'])
        if [pos for pos, _ in pk] != list(range(1, len(pk) + 1)):
            raise ValueError('Ambiguous primary key sequence')
        definitions = [quote(c['name']) + ' ' + quote(c['type']) +
                       (' NOT NULL' if c['pk'] or c.get('not_null') else '') for c in cols]
        if pk:
            definitions.append('PRIMARY KEY (' + ','.join(quote(n) for _, n in pk) + ')')
        fks = set()
        for fk in table['foreign_keys']:
            child = names[fk['from'].casefold()]['name']
            fks.add(child)
            parent = by_name[fk['table'].casefold()]
            keys = [c['name'] for c in parent['columns'] if c['pk']]
            if len(keys) != 1 or (fk['to'] and fk['to'].casefold() != keys[0].casefold()):
                # Public schema omits UNIQUE indexes and composite FK grouping. An empty child
                # column satisfies this FK regardless. Reject a world that needs an ambiguous edge.
                if any(row.get(child) is not None for row in rows.get(name, [])):
                    raise ValueError(f'Underdetermined foreign key: {name}.{child}')
                continue
            definitions.append('FOREIGN KEY (' + quote(child) + ') REFERENCES ' + quote(parent['name']) +
                               ' (' + quote(keys[0]) + ')')
        required[name] = fks
        db.execute('CREATE TABLE ' + quote(name) + ' (' + ','.join(definitions) + ')')

    db.execute('BEGIN')
    db.execute('PRAGMA defer_foreign_keys=ON')
    for name, supplied in rows.items():
        cols = tables[name]['columns']
        names = {c['name'] for c in cols}
        statement = 'INSERT INTO ' + quote(name) + ' VALUES (' + ','.join('?' for _ in cols) + ')'
        for number, row in enumerate(supplied, 1):
            if not isinstance(row, dict) or row.keys() - names:
                raise ValueError('Unknown column or invalid synthetic row')
            values = []
            for c in cols:
                key = c['name']
                value = row.get(key)
                if value is None and (c['pk'] or c.get('not_null')):
                    if key in row or key in required[name]:
                        raise ValueError(f'Invalid or unspecified required value: {name}.{key}')
                    value = filler(c, number)
                if (value is not None and not isinstance(value, (str, float, int)) or
                    isinstance(value, str) and len(value.encode()) > 1024 or
                    isinstance(value, float) and not math.isfinite(value)):
                    raise ValueError('Unsupported synthetic value')
                values.append(value)
            db.execute(statement, values)
    db.commit()
    if db.execute('PRAGMA foreign_key_check').fetchone():
        raise ValueError('Invalid foreign key')
    return {name: [dict(row) for row in db.execute('SELECT * FROM ' + quote(name))] for name in tables}


def query(db, sql):
    ticks = 0
    def limit():
        nonlocal ticks
        ticks += 1
        return ticks * 1000 >= MAX_STEPS

    db.set_progress_handler(limit, 1000)
    cursor = db.execute(sql)
    rows, size = [], 0
    for row in cursor:
        if len(rows) == MAX_ROWS:
            raise ValueError('Result exceeds synthetic row budget')
        cells = []
        for value in row:
            if isinstance(value, bytes):
                value = 'blob:' + value.hex()
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError('Non-finite result')
            if isinstance(value, str) and len(value.encode()) > 4000:
                raise ValueError('Oversized result cell')
            size += len(value.encode()) if isinstance(value, str) else 8
            if size > 512_000:
                raise ValueError('Result exceeds synthetic size budget')
            cells.append(value)
        rows.append(cells)
    return {'ok': True, 'columns': [col[0] for col in cursor.description], 'rows': rows, 'error': None}


def compare_world(schema, rows, incumbent_sql, candidate_sql, *, ordered=False):
    """Return executed world/results, or an inconclusive reason. No course DB is opened."""
    attempts = 0
    db = sqlite3.connect(':memory:')
    try:
        if type(ordered) is not bool:
            raise ValueError('Expected a boolean ordered flag')
        validate_sql(incumbent_sql)
        validate_sql(candidate_sql)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA temp_store=MEMORY')
        snapshot = build(db, schema, rows)
        db.execute('PRAGMA query_only=ON')
        for category, cap in [(sqlite3.SQLITE_LIMIT_LENGTH, 100_000), (sqlite3.SQLITE_LIMIT_SQL_LENGTH, 16_000),
                              (sqlite3.SQLITE_LIMIT_COLUMN, 100), (sqlite3.SQLITE_LIMIT_EXPR_DEPTH, 100),
                              (sqlite3.SQLITE_LIMIT_COMPOUND_SELECT, 20), (sqlite3.SQLITE_LIMIT_VDBE_OP, 50_000),
                              (sqlite3.SQLITE_LIMIT_LIKE_PATTERN_LENGTH, 1000)]:
            db.setlimit(category, cap)
        allowed = {table.casefold() for table in snapshot}
        def authorize(action, first, second, database, source):
            if (action in (sqlite3.SQLITE_SELECT, sqlite3.SQLITE_RECURSIVE) or
                action == sqlite3.SQLITE_READ and database in (None, 'main') and (first or '').casefold() in allowed or
                action == sqlite3.SQLITE_FUNCTION and (second or first or '').casefold() in FUNCTIONS):
                return sqlite3.SQLITE_OK
            return sqlite3.SQLITE_DENY
        db.set_authorizer(authorize)
        attempts = 1
        incumbent = query(db, incumbent_sql)
        attempts = 2
        candidate = query(db, candidate_sql)
        return {'status': 'executed', 'snapshot': snapshot, 'incumbent': incumbent, 'candidate': candidate,
                'different': result_fingerprint(incumbent, ordered) != result_fingerprint(candidate, ordered),
                'query_executions': attempts}
    except (sqlite3.Error, ValueError, TypeError, KeyError, AttributeError, OverflowError, MemoryError, RecursionError) as exc:
        return {'status': 'inconclusive', 'reason': f'{type(exc).__name__}: {exc}'[:300], 'query_executions': attempts}
    finally:
        db.close()
