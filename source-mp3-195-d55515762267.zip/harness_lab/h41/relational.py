"""Supplement the frozen intent rules with explicitly declared count relationships."""
from collections import Counter
import re

from harness_lab.h41 import intent
from harness_lab.h41.world import MAX_ROWS


def detail_link(schema, entity, noun):
    entity_key = intent.primary(entity)
    if not entity_key:
        return None
    matches = []
    for table in schema:
        if table is entity or not set(intent.tokens(noun)).issubset(intent.tokens(table["name"])):
            continue
        for fk in table["foreign_keys"]:
            if fk["table"].casefold() == entity["name"].casefold():
                matches.append((table, fk))
    bound = intent.unique(matches)
    if not bound:
        return None
    detail, fk = bound
    detail_key = intent.primary(detail)
    if (fk["to"].casefold() != entity_key["name"].casefold() or
            detail_key and detail_key["name"].casefold() == fk["from"].casefold()):
        return None  # A sole primary key referring to the owner cannot represent many rows per owner.
    return detail, fk


def summaries(entity, noun):
    words = intent.tokens(noun)
    endings = {("count",), ("number",), ("amount",), ("total",)}
    names = {words, *(words + suffix for suffix in endings), *(prefix + words for prefix in endings)}
    return [c for c in entity["columns"] if intent.tokens(c["name"]) in names]


def design_relational(question, schema):
    """Only an unambiguous FK-bound detail table can supply the additional counting oracle."""
    try:
        frozen = intent.design(question, schema)
    except (ValueError, OverflowError):
        return []  # For example, a threshold longer than Python's integer input limit.
    if frozen or not isinstance(question, str) or not isinstance(schema, list):
        return frozen
    text = " ".join(question.split()).strip().rstrip("?.!").strip()
    pattern = next(pattern for builder, pattern in intent._PATTERNS if builder is intent.without_entity)
    m = re.fullmatch(pattern, text, intent._IGNORE)
    if not m:
        return []
    # A boundary value needs at least that many detail rows in a bounded world.
    number = m["amount"]
    if number.isdigit() and len(number.lstrip("0")) > len(str(MAX_ROWS)):
        return []
    try:
        compare, n = intent.quantity(m)
    except (ValueError, OverflowError):
        return []
    entity = intent.choose(schema, m["entity"], suffix=True)
    if not entity or n >= MAX_ROWS:
        return []
    group = intent.projection(entity, m["group"])
    relation = detail_link(schema, entity, m["noun"])
    columns = summaries(entity, m["noun"])
    if not intent.text_col(group) or not relation or len(columns) > 1:
        return []
    summary = intent.unique(columns)
    if summary and (summary == group or summary.get("pk") or
                    not (intent.text_col(summary) or intent.numeric_col(summary))):
        return []
    entity_key = intent.primary(entity)["name"]
    detail, foreign_key = relation
    if any(fk["from"].casefold() in {group["name"].casefold(), (summary or {"name": ""})["name"].casefold()}
           for fk in entity["foreign_keys"]):
        return []  # Group or summary requires a separate parent domain that these worlds cannot supply.

    lo, hi = max(0, n - 1), n + 1
    arrangements = [((lo,), (n,), (hi, lo)), ((hi,), (lo, hi), (n,))]
    worlds = []
    for counts in arrangements:
        total = sum(map(sum, counts))
        if sum(map(len, counts)) + total * len(detail["foreign_keys"]) > MAX_ROWS:
            return []
        rows = {entity["name"]: []}
        entities = rows[entity["name"]]
        # Supply construction sizes to the frozen FK materializer; this private key never reaches SQLite.
        requested_count = object()
        for label, members in zip(("Group-A", "Group-B", "Group-C"), counts):
            for size in members:
                item = intent.entity_row(entity, len(entities) + 1)
                if not item:
                    return []
                item.update({group["name"]: label, requested_count: size})
                entities.append(item)
        if not intent.add_count_details(schema, entity, m["noun"], rows, {"name": requested_count}):
            return []
        by_entity = Counter(r[foreign_key["from"]] for r in rows[detail["name"]])
        disqualified = set()
        groups = []
        for item in entities:
            actual = by_entity[item[entity_key]]
            if item.pop(requested_count) != actual:
                return []
            if summary:
                item[summary["name"]] = str(actual) if intent.text_col(summary) else actual
            label = item[group["name"]]
            if label not in groups:
                groups.append(label)
            if compare(actual, n):
                disqualified.add(label)
        expected = [label for label in groups if label not in disqualified]
        if not expected or not disqualified:
            return []
        worlds.append(intent.world("relational_negative_existence",
                                   "Count the declared detail rows per entity using their foreign key. "
                                   "Exclude a group if any of its entities meets the stated threshold.",
                                   rows, expected))
    return worlds
