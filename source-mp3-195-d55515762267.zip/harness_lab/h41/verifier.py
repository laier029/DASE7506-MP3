"""Decide only when a question-derived expectation and a distinguishing world are available."""
from mp3_sql.common import result_fingerprint
from harness_lab.h41.intent import design
from harness_lab.h41.world import compare_world


def matches(observed, expected, width, ordered):
    if width is None or width < 1 or any(len(row) != width for row in expected):
        return None
    oracle = {"ok": True, "columns": list(range(width)), "rows": expected}
    actual = {"ok": True, "columns": observed["columns"], "rows": observed["rows"]}
    return result_fingerprint(actual, ordered) == result_fingerprint(oracle, ordered)


def review(question, schema, incumbent, proposed, ordered):
    report = {"status": "inconclusive", "reason": "no_grounded_interpretation",
              "worlds_designed": 0, "worlds_tested": 0, "distinguishing_worlds": 0,
              "query_executions": 0, "evidence": []}
    if ordered:
        # Supported intents imply a multiset. Fixture insertion order is not a semantic oracle.
        report["reason"] = "ordering_not_grounded"
        return report
    fixtures = design(question, schema)
    report["worlds_designed"] = len(fixtures)
    if not fixtures:
        return report
    if len({f["family"] for f in fixtures}) != 1:
        report["reason"] = "multiple_interpretations"
        return report
    failures, wins = [], []
    for index, fixture in enumerate(fixtures):
        expected = fixture["expected"]
        width = fixture.get("arity", len(expected[0]) if expected else None)
        result = compare_world(schema, fixture["rows"], incumbent, proposed, ordered=ordered)
        report["query_executions"] += result.get("query_executions", 0)
        entry = {"family": fixture["family"], "reason": fixture["reason"],
                 "expected": expected, "execution": result}
        report["evidence"].append(entry)
        if result["status"] != "executed":
            continue
        a = matches(result["incumbent"], expected, width, ordered)
        b = matches(result["candidate"], expected, width, ordered)
        entry.update(incumbent_matches=a, candidate_matches=b)
        if b is None:
            continue
        report["worlds_tested"] += 1
        report["distinguishing_worlds"] += int(result["different"])
        if not b:
            failures.append(index)
        elif not a:
            wins.append(index)
    if not report["distinguishing_worlds"]:
        report["reason"] = "no_discriminating_valid_world"
    elif failures:
        report.update(status="veto", reason="candidate_failed_grounded_expectation", failed_worlds=failures)
    elif wins and report["worlds_tested"] == len(fixtures):
        report.update(status="support", reason="candidate_passed_all_constructed_worlds", winning_worlds=wins)
    else:
        report["reason"] = "insufficient_evidence"
    return report
