"""Build small hypothetical databases from explicit English requirements and public schema."""
import operator
import re

from submission.semantic_context import NUMBER_WORDS, QUANTITY_OPERATORS


_OPERATORS = {">": operator.gt, ">=": operator.ge, "<": operator.lt, "<=": operator.le, "=": operator.eq}
_NUMBERS = "|".join(["[0-9]+", *NUMBER_WORDS])
_QUANTIFIER = "|".join(sorted(QUANTITY_OPERATORS, key=len, reverse=True))
_AMOUNT = rf"(?P<op>{_QUANTIFIER}) (?P<amount>{_NUMBERS})"
_WORDS = r"[A-Za-z][A-Za-z_]*(?: [A-Za-z][A-Za-z_]*){0,3}?"
_LEAD = r"(?:(?:list|show|find|give|return|select)(?: me)?|what are|which are|which) (?:all (?:the )?|the )?"
_IGNORE = re.IGNORECASE


def tokens(name):
    def lemma(w):
        if w == "people":
            return "person"
        if w == "children":
            return "child"
        if w in {"dept", "depts"}:
            return "department"
        if w.endswith("ies") and len(w) > 3:
            return w[:-3] + "y"
        if w.endswith(("ches", "shes", "xes", "sses", "zzes")):
            return w[:-2]
        if w.endswith("s") and not w.endswith(("ss", "us", "is")):
            return w[:-1]
        return w
    name = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", name)
    return tuple(lemma(w) for w in re.findall("[a-z0-9]+", name.lower()))


def unique(options):
    return options[0] if len(options) == 1 else None


def choose(options, phrase, *, suffix=False):
    wanted = tokens(phrase)
    exact = [item for item in options if tokens(item["name"]) == wanted]
    if exact or not suffix:
        return unique(exact)
    return unique([item for item in options if tokens(item["name"])[-len(wanted):] == wanted])


def by_name(items, name):
    return unique([item for item in items if item["name"].casefold() == name.casefold()])


def text_col(col):
    return col and any(t in col["type"].upper() for t in ("CHAR", "TEXT", "CLOB"))


def numeric_col(col):
    return col and any(t in col["type"].upper() for t in ("INT", "NUM", "REAL", "DEC", "FLOAT", "DOUBLE"))


def primary(table):
    return unique([c for c in table["columns"] if c.get("pk")])


def quantity(m):
    number = m["amount"].lower()
    return _OPERATORS[QUANTITY_OPERATORS[m["op"].lower()]], int(number) if number.isdigit() else NUMBER_WORDS[number]


def projection(table, phrase):
    col = choose(table["columns"], phrase)
    if col:
        return col
    # A schema may qualify a projected name/ID with the entity, e.g. Item_Name.
    wanted = tokens(phrase)
    names = tokens(table["name"])
    return unique([c for c in table["columns"]
                   if tokens(c["name"]) in {names + wanted, names[-1:] + wanted}])


def key_value(col, i):
    if not col or numeric_col(col):
        return i
    return f"K{i}" if text_col(col) else None


def entity_row(table, i):
    key = primary(table)
    if key:
        value = key_value(key, i)
        if value is None:
            return None
        return {key["name"]: value}
    return {} if not any(c.get("pk") for c in table["columns"]) else None


def world(family, reason, rows, expected):
    return {"family": family, "reason": reason, "rows": rows,
            "arity": 1, "expected": [[value] for value in expected]}


def count_groups(m, schema):
    role = choose(schema, m["entity"], suffix=True)
    if not role:
        return []
    compare, n = quantity(m)
    if not 1 <= n <= 8:
        return []
    if compare(0, n):
        # Without a specified domain, groups containing no such entities are ambiguous.
        return []
    group = projection(role, m["group"])
    owner, fk = role, None
    if not group:
        # Only a declared unique role ID joining the unique parent ID establishes a subtype.
        child_key = primary(role)
        links = []
        for link in role["foreign_keys"]:
            parent = by_name(schema, link["table"])
            parent_key = primary(parent) if parent else None
            attr = projection(parent, m["group"]) if parent else None
            if (parent is not role and child_key and parent_key and text_col(attr)
                    and link["from"].casefold() == child_key["name"].casefold()
                    and link["to"].casefold() == parent_key["name"].casefold()):
                links.append((parent, attr, link))
        bound = unique(links)
        if not bound:
            return []
        owner, group, fk = bound
    if not text_col(group):
        return []
    counts = [max(1, n-1), n, n+1]
    designs = []
    for reverse in (False, True):
        rows = {t["name"]: [] for t in (owner, role)}
        expected = []
        for label, count in zip(("Set-A", "Set-B", "Set-C"), reversed(counts) if reverse else counts):
            if compare(count, n):
                expected.append(label)
            for _ in range(count):
                key = len(rows[owner["name"]]) + 1
                item = entity_row(owner, key)
                if item is None:
                    return []
                item[group["name"]] = label
                rows[owner["name"]].append(item)
                if fk:
                    rows[role["name"]].append({fk["from"]: item[primary(owner)["name"]]})
        if fk:
            # The base entity alone must not qualify a person/object for the requested role.
            for label in ["Non-role"] * (n+1) + ["Set-A"]:
                item = entity_row(owner, len(rows[owner["name"]])+1)
                item[group["name"]] = label
                rows[owner["name"]].append(item)
        designs.append(world("group_count", "Compare numbers of distinct entities around the stated threshold; "
                             "only rows of the requested role count.", rows, expected))
    return designs


def measure_for(table, phrase):
    stem = tokens(phrase)
    suffixes = {("count",), ("number",), ("amount",), ("total",)}
    forms = {stem, *(stem+s for s in suffixes), *(s+stem for s in suffixes)}
    return unique([c for c in table["columns"] if numeric_col(c) and tokens(c["name"]) in forms])


def add_count_details(schema, table, noun, rows, measure):
    """Keep an explicitly named count relationship consistent with its numeric summary."""
    key = primary(table)
    noun_words = tokens(noun)
    children = []
    for child in schema:
        if child is table or not set(noun_words).issubset(tokens(child["name"])):
            continue
        links = [fk for fk in child["foreign_keys"] if fk["table"].casefold() == table["name"].casefold()]
        if links:
            if len(links) != 1 or not key or links[0]["to"].casefold() != key["name"].casefold():
                return False
            children.append((child, links[0]))
    if not children:
        # A numeric amount can denote money rather than the number of related entities.
        return "amount" not in tokens(measure["name"])
    if len(children) != 1:
        return False
    child, parent_fk = children[0]
    others = [f for f in child["foreign_keys"] if f != parent_fk]
    parent_tables = []
    for link in others:
        parent = by_name(schema, link["table"])
        pk = primary(parent) if parent else None
        if (not pk or link["to"].casefold() != pk["name"].casefold()
                or parent["name"] in {table["name"], child["name"]} or parent["foreign_keys"]):
            return False
        parent_tables.append((link, parent, pk))
    outer_rows = rows[table["name"]]
    total = sum(item[measure["name"]] for item in outer_rows)
    if len(outer_rows) + total * (1 + len(others)) > 1024:
        return False
    rows[child["name"]] = []
    for outer in outer_rows:
        for _ in range(outer[measure["name"]]):
            i = len(rows[child["name"]]) + 1
            # A bridge may have a composite PK entirely supplied by its FKs.
            if any(c.get("pk") and c["name"].casefold() not in {f["from"].casefold() for f in child["foreign_keys"]}
                   for c in child["columns"]) and not primary(child):
                return False
            detail = entity_row(child, i) or {}
            detail[parent_fk["from"]] = outer[key["name"]]
            for link, parent, pk in parent_tables:
                entries = rows.setdefault(parent["name"], [])
                value = key_value(pk, len(entries) + 1)
                if value is None:
                    return False
                entries.append({pk["name"]: value})
                detail[link["from"]] = value
            rows[child["name"]].append(detail)
    return True


def without_entity(m, schema):
    table = choose(schema, m["entity"], suffix=True)
    compare, n = quantity(m)
    if not table or not 0 <= n <= 500:
        return []
    group = projection(table, m["group"])
    measure = measure_for(table, m["noun"])
    if not text_col(group) or not measure:
        return []
    lo, hi = max(0, n-1), n+1
    # The mixed group distinguishes an existential exclusion from a row-level condition.
    patterns = [((lo,), (n,), (hi, lo)), ((hi,), (lo, hi), (n,))]
    designs = []
    for groups in patterns:
        rows = {table["name"]: []}
        expected = []
        for label, values in zip(("Zone-A", "Zone-B", "Zone-C"), groups):
            if not any(compare(value, n) for value in values):
                expected.append(label)
            for value in values:
                item = entity_row(table, len(rows[table["name"]])+1)
                if item is None:
                    return []
                item.update({group["name"]: label, measure["name"]: value})
                rows[table["name"]].append(item)
        if add_count_details(schema, table, m["noun"], rows, measure):
            designs.append(world("negative_existence", "Return each group having no member satisfying the "
                                 "numeric condition, including a group with mixed member values.", rows, expected))
    return designs


def range_worlds(m, schema):
    table = choose(schema, m["entity"], suffix=True)
    if not table:
        return []
    result = projection(table, m["output"])
    verb = m["field"].lower()
    terms = {verb, verb.removesuffix("ed"), verb.removesuffix("ed")+"e"}
    options = [c for c in table["columns"] if numeric_col(c) and
               (tokens(c["name"]) in {(v,) for v in terms} or tokens(c["name"]) in
                {(v,"year") for v in terms} | {("year",v) for v in terms})]
    col = unique(options)
    if not col or not text_col(result):
        return []
    a, b = int(m["a"]), int(m["b"])
    if not 0 <= a < b < 1000000:
        return []
    designs = []
    for values in ([a-1,a,b,b+1], [b,a-1,b+1,a]):
        rows, expected = [], []
        for i, value in enumerate(values, 1):
            item = entity_row(table, i)
            if item is None:
                return []
            label = f"Item-{i}"
            item.update({result["name"]: label, col["name"]: value})
            rows.append(item)
            if a <= value <= b:
                expected.append(label)
        designs.append(world("inclusive_range", "Include both endpoints; keep eligible entities even when "
                             "unrelated tables have no corresponding row.", {table["name"]:rows}, expected))
    return designs


def membership(table, dimension_name, schema, literal, other):
    dimension = choose(schema, dimension_name)
    if dimension:
        fks = [fk for fk in table["foreign_keys"] if fk["table"].casefold() == dimension["name"].casefold()]
        key = primary(dimension)
        if len(fks) == 1 and key and fks[0]["to"].casefold() == key["name"].casefold():
            name = projection(dimension, "name") or (key if text_col(key) else None)
            if not text_col(name):
                return None
            parent_rows, refs = [], []
            for i, item in enumerate((literal, other),1):
                ref = item if name is key else key_value(key, i)
                if ref is None:
                    return None
                parent_rows.append({key["name"]:ref, name["name"]:item})
                refs.append(ref)
            return fks[0]["from"], refs, {dimension["name"]:parent_rows}
        if fks:
            return None
    dim_tokens = tokens(dimension_name)
    col = unique([c for c in table["columns"] if text_col(c) and tokens(c["name"]) in
                  {dim_tokens, dim_tokens+("name",)}])
    if col and not any(f["from"].casefold() == col["name"].casefold() for f in table["foreign_keys"]):
        return col["name"], (literal, other), {}
    return None


def relative_all(m, schema):
    if tokens(m["measure"]) != tokens(m["measure2"]) or tokens(m["entity"]) != tokens(m["entity2"]):
        return []
    table = choose(schema, m["entity"], suffix=True)
    if not table:
        return []
    result, measure = projection(table, m["output"]), projection(table, m["measure"])
    if not text_col(result) or not numeric_col(measure):
        return []
    op = operator.gt if m["direction"].lower() in ("greater","higher","more") else operator.lt
    bound = membership(table, m["dimension"], schema, m["value"], "Other-Group")
    if not bound or m["value"].casefold() == "other-group":
        return []
    field, refs, parents = bound
    if field == result["name"]:
        return []
    designs = []
    for amounts in ([30,60,40,60,80,20], [60,45,45,75,30,55]):
        rows, expected = [], []
        for i, value in enumerate(amounts):
            item = entity_row(table, i+1)
            if item is None:
                return []
            label = f"Subject-{i+1}"
            item.update({field:refs[0 if i<2 else 1], result["name"]:label, measure["name"]:value})
            rows.append(item)
            if all(op(value, member) for member in amounts[:2]):
                expected.append(label)
        designs.append(world("all_members_extremum", "Compare each entity with every value in the named "
                             "group, including values between and equal to a group boundary.",
                             {**parents, table["name"]:rows}, expected))
    return designs


_PATTERNS = (
    (without_entity, _LEAD+rf"(?P<group>{_WORDS}) without (?:a|an|any) (?P<entity>{_WORDS}) "
     rf"(?:having|with|that has|which has) {_AMOUNT} (?P<noun>{_WORDS})"),
    (count_groups, _LEAD+rf"(?P<group>{_WORDS}) (?:that are shared by|shared by|with|having|have) "
     rf"{_AMOUNT} (?P<entity>{_WORDS})"),
    (relative_all, _LEAD+rf"(?P<output>{_WORDS}) of (?:all |the )?(?P<entity>{_WORDS}) whose (?P<measure>{_WORDS}) "
     rf"(?:is|are) (?P<direction>greater|higher|more|less|lower) than (?:the )?(?P<measure2>{_WORDS}) of all "
     rf"(?P<entity2>{_WORDS}) in (?:the )?(?P<value>[A-Za-z][A-Za-z0-9_'-]*) (?P<dimension>[A-Za-z_]+)"),
    (range_worlds, rf"(?:{_LEAD}|the )(?P<output>{_WORDS}) of (?:the )?(?P<entity>{_WORDS}) "
     rf"(?:(?:that|which|who) )?(?P<field>[A-Za-z_]+) between (?P<a>[0-9]+) and (?P<b>[0-9]+)"),
)


def design(question, schema):
    """Return multiple independent, question-derived expectations or abstain on unsupported wording."""
    if not isinstance(question, str) or not isinstance(schema, list):
        return []
    text = " ".join(question.split()).strip().rstrip("?.!").strip()
    for builder, pattern in _PATTERNS:
        match = re.fullmatch(pattern, text, _IGNORE)
        if match:
            return builder(match, schema)
    return []
