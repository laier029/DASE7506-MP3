"""Bounded SQL choices: keep existing projections or replace one column node."""

from dataclasses import dataclass
import json
import re

from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from agent_v2.submission import parse_query


class UnsupportedEdit(ValueError):
    """The query is outside this deliberately small editor's supported scope."""


class InvalidDecision(ValueError):
    """The response is not an allowed decision for the given immutable task."""


@dataclass(frozen=True)
class Candidate:
    id: str
    sql: str


@dataclass(frozen=True)
class FieldTarget:
    id: str
    clause: str
    sql: str


@dataclass(frozen=True)
class DecisionSpec:
    operation: str
    source_sql: str
    target_id: str | None
    target_sql: str | None
    candidates: tuple[Candidate, ...]
    context_json: str


@dataclass(frozen=True)
class EditResult:
    status: str
    sql: str | None
    selected_ids: tuple[str, ...]


def _select(sql):
    try:
        tree = parse_query(sql)
    except ValueError as error:
        raise UnsupportedEdit(str(error)) from error
    if not isinstance(tree, exp.Select):
        raise UnsupportedEdit("Only a top-level SELECT is supported; set queries are excluded")
    return tree


def _positional_clause(tree):
    for clause in ("group", "order"):
        node = tree.args.get(clause)
        for expression in node.expressions if node is not None else ():
            while isinstance(expression, (exp.Ordered, exp.Paren, exp.Neg)):
                expression = expression.this
            if (isinstance(expression, exp.Literal) and not expression.is_string
                    and re.fullmatch(r"[+-]?\d+", expression.this)):
                return clause
    return None


def _physical_sources(tree, schema):
    """Bind only the outer SELECT's explicitly selected physical sources."""
    tables = {table["name"].casefold(): table for table in schema}
    if len(tables) != len(schema):
        raise UnsupportedEdit("Schema contains ambiguous table names")
    try:
        scope = build_scope(tree)
        selected = scope.selected_sources if scope is not None else {}
    except Exception as error:
        raise UnsupportedEdit("Cannot resolve top-level source bindings") from error
    if not selected:
        raise UnsupportedEdit("Field replacement requires a bound physical table")
    sources = []
    for alias, (_, source) in selected.items():
        if (not isinstance(source, exp.Table) or source.db or source.catalog
                or source.name.casefold() not in tables):
            raise UnsupportedEdit("Field replacement requires known physical tables, not CTE or derived sources")
        if source.args.get("alias") and source.args["alias"].args.get("columns"):
            raise UnsupportedEdit("Column-renaming table aliases are not supported")
        sources.append((alias, tables[source.name.casefold()]))
    return sources


def _field_nodes(tree):
    """Stable preorder within SELECT, WHERE, HAVING, ORDER; never descend scopes."""
    aliases = {item.alias.casefold() for item in tree.expressions if item.alias}
    roots = [("select", expression) for expression in tree.expressions]
    for clause in ("where", "having", "order"):
        node = tree.args.get(clause)
        if node is not None:
            roots.append((clause, node))
    targets = []
    for clause, root in roots:
        for node in root.walk(bfs=False):
            if (not isinstance(node, exp.Column) or node.is_star
                    or node.db or node.catalog
                    or node.find_ancestor(exp.Select) is not tree
                    or node.find_ancestor(exp.Window) is not None):
                continue
            # SQLite accepts SELECT aliases in several clauses. Such an alias
            # is not a physical field and must not be silently rebound.
            if clause != "select" and not node.table and node.name.casefold() in aliases:
                continue
            targets.append((clause, node))
    return targets


def list_field_targets(sql, schema):
    tree = _select(sql)
    _physical_sources(tree, schema)
    return tuple(FieldTarget(f"T{index}", clause, node.sql(dialect="sqlite"))
                 for index, (clause, node) in enumerate(_field_nodes(tree), 1))


def build_task(case):
    """Freeze an operator task from public inputs; ignore unrelated case fields.

    Required: row, schema, operation. field additionally needs target_id.
    working_sql overrides row.issue_sql after an earlier accepted AST edit.
    """
    row, schema = case["row"], case["schema"]
    source_sql = case.get("working_sql", row["issue_sql"])
    tree = _select(source_sql)
    operation = case["operation"]
    target_id, target_sql = None, None
    if operation == "projection":
        positional = _positional_clause(tree)
        if positional:
            raise UnsupportedEdit(f"Projection editing is disabled with positional {positional.upper()} BY")
        candidates = tuple(Candidate(f"P{index}", expression.sql(dialect="sqlite"))
                           for index, expression in enumerate(tree.expressions, 1))
    elif operation == "field":
        sources = _physical_sources(tree, schema)
        nodes = _field_nodes(tree)
        target_id = case.get("target_id")
        target = next((node for index, (_, node) in enumerate(nodes, 1)
                       if target_id == f"T{index}"), None)
        if target is None:
            raise UnsupportedEdit("target_id must identify an eligible top-level column occurrence")
        target_sql = target.sql(dialect="sqlite")
        columns = [exp.column(column["name"], table=alias, quoted=True)
                   for alias, table in sources for column in table["columns"]]
        candidates = tuple(Candidate(f"F{index}", column.sql(dialect="sqlite"))
                           for index, column in enumerate(columns, 1))
    else:
        raise UnsupportedEdit("operation must be projection or field")
    if not candidates:
        raise UnsupportedEdit("No candidates available for this operation")
    context = {
        "question": row.get("question", ""),
        "original_sql": row["issue_sql"], "working_sql": source_sql,
        "schema": schema, "public_example": row.get("example"),
        "ordered": row.get("ordered"),
        "checks": [event for event in case.get("history", []) if event.get("tool") == "check"],
        "operation": operation, "target_id": target_id, "target_sql": target_sql,
        "candidates": [{"id": candidate.id, "sql": candidate.sql} for candidate in candidates],
    }
    return DecisionSpec(operation, source_sql, target_id, target_sql, candidates,
                        json.dumps(context, ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def apply_decision(spec, reply):
    """Apply IDs to the saved AST; no generated SQL is ever accepted here."""
    if not isinstance(reply, str) or not reply.strip():
        raise InvalidDecision("Decision must be a nonempty string")
    reply = reply.strip()
    if reply == "UNCHANGED":
        return EditResult("unchanged", spec.source_sql, ())
    if reply == "UNRESOLVED":
        return EditResult("unresolved", None, ())
    prefix = "P" if spec.operation == "projection" else "F"
    if not re.fullmatch(fr"{prefix}\d+(?:\s*,\s*{prefix}\d+)*", reply):
        raise InvalidDecision("Reply only with candidate IDs, UNCHANGED, or UNRESOLVED")
    ids = tuple(part.strip() for part in reply.split(","))
    by_id = {candidate.id: candidate for candidate in spec.candidates}
    if len(set(ids)) != len(ids) or any(value not in by_id for value in ids):
        raise InvalidDecision("Candidate IDs must be known and distinct")
    if spec.operation == "field" and len(ids) != 1:
        raise InvalidDecision("Field replacement requires exactly one candidate ID")
    tree = _select(spec.source_sql)
    if spec.operation == "projection":
        if ids == tuple(candidate.id for candidate in spec.candidates):
            return EditResult("unchanged", spec.source_sql, ids)
        expressions = {f"P{index}": expression for index, expression in enumerate(tree.expressions, 1)}
        tree.set("expressions", [expressions[value].copy() for value in ids])
    elif spec.operation == "field":
        node = next(node for index, (_, node) in enumerate(_field_nodes(tree), 1)
                    if spec.target_id == f"T{index}")
        replacement = parse_query("SELECT " + by_id[ids[0]].sql).expressions[0]
        sources = _physical_sources(tree, json.loads(spec.context_json)["schema"])
        if node.table:
            bindings = {alias.casefold() for alias, _ in sources
                        if alias.casefold() == node.table.casefold()}
        else:
            bindings = {alias.casefold() for alias, table in sources
                        if any(column["name"].casefold() == node.name.casefold()
                               for column in table["columns"])}
        if (node.name.casefold() == replacement.name.casefold()
                and bindings == {replacement.table.casefold()}):
            return EditResult("unchanged", spec.source_sql, ids)
        node.replace(replacement.copy())
    else:
        raise InvalidDecision("Unknown operation")
    return EditResult("edited", tree.sql(dialect="sqlite"), ids)
