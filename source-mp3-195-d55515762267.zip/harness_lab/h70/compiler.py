"""Compile a joint decision about row identity, relationship roles and qualifying records.

Only one-/two-hop paths of declared, single-column foreign keys are used. Each option
is a complete interpretation of the existing projection. Its SQL is prepared against
the public schema before it can appear in the choice menu.
"""
import re
from collections import defaultdict
from dataclasses import dataclass

from sqlglot import exp
from sqlglot.errors import SqlglotError

from agent_v10.join_repair import _schema_tables
from harness_lab.h41.intent import tokens
from harness_lab.h60.agent import sql_candidate
from harness_lab.h69.binding import _conjuncts, _resolve, _scope
from mp3_sql.sqlite_tool import validate_sql

_LIMIT = 18
_STOP = set(tokens("id code key by with from to of in for the a an at data ref row table number"))
_NEG = re.compile(r"\b(no|not|never|without|neither|don't|doesn't|haven't|hasn't)\b", re.I)
_MEMBER = re.compile(r"\b(with|have|has|had|having|who|whose|that|which|without|not|never|any|at least|each|every|per|among|both|part of|belong)\b", re.I)
_RANK = re.compile(r"\b(most|fewest|greatest number of|least number of|largest number of|smallest number of)\b", re.I)


def _words(s):
    return set(tokens(s)) - _STOP


def _t(name):
    return exp.Table(this=exp.to_identifier(name, quoted=True))


def _c(tab, name):
    return exp.column(name, table=tab, quoted=True)


def _sql(node):
    return node.sql(dialect="sqlite", comments=False)


@dataclass(frozen=True)
class Edge:
    child: str
    fk: str
    parent: str
    pk: str

    def other(self, name):
        return self.parent if self.child == name else self.child

    def predicate(self):
        return exp.EQ(this=_c(self.child, self.fk), expression=_c(self.parent, self.pk))

    def role(self):
        return f"{self.child}.{self.fk} = {self.parent}.{self.pk}"


def _graph(tables):
    graph = defaultdict(list)
    for t in tables.values():
        child = t["name"]
        fields = {c["name"].casefold(): c["name"] for c in t["columns"]}
        for f in t["foreign_keys"]:
            parent = tables.get((f.get("table") or "").casefold())
            if not parent or parent["name"] == child or f.get("seq"):
                continue
            pk = [c["name"] for c in parent["columns"] if c["pk"]]
            fk = fields.get((f.get("from") or "").casefold())
            if not fk or len(pk) != 1 or pk[0].casefold() != (f.get("to") or "").casefold():
                continue
            edge = Edge(child, fk, parent["name"], pk[0])
            if edge not in graph[child]:
                graph[child].append(edge)
                graph[parent["name"]].append(edge)
    return graph


def _paths(anchor, graph):
    for first in graph[anchor]:
        mid = first.other(anchor)
        yield [first], [anchor, mid]
        for second in graph[mid]:
            last = second.other(mid)
            if last != anchor:
                yield [first, second], [anchor, mid, last]


def _prepare(tree, tables):
    """Qualify expressions against the original scope before rebuilding its FROM."""
    if not isinstance(tree, exp.Select) or tree.find(exp.With, exp.Window, exp.SetOperation):
        raise ValueError("unsupported scope")
    if any(isinstance(n, exp.Select) and n is not tree for n in tree.walk()):
        raise ValueError("nested scopes require separate binding")
    scope = _scope(tree, tables)
    used = {table["name"] for _, table in scope.values()}
    if not used or len(used) != len(scope) or any(isinstance(n, exp.Star) and not isinstance(n.parent,exp.Count) for n in tree.walk()):
        raise ValueError("no unique physical sources")
    labels = {expr.alias.casefold() for expr in tree.expressions if expr.alias}
    for col in list(tree.find_all(exp.Column)):
        ref = _resolve(col, scope)
        if ref:
            col.replace(_c(ref[1]["name"], ref[2]["name"]))
        elif col.name.casefold() not in labels or col.table or not col.find_ancestor(exp.Order, exp.Group, exp.Having):
            raise ValueError("unbound source column")
    # Extra ON filters affect membership and must not be lost when changing a path.
    conditions = list(_conjuncts(tree.args["where"].this)) if tree.args.get("where") else []
    for join in tree.args.get("joins", []):
        if join.kind not in ("", "INNER") or join.side not in ("", "LEFT") or join.method or join.args.get("using"):
            raise ValueError("unsupported join")
        extras = []
        for cond in _conjuncts(join.args.get("on")):
            if not (isinstance(cond, exp.EQ) and isinstance(cond.this, exp.Column)
                    and isinstance(cond.expression, exp.Column)):
                extras.append(cond)
        if join.side and extras:
            raise ValueError("outer join with an ON filter")
        conditions.extend(extras)
    return used, conditions


def _tables(expr):
    return {c.table for c in expr.find_all(exp.Column) if c.table}


def _pk(table):
    found = [c["name"] for c in table["columns"] if c["pk"]]
    return found[0] if len(found) == 1 else None


def _replace_frame(tree, anchor, outer, conditions):
    out = tree.copy()
    out.set("from", exp.From(this=_t(anchor)))
    out.set("joins", [])
    out.set("where", exp.Where(this=exp.and_(*(e.copy() for e in conditions))) if conditions else None)
    out.set("expressions", [e.copy() for e in outer])
    return out


def _inner(nodes, edges, filters, value):
    """Correlate the first edge with an outer entity; join subsequent tables inside."""
    query = exp.select(value).from_(_t(nodes[1]))
    for node, edge in zip(nodes[2:],edges[1:]):
        query = query.join(_t(node), on=edge.predicate())
    return query.where(exp.and_(edges[0].predicate(), *(c.copy() for c in filters)))


def _exact_or_fk(col, anchor, path):
    if col.table == anchor:
        return col.copy()
    if path:
        first = path[0]
        if first.parent == anchor and col.table == first.child and col.name.casefold() == first.fk.casefold():
            return _c(anchor, first.pk)
    return None


def _outside(expr, anchor, path):
    bad = False
    def transform(n):
        nonlocal bad
        if isinstance(n, exp.Column) and n.table:
            result = _exact_or_fk(n, anchor, path)
            if result is None:
                bad = True
            else:
                return result
        return n
    ret = expr.transform(transform)
    return None if bad else ret


def _role_score(question_words, names, edges, used):
    # An unmentioned endpoint may still be identified by a role such as authorised_by.
    end = names[-1]
    endpoint = len((_words(end) - _words(names[0])) & question_words)
    role = max((len((_words(e.fk) - _words(e.parent)) & question_words) for e in edges), default=0)
    if end not in used and not (role or endpoint):
        return None
    if len(edges) == 2 and not (endpoint or names[-1] in used):
        return None
    return 3 * endpoint + 3 * role + int(end in used) - len(edges)


def _rank_scope(tree, tables, question):
    """Lift the simple top-N membership draft into the new relationship decision."""
    if not _RANK.search(question) or not isinstance(tree,exp.Select) or not tree.args.get("where"):
        return
    pred = tree.args["where"].this
    if not isinstance(pred,exp.In) or not isinstance(pred.this,exp.Column) or not pred.args.get("query"):
        return
    sub = pred.args["query"].this
    if not isinstance(sub,exp.Select) or not sub.args.get("limit") or not sub.args.get("order"):
        return
    if any(sub.args.get(k) for k in ("where","group","having","with","joins","offset")):
        return
    outer, inner = _scope(tree,tables), _scope(sub,tables)
    if len(outer)!=1 or len(inner)!=1 or len(sub.expressions)!=1:
        return
    lhs, rhs = _resolve(pred.this,outer), _resolve(sub.expressions[0],inner)
    if not lhs or not rhs:
        return
    pk, fk = lhs[2]["name"], rhs[2]["name"]
    if not any((f.get("from"),f.get("to"),f.get("table"))==(fk,pk,lhs[1]["name"]) for f in rhs[1]["foreign_keys"]):
        return
    tree.set("where",None)
    return rhs[1]["name"]


def _membership(anchor, nodes, edges, conditions, negative):
    # Split a disjunction between a condition on the subject and one on its
    # details. A subject satisfying its own branch can have no details at all.
    filters, inner, alternative = [], [], None
    for cond in conditions:
        if _tables(cond) <= {anchor}:
            filters.append(cond)
        elif not negative and alternative is None and isinstance(cond,exp.Or):
            a,b = cond.this,cond.expression
            if _tables(a) <= {anchor} and anchor not in _tables(b):
                alternative = a
                inner.append(b)
            elif _tables(b) <= {anchor} and anchor not in _tables(a):
                alternative = b
                inner.append(a)
            else:
                inner.append(cond)
        else:
            inner.append(cond)
    # With another mandatory child filter, the parent-only branch also needs
    # a qualifying child. Leave that more complicated quantifier unsupported.
    if alternative is not None and len(inner)>1:
        return None
    exists = exp.Exists(this=_inner(nodes,edges,inner,exp.Literal.number(1)))
    if alternative is not None:
        exists = exp.or_(alternative.copy(),exists)
    filters.append(exp.Not(this=exists) if negative else exists)
    return filters


def _methods(tree, used, conditions, tables, graph, question, rank_only):
    aggs = list(tree.find_all(exp.AggFunc))
    if any(not isinstance(a,(exp.Avg, exp.Sum, exp.Count, exp.Min, exp.Max)) for a in aggs):
        return
    group = tree.args.get("group")
    counted = bool(group and any(isinstance(a, exp.Count) for a in aggs))
    if group and not counted:
        return
    qwords = _words(question)
    rank = _RANK.search(question)
    k = re.search(r"\b(?:top|bottom|first)\s+([1-9][0-9]?)\b",question,re.I)
    count_limit = int(k[1]) if k else 1
    anchors = sorted({t["name"] for t in tables.values() if t["name"] in used or _words(t["name"]) & qwords})
    column_aggs = any(isinstance(a, exp.Count) and not isinstance(a.this, exp.Star) for a in aggs)
    for anchor in anchors:
        # Counting a parent entity can change COUNT(non-null detail) to COUNT(*);
        # scalar AVG/SUM retain the actual measured parent field.
        outer = [e.copy() for e in tree.expressions]
        if not group and column_aggs:
            for e in outer:
                for count in e.find_all(exp.Count):
                    if isinstance(count.this, exp.Star):
                        continue
                    arg = count.this
                    if isinstance(arg, exp.Distinct) and len(arg.expressions) == 1:
                        arg = arg.expressions[0]
                    if not isinstance(arg, exp.Column):
                        break
                    if arg.table == anchor and arg.name != _pk(tables[anchor.casefold()]):
                        continue
                    count.set("this", exp.Star())
        # Grouping an aggregate by a genuine property (year, region, etc.) is
        # not equivalent to grouping by an entity. Only present a distinct
        # entity hypothesis when its name or a displayed identifier supports it.
        general = 2 * len(_words(anchor) & qwords)
        for edges, nodes in _paths(anchor,graph):
            relation_score = _role_score(qwords, nodes, edges, used)
            if relation_score is None:
                continue
            inner_conds, outer_conds = [], []
            supported = True
            for cond in conditions:
                refs = _tables(cond)
                if refs <= {anchor}:
                    outer_conds.append(cond)
                elif refs <= set(nodes):
                    inner_conds.append(cond)
                else:
                    supported = False
                    break
            if not supported:
                continue
            if not (len(used) > 1 or counted or _MEMBER.search(question) or _NEG.search(question)):
                continue
            role = " and ".join(e.role() for e in edges)
            detail = nodes[-1]
            relevance = general + relation_score
            # Repair a draft which ranks by an unrelated value even when it
            # did not already express the intended aggregate or join.
            if rank and not any(e.find(exp.AggFunc) for e in tree.expressions):
                ranked_outputs = [_outside(e,anchor,edges) for e in tree.expressions]
                if all(e is not None for e in ranked_outputs) and not tree.args.get("having"):
                    ascending = bool(re.match("fewest|least|smallest",rank[1],re.I))
                    measure = _inner(nodes,edges,inner_conds,exp.Count(this=exp.Star()))
                    for positive in (False,True):
                        population = list(outer_conds)
                        if positive:
                            population.append(exp.Exists(this=_inner(nodes,edges,inner_conds,exp.Literal.number(1))))
                        new = _replace_frame(tree,anchor,ranked_outputs,population)
                        new.set("group",None)
                        order = exp.Ordered(this=measure.subquery(),desc=not ascending,nulls_first=ascending)
                        new.set("order",exp.Order(expressions=[order]))
                        new.set("limit",exp.Limit(expression=exp.Literal.number(count_limit)))
                        mode = "positive counts only" if positive else "including zero counts"
                        direction = "fewest" if ascending else "most"
                        yield relevance+3, f"Rank {anchor} by {direction} matching {detail} records via {role}; {mode}; take {count_limit}.",new
            if rank_only:
                continue
            if counted:
                if any(not isinstance(a, exp.Count) for a in aggs) or not _pk(tables[anchor.casefold()]):
                    continue
                if not any(_tables(e) for e in tree.expressions if not e.find(exp.AggFunc)):
                    # A count-only projection with one group per entity is valid,
                    # but needs a bound, explicit grouping column.
                    if not all(isinstance(c,exp.Column) for c in group.expressions):
                        continue
                groups = [_outside(e,anchor,edges) for e in group.expressions]
                if any(g is None for g in groups):
                    continue
                ids = _pk(tables[detail.casefold()])
                measures = [("row", exp.Count(this=exp.Star()))]
                if ids and len(edges)>1:
                    measures.append((f"distinct {detail}.{ids}", exp.Count(this=exp.Distinct(expressions=[_c(detail,ids)]))))
                for description, measure in measures:
                    correlated = _inner(nodes, edges, inner_conds, measure)
                    # Check every non-aggregate outer expression before inserting nested subqueries.
                    marker = lambda n: exp.Literal.number(0) if isinstance(n, exp.Count) else n
                    attrs = [*tree.expressions,*(tree.args[k] for k in ("order","having") if tree.args.get(k))]
                    if any(_outside(e.transform(marker),anchor,edges) is None for e in attrs):
                        continue
                    def output(e):
                        def sub(n):
                            if isinstance(n, exp.Count):
                                return correlated.subquery()
                            if isinstance(n, exp.Column) and n.table:
                                return _exact_or_fk(n,anchor,edges)
                            return n
                        return e.transform(sub)
                    outs = [output(e) for e in tree.expressions]
                    for population in ("all","matched"):
                        filters = list(outer_conds)
                        if tree.args.get("having"):
                            filters.append(output(tree.args["having"].this))
                        if population == "matched":
                            filters.append(exp.Exists(this=_inner(nodes,edges,inner_conds,exp.Literal.number(1))))
                        new = _replace_frame(tree,anchor,outs,filters)
                        new.set("group",None)
                        new.set("having",None)
                        if tree.args.get("order"):
                            new.set("order",output(tree.args["order"]))
                        pop = f"include {anchor} with zero matches" if population=="all" else f"only {anchor} with matches"
                        yield relevance, f"One row per {anchor}; count {detail} ({description}) via {role}; {pop}.", new
                continue
            outs = [_outside(e,anchor,edges) for e in outer]
            order = tree.args.get("order")
            if any(o is None for o in outs) or (order and _outside(order,anchor,edges) is None):
                continue
            # A wholly unfiltered, single-table SELECT is already the all-entities version.
            if len(used)>1 and not inner_conds:
                new = _replace_frame(tree,anchor,outs,outer_conds)
                if order:
                    new.set("order",_outside(order,anchor,edges))
                yield general+1, f"Each {anchor} contributes once; use its own rows including those without related records.", new
            for negative in (False,True) if _NEG.search(question) else (False,):
                filters = _membership(anchor,nodes,edges,conditions,negative)
                if filters is None:
                    continue
                new = _replace_frame(tree,anchor,outs,filters)
                if order:
                    new.set("order",_outside(order,anchor,edges))
                mode = "no" if negative else "at least one"
                desc = f"Each {anchor} contributes once; require {mode} matching {detail} via {role}."
                if any(isinstance(x,exp.Or) for x in filters):
                    desc += " Honor the subject's own alternative even with no related rows."
                yield relevance + int(negative), desc, new
                if negative:
                    # Old outer-join absence sentinels do not belong in NOT EXISTS.
                    outer_nulls = [c for c in inner_conds if isinstance(c,exp.Is) and isinstance(c.expression,exp.Null)
                                   and isinstance(c.this,exp.Column) and _words(c.this.name) - qwords
                                   and not qwords & {"null","missing","unknown","unspecified"}]
                    if outer_nulls and len(outer_nulls)<len(inner_conds):
                        reduced = [c for c in conditions if c not in outer_nulls]
                        clean = _replace_frame(tree,anchor,outs,_membership(anchor,nodes,edges,reduced,True))
                        if order:
                            clean.set("order",_outside(order,anchor,edges))
                        yield relevance+2,desc+" Drop the draft's NULL test on "+", ".join(_sql(c.this) for c in outer_nulls)+".",clean


def plans(question,schema,current_sql):
    keep = {"key":"KEEP","label":"Keep the current query's rows, relationship and inclusion rule.","sql":current_sql}
    try:
        tables = _schema_tables(schema)
        tree = validate_sql(current_sql)
        inner_rank = _rank_scope(tree,tables,question)
        used, conditions = _prepare(tree,tables)
        if inner_rank:
            used.add(inner_rank)
        graph = _graph(tables)
        items = sorted(_methods(tree,used,conditions,tables,graph,question,bool(inner_rank)), key=lambda x:(-x[0],x[1]))
    except (ValueError,SqlglotError,RecursionError):
        return [keep]
    options = [keep]
    seen = {_sql(validate_sql(current_sql))}
    for _, label, query in items:
        value = _sql(query)
        if value in seen:
            continue
        seen.add(value)
        try:
            valid = sql_candidate(value,schema)
        except (ValueError,SqlglotError,RecursionError):
            continue
        options.append({"key":f"P{len(options)}","label":label,"sql":valid})
        if len(options) >= _LIMIT:
            break
    return options
