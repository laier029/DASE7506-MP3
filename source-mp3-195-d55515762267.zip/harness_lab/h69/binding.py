"""Bind one public-schema identifier to a literal predicate or an aggregate's unit."""
import re
from collections import defaultdict

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.h60.agent import sql_candidate
from mp3_sql.sqlite_tool import validate_sql


COMPARISONS = (exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE, exp.Like)
AGGREGATES = (exp.Count, exp.Avg, exp.Sum)


def _sql(node):
    return node.sql(dialect="sqlite", comments=False)


def _words(value):
    return re.findall(r"[a-z0-9]+", re.sub(r"([a-z])([A-Z])", r"\1 \2", value).lower())


def _catalog(schema):
    return {t['name'].casefold(): t for t in schema}


def _scope(tree, catalog):
    source = tree.args.get('from')
    if not source or tree.args.get('with'):
        return {}
    aliases = {}
    for table in [source.this, *(j.this for j in tree.args.get('joins', []))]:
        if not isinstance(table, exp.Table) or table.db or table.catalog:
            return {}
        alias = table.alias_or_name.casefold()
        if alias in aliases or table.name.casefold() not in catalog:
            return {}
        aliases[alias] = (table, catalog[table.name.casefold()])
    return aliases


def _resolve(column, aliases):
    if not isinstance(column, exp.Column) or column.db or column.catalog:
        return None
    matches = [(alias, t, c) for alias, (_, t) in aliases.items()
               if not column.table or column.table.casefold() == alias
               for c in t['columns'] if c['name'].casefold() == column.name.casefold()]
    return matches[0] if len(matches) == 1 else None


def _unwrap(node):
    while isinstance(node, (exp.Lower, exp.Upper, exp.Collate, exp.Paren)):
        node = node.this
    return node


def _filter_options(tree, aliases, question):
    where = tree.args.get('where')
    if where is None:
        return []
    options = []
    for node in where.walk():
        if node.find_ancestor(exp.Select) is not tree:
            continue
        if isinstance(node, COMPARISONS):
            pairs = [(node.this, [node.expression]), (node.expression, [node.this])]
        elif isinstance(node, exp.In) and node.expressions and not node.args.get('query'):
            pairs = [(node.this, node.expressions)]
        elif isinstance(node, exp.Between):
            pairs = [(node.this, [node.args['low'], node.args['high']])]
        else:
            continue
        for candidate, values in pairs:
            col = _unwrap(candidate)
            if not isinstance(col, exp.Column):
                continue
            literals = [_unwrap(v) for v in values]
            if not all(isinstance(v, exp.Literal) for v in literals):
                continue
            ref = _resolve(col, aliases)
            current = ref[1]['name'] + '.' + ref[2]['name'] if ref else None
            values = [v.this for v in literals]
            mentioned = any(v and re.search(r'(?<!\w)' + re.escape(v.strip('%')) + r'(?!\w)', question, re.I) for v in values)
            options.append((int(mentioned), int(any(v.is_string for v in literals)), node, col, current))
    return options


def _aggs(tree):
    return [a for a in tree.find_all(exp.AggFunc) if a.find_ancestor(exp.Select) is tree]


def _pk(table):
    return {c['name'].casefold() for c in table['columns'] if c.get('pk')}


def _conjuncts(node):
    if isinstance(node, (exp.Paren, exp.And)):
        yield from _conjuncts(node.this)
        if isinstance(node, exp.And):
            yield from _conjuncts(node.expression)
    elif node is not None:
        yield node


def _inner(joins):
    return all(not j.side and not j.method and j.kind in ('', 'INNER', 'CROSS') and not j.args.get('using') for j in joins)


def _units(tree, aliases):
    """A row determines the join when all other aliases are functionally determined by it."""
    if len(aliases) == 1:
        return list(aliases)
    joins = tree.args.get('joins', [])
    if not _inner(joins):
        return []
    sources = [j.args.get('on') for j in joins]
    if tree.args.get('where'):
        sources.append(tree.args['where'].this)
    edges = defaultdict(set)
    for source in sources:
        for eq in _conjuncts(source):
            if not isinstance(eq, exp.EQ):
                continue
            a, b = _resolve(eq.this, aliases), _resolve(eq.expression, aliases)
            if a and b and a[0] != b[0]:
                edges[a[0], b[0]].add(b[2]['name'].casefold())
                edges[b[0], a[0]].add(a[2]['name'].casefold())
    units = []
    for alias in aliases:
        reached = {alias}
        while True:
            more = {b for (a, b), cols in edges.items() if a in reached and _pk(aliases[b][1]) and _pk(aliases[b][1]) <= cols}
            if more <= reached:
                break
            reached.update(more)
        if reached == set(aliases):
            units.append(alias)
    return units


def _distinct_ref(agg, aliases):
    arg = agg.this
    if not isinstance(agg, exp.Count) or not isinstance(arg, exp.Distinct) or len(arg.expressions) != 1:
        return None
    ref = _resolve(arg.expressions[0], aliases)
    if ref and _pk(ref[1]) == {ref[2]['name'].casefold()}:
        return ref
    return None


def _inspect(question, schema, sql):
    tree = validate_sql(sql)
    if not isinstance(tree, exp.Select) or tree.args.get('with'):
        return None
    catalog = _catalog(schema)
    filters = []
    for i, scope in enumerate(tree.find_all(exp.Select, bfs=False)):
        aliases = _scope(scope, catalog)
        if aliases:
            for rank1, rank2, node, col, current in _filter_options(scope, aliases, question):
                filters.append((rank1, rank2, i, node, col, current, scope, aliases))
    best = max(filters, key=lambda t: t[:2]) if filters else None
    aliases = _scope(tree, catalog)
    aggs = _aggs(tree)
    unit = None
    if aliases and aggs and all(isinstance(a, AGGREGATES) for a in aggs) and not tree.find(exp.Window):
        units = _units(tree, aliases)
        distinct = [_distinct_ref(a, aliases) for a in aggs]
        if any(isinstance(a.this, exp.Distinct) for a in aggs):
            units = list({r[0] for r in distinct}) if all(distinct) else []
        names = {aliases[a][1]['name'] for a in units}
        current = next(iter(names)) if len(names) == 1 else None
        aggregate = ', '.join(dict.fromkeys(_sql(a) for a in aggs))
        relations = ', '.join(t.sql(dialect='sqlite') for t, _ in aliases.values())
        unit = ({'kind':'unit', 'slot':f'{aggregate} FROM {relations}', 'current':current}, tree, aliases, aggs)
    # A literal already supplies a narrow question. Prefer the unit for an exposed
    # parent-valued measure, or when the question directly names a different counted table.
    prefer_unit = False
    if unit and len(aliases) > 1:
        measure_refs = [_resolve(a.this, aliases) for a in aggs if isinstance(a, (exp.Sum, exp.Avg))]
        prefer_unit = any(r and r[0] not in units for r in measure_refs)
        count_noun = re.search(r'\b(?:how many|(?:the )?number of|count (?:the )?)\s+([\w-]+)', question, re.I)
        if count_noun and all(isinstance(a, exp.Count) for a in aggs):
            noun = count_noun[1].casefold().rstrip('s')
            prefer_unit |= any(alias not in units and noun == t['name'].casefold().rstrip('s') for alias, (_, t) in aliases.items())
    if best and not prefer_unit:
        _, _, scope_i, node, col, current, scope, aliases = best
        return ({'kind':'filter', 'slot':_sql(node), 'current':current, 'scope':scope_i}, tree, aliases, (node, col))
    return unit


def inspect_task(question, schema, sql):
    try:
        data = _inspect(question, schema, sql)
        return data[0] if data else None
    except (ValueError, SqlglotError, RecursionError):
        return None


def _answer(schema, kind, label):
    matches = []
    for table in schema:
        if kind == 'unit' and table['name'].casefold() == label.casefold():
            matches.append((table, None))
        if kind == 'filter':
            matches.extend((table, c) for c in table['columns'] if (table['name'] + '.' + c['name']).casefold() == label.casefold())
    return matches[0] if len(matches) == 1 else None


def _column(col, table):
    return exp.column(col, table=table, quoted=True)


def _edit_filter(question, selected, alias, data):
    site, tree, aliases, (pred, old) = data
    table, col = selected
    same = site['current'] == table['name'] + '.' + col['name']
    requested = bool(re.search(r'\b(?:case[- ]insensitive(?:ly)?|ignore case|regardless of case)\b', question, re.I))
    categorical = bool(set(_words(col['name'])) & {'category','type','class','classification','level','rank','status','role','sex','gender','color','colour','position'})
    # SQLite NOCASE is ASCII-only. Fold plain, alphabetic category comparisons after
    # a rebind; keep identifiers, names, mixed alphanumeric codes and explicit collation intact.
    literal = pred.expression if pred.this is old else pred.this
    plain_text = (isinstance(pred, (exp.EQ, exp.NEQ)) and (pred.this is old or pred.expression is old)
                  and isinstance(literal, exp.Literal) and literal.is_string and literal.this.isascii()
                  and re.fullmatch(r'[A-Za-z][A-Za-z -]*', literal.this))
    sensitive = re.search(r'\b(?:case[- ]sensitive|exact case)\b', question, re.I)
    fold = plain_text and not sensitive and (requested or (categorical and not same))
    if same and not fold:
        return 'keep'
    new = _column(col['name'], aliases[alias][0].alias_or_name)
    if fold:
        new = exp.Collate(this=new, expression=exp.Var(this='NOCASE'))
    old.replace(new)
    return None


def _entity_count(tree, aliases, aggs, alias):
    table_expr, table = aliases[alias]
    keys = [c['name'] for c in table['columns'] if c.get('pk')]
    if len(keys) != 1:
        return 'unsupported_count_identity'
    pk = _column(keys[0], table_expr.alias_or_name)
    for agg in aggs:
        ref = _distinct_ref(agg, aliases)
        if isinstance(agg.this, exp.Distinct):
            if not ref:
                return 'unsupported_distinct_measure'
        elif not isinstance(agg.this, exp.Star):
            ref = _resolve(agg.this, aliases)
            if not ref or (_pk(ref[1]) != {ref[2]['name'].casefold()} and not ref[2].get('not_null')):
                return 'unsupported_nullable_count'
        if ref and ref[0] != alias and any(j.side for j in tree.args.get('joins', [])):
            return 'unsupported_outer_count_nulls'
        agg.set('this', exp.Distinct(expressions=[pk.copy()]))
    return None


def _entity_exists(tree, aliases, aggs, alias):
    joins = tree.args.get('joins', [])
    if (not _inner(joins) or any(a.find_ancestor(exp.Select) is not tree for a in tree.find_all(exp.Column))
            or any(isinstance(a.this, exp.Distinct) for a in aggs)):
        return 'unsupported_semijoin_shape'
    qualifiers = {n for j in joins for n in j.walk()}
    if tree.args.get('where'):
        qualifiers.update(tree.args['where'].walk())
    output_names = {e.alias.casefold() for e in tree.expressions if e.alias}
    if any(isinstance(e, exp.Star) for e in tree.expressions):
        return 'unsupported_wildcard'
    for col in list(tree.find_all(exp.Column)):
        ref = _resolve(col, aliases)
        if ref is None:
            if col not in qualifiers and not col.table and col.name.casefold() in output_names:
                continue
            return 'unsupported_unbound_expression'
        if col not in qualifiers and ref[0] != alias:
            return 'unsupported_measure_or_group_outside_unit'
        col.set('table', exp.to_identifier(aliases[ref[0]][0].alias_or_name, quoted=True))
    others = [node for a, (node, _) in aliases.items() if a != alias]
    if not others:
        return 'keep'
    query = exp.select('1').from_(others[0].copy())
    for other in others[1:]:
        query = query.join(other.copy(), join_type='CROSS')
    restrictions = [j.args['on'].copy() for j in joins if j.args.get('on') is not None]
    if tree.args.get('where'):
        restrictions.append(tree.args['where'].this.copy())
    if restrictions:
        query = query.where(exp.and_(*restrictions))
    tree.set('from', exp.From(this=aliases[alias][0].copy()))
    tree.set('joins', [])
    tree.set('where', exp.Where(this=exp.Exists(this=query)))
    return None


def _edit_unit(alias, data):
    site, tree, aliases, aggs = data
    if any(isinstance(a.this, exp.Distinct) for a in aggs):
        if all((r := _distinct_ref(a, aliases)) and r[0] == alias for a in aggs):
            return 'keep'
    elif alias in _units(tree, aliases):
        return 'keep'
    if all(isinstance(a, exp.Count) for a in aggs):
        # Identity counting retains group labels and predicates on the joined rows.
        reason = _entity_count(tree, aliases, aggs, alias)
        if reason == 'unsupported_count_identity' and all(isinstance(a.this, exp.Star) for a in aggs):
            return _entity_exists(tree, aliases, aggs, alias)
        return reason
    return _entity_exists(tree, aliases, aggs, alias)


def compile_binding(question, schema, sql, site, answer):
    if answer is None:
        return {'sql':None, 'reason':'abstain'}
    try:
        data = _inspect(question, schema, sql)
        if not data or site != data[0]:
            return {'sql':None, 'reason':'unsupported_or_stale_site'}
        selected = _answer(schema, site['kind'], answer) if isinstance(answer, str) else None
        if selected is None:
            return {'sql':None, 'reason':'unknown_schema_identifier'}
        names = [a for a, (_, t) in data[2].items() if t['name'] == selected[0]['name']]
        if len(names) != 1:
            return {'sql':None, 'reason':'unsupported_table_outside_scope' if not names else 'unsupported_multiple_table_aliases'}
        reason = (_edit_filter(question, selected, names[0], data) if site['kind'] == 'filter' else _edit_unit(names[0], data))
        if reason:
            return {'sql':None, 'reason':reason}
        return {'sql':sql_candidate(_sql(data[1]), schema), 'reason':'compiled'}
    except (ValueError, SqlglotError, RecursionError) as exc:
        return {'sql':None, 'reason':'unsupported_sql', 'detail':str(exc)}
