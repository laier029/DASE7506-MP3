"""Model-first SQL repair using only the official observation and real checked candidates."""
import json
from functools import lru_cache
from pathlib import Path
import re

from harness_lab.h57.protocol import bind
from mp3_sql.sqlite_tool import validate_sql

CAP = 384
SYSTEM = (
    "Repair the original SQLite query to answer the question. Use the schema and the actual "
    "public check. Work out what one result row represents, which records qualify, and which "
    "columns are requested. A public check covers one instance. If the original query already "
    "answers the question, return it unchanged. Otherwise return the complete corrected query. "
    "Use only a single read-only SELECT or WITH query, without markdown or explanation."
)


def messages(question, schema, original_sql, original_check, example, ordered, attempt=None):
    payload = {"question": question, "schema": schema, "original_sql": original_sql,
               "expected_example": example, "ordered": ordered, "original_check": original_check}
    system = SYSTEM
    if attempt is not None:
        payload["previous_attempt"] = attempt
        system += " Your previous answer failed validation or its public check. Use that feedback to repair it."
    return [{"role": "system", "content": system},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False, separators=(",", ":"))}]


def sql_candidate(text, schema):
    sql = text.strip()
    if not re.match(r"^(SELECT|WITH)\b", sql, re.IGNORECASE):
        raise ValueError("Expected a complete standalone SELECT or WITH query")
    validate_sql(sql)
    bind(sql, schema)
    return sql


def checked(history, sql):
    return next((e["observation"] for e in history if e["tool"] == "check" and e["sql"] == sql), None)


def matched(check):
    return bool(check and check["ok"] and check["matches_example"])


class PrimaryAgent:
    def __init__(self, model, max_calls=2):
        if max_calls not in (1, 2):
            raise ValueError("Expected one or two model calls")
        self.model = model
        self.max_calls = max_calls
        self.attempts = []
        self.context = None
        self.decision = None

    def act(self, obs):
        history = obs["history"]
        original = obs["issue_sql"]
        if not history:
            return {"tool": "schema"}
        original_check = checked(history, original)
        if original_check is None:
            return {"tool": "check", "sql": original}
        if self.context is None:
            self.context = dict(question=obs["task"]["question"], schema=history[0]["observation"],
                                original_sql=original, original_check=original_check,
                                example=obs["example"], ordered=obs["ordered"])

        while True:
            prior = self.attempts[-1] if self.attempts else None
            if prior is not None:
                if prior["sql"]:
                    result = checked(history, prior["sql"])
                    if result is None:
                        return {"tool": "check", "sql": prior["sql"]}
                    prior["check"] = result
                prior["retry_input"] = {"text": prior["text"], "check": prior["check"], "error": prior["error"]}
                if matched(prior["check"]) or len(self.attempts) == self.max_calls:
                    break
            turns = messages(**self.context, attempt=prior["retry_input"] if prior is not None else None)
            gen = self.model.dialog(turns, cap=CAP)
            text = gen["text"] or gen["raw_text"]
            record = {"text": text, "sql": None, "check": None, "error": None, "generation": gen}
            if gen["truncated"] or gen["status"] != "generated":
                record["error"] = "Incomplete model output: " + ("token limit" if gen["truncated"] else gen["status"])
            else:
                try:
                    record["sql"] = sql_candidate(text, self.context["schema"])
                except (ValueError, RecursionError) as exc:
                    record["error"] = str(exc)
            self.attempts.append(record)

        # A tie on the single public instance does not establish that a replacement is better.
        chosen, reason = original, "original_public_match" if matched(original_check) else "original_fallback"
        if not matched(original_check):
            for i in range(len(self.attempts) - 1, -1, -1):
                a = self.attempts[i]
                if a["check"] and a["check"]["ok"]:
                    chosen = a["sql"]
                    reason = ("public_match" if matched(a["check"]) else "executable_unresolved") + f"_attempt_{i+1}"
                    break
        self.decision = {"sql": chosen, "reason": reason, "check": checked(history, chosen)}
        return {"tool": "submit", "sql": chosen}


@lru_cache(maxsize=2)
def shared_model(adapter):
    from harness_lab.h59.model import Model
    return Model(adapter=adapter)


def create_agent(checkpoint=None):
    """A fresh episode; immutable model weights may be shared between sequential episodes."""
    cfg = json.loads(Path(checkpoint).read_text()) if checkpoint else {}
    adapter = cfg.get("adapter")
    if adapter and not Path(adapter).is_absolute():
        adapter = Path(checkpoint).resolve().parent / adapter
    return PrimaryAgent(shared_model(str(adapter) if adapter else None), cfg.get("max_calls", 2))
