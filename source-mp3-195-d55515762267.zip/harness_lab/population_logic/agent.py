"""Use real public feedback to review the population named in a boolean requirement."""
from sqlglot import exp
from sqlglot.errors import SqlglotError
from harness_lab.intent_repair.pool import sql_key
from harness_lab.intent_repair.semantics import Requirement
from harness_lab.population_logic.compose import plans_for
from mp3_sql.sqlite_tool import validate_sql


def inconsistent(tree,reason):
    if reason.startswith('restrict an unqualified comparator'):
        return True
    if reason.startswith('apply either'):
        return bool(tree.find(exp.Join)) or not tree.find(exp.In,exp.Or)
    if reason.endswith('by intersect'):
        return not tree.find(exp.Intersect) or len(list(tree.find_all(exp.Join)))>2
    if reason.endswith('by except'):
        return not tree.find(exp.Except)
    if reason.endswith('by union'):
        return not tree.find(exp.Or,exp.Union,exp.In)
    if reason.startswith('combine the global'):
        return not tree.find(exp.Union,exp.Or)
    if reason.startswith('qualify each entity'):
        return not tree.find(exp.Having) or not tree.find(exp.Max,exp.Min)
    return False


class PopulationAgent:
    def __init__(self,old,mode):
        self.old=old
        self.mode=mode
        self.fallback=None
        self.candidates=[]
        self.decision={}

    def act(self,obs):
        checks={sql_key(h['sql']):h for h in obs['history'] if h['tool']=='check'}
        if self.fallback is None:
            action=self.old.act(obs)
            if action['tool']!='submit':
                return action
            sql=action['sql'];key=sql_key(sql)
            schema=next((h['observation'] for h in obs['history'] if h['tool']=='schema'),None)
            if not schema:return action
            req=Requirement(obs['task']['question'],obs['example']['columns'],schema)
            hints=next((h['observation'] for h in obs['history'] if h['tool']=='repair_hint'),[])
            sources=[sql,obs['issue_sql']]+[h['sql'] for h in checks.values()]+[x for x in hints if isinstance(x,str)]
            passed=checks.get(key,{}).get('observation',{}).get('matches_example',False)
            try:
                tree=validate_sql(sql)
                self.candidates=[c for c in plans_for(req,sources,self.mode) if sql_key(c[1])!=key and (not passed or inconsistent(tree,c[2]))][:2]
            except (ValueError,SqlglotError,RecursionError):
                return action
            self.fallback=sql
        for score,candidate,reason in self.candidates:
            known=checks.get(sql_key(candidate))
            if known and known['observation']['matches_example']:
                self.decision=dict(evidence=reason,score=score)
                return dict(tool='submit',sql=known['sql'])
            if known is None and obs['remaining']:
                return dict(tool='check',sql=candidate)
        return dict(tool='submit',sql=self.fallback)
