"""Construct the qualifying population of each explicit boolean branch before projecting."""
import re
from collections import defaultdict

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.h41.intent import primary
from harness_lab.grain_repair.scopes import comparison_probe
from harness_lab.intent_repair.pool import sql_key
from harness_lab.intent_repair.reconstruct import projected, sources, group_bound
from harness_lab.intent_repair.roles import plans
from harness_lab.intent_repair.semantics import column, rendered, table, words
from mp3_sql.sqlite_tool import validate_sql

COMPARISON = (exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE, exp.Like)
STOP = set('a an the of in as all have both some is are for with at to their that or and but not by has whose his its those into this out there many what which show list find give me how on from per number'.split())


def terms(text):
    return set(words(text)) - STOP


def connected(req, root, fields, tables):
    path = plans(req, root, list(dict.fromkeys(tables)))
    if path is None:
        return None
    query = exp.select(*[f.copy() for f in fields]).from_(table(root))
    for edge, destination in path:
        query = query.join(table(destination), on=edge.predicate())
    return query


def field_hint(req, text, seed=None):
    """Resolve a field only when the local words identify a unique best binding."""
    def semantic(items):
        return {'description' if w in ('describe','described','description') else w for w in items}
    wanted = semantic(terms(text))
    result = []
    for owner in req.schema:
        for c in owner['columns']:
            field = semantic(words(c['name']))
            including_table = set(words(owner['name'])) | field
            domain = field & wanted
            if not domain:
                continue
            score = 2*len(domain) + len(including_table & wanted) + int(field <= wanted) - .25*len(field-wanted)
            if seed and (owner['name'].lower(), c['name'].lower()) == (seed[0].lower(), seed[1].lower()):
                score += .2
            result.append((score, (owner['name'],c['name'])))
    result.sort(reverse=True)
    if result and (len(result)==1 or result[0][0]>result[1][0]):
        return result[0][1]
    return seed


def observed_atoms(req, trees):
    """Only literals actually present in the question are eligible as predicate evidence."""
    atoms = defaultdict(list)
    for tree in trees:
        for atom in tree.find_all(*COMPARISON, exp.In):
            if not isinstance(atom.this, exp.Column):
                continue
            host=atom.find_ancestor(exp.Select)
            if host is None:
                continue
            ref = req.required(atom.this, sources(host,req))
            if not ref:
                continue
            vals=atom.expressions if isinstance(atom, exp.In) else [atom.expression]
            for lit in vals:
                if not isinstance(lit,exp.Literal):
                    continue
                value = lit.name.strip('%')
                if not value or not re.search(r'(?<!\w)'+re.escape(value)+r'(?!\w)',req.text,re.I):
                    continue
                record=(ref, exp.EQ if isinstance(atom,exp.In) else type(atom),lit)
                if record not in atoms[value.casefold()]:
                    atoms[value.casefold()].append(record)
    return atoms


def atom_for(req, fragment, atoms, inherited='', grounded=False):
    matches=[]
    for value, bindings in atoms.items():
        found=re.search(r'(?<!\w)'+re.escape(value)+r'(?!\w)',fragment,re.I)
        if found:
            matches.append((found.start(),value,bindings))
    if len(matches)!=1:
        return None
    at,value,bindings=matches[0]
    # Include field clues next to this value, with the existing SQL as secondary evidence.
    near=fragment[max(0,at-45):at]+' '+fragment[at+len(value):at+len(value)+22]
    if not terms(near):
        near=inherited
    near=re.split(r'\b(?:have|has|whose)\s+(?:their\s+)?',near)[-1]
    ref,op,lit=bindings[0]
    strict=field_hint(req,near,ref)
    if strict is not None and (not grounded or any(f==strict for f,_,_ in bindings)):
        ref=strict
        op,lit=next(((kind,raw) for field,kind,raw in bindings if field==ref),(op,lit))
    if re.search(r'\b(above|older than|more than|higher than|over)\b',near):op=exp.GT
    if re.search(r'\b(below|younger than|less than|lower than|under)\b',near):op=exp.LT
    return ref[0],op(this=column(*ref),expression=lit.copy())


def alternatives(req,trees,grounded=False):
    if len(req.targets)!=1 or req.targets[0] is None:
        return
    q=req.text.rstrip('?.! ')
    members=re.search(r'\b(both|either)\b(.+?)\b(and|or)\b(.+)$',q)
    negative=re.search(r'\b(?:some|who have|that have|who are|with|in)\b(.+?)\bbut not\b(.+)$',q)
    plain=re.search(r'^(.+?)\bor\b(.+)$',q)
    if negative:
        left,right=negative.group(1),negative.group(2);op='except'
    elif members:
        left,right=members.group(2),members.group(4);op='intersect' if members.group(1)=='both' else 'union'
    elif plain:
        left,right=plain.groups();op='union'
    else:return
    atoms=observed_atoms(req,trees)
    shared=q[:members.start()] if members and not negative else ''
    left_atom=atom_for(req,left,atoms,shared,grounded)
    right_atom=atom_for(req,right,atoms,shared or left,grounded)
    if not left_atom or not right_atom:return
    lt,lp=left_atom;rt,rp=right_atom
    target=req.targets[0]
    ref=None
    count=isinstance(target,exp.Count)
    head=re.split(r'\b(?:that|who|whose|have|has|having|with|where|either|both|which (?:have|are))\b',q,maxsplit=1)[0]
    if count:
        # A SQL COUNT(DISTINCT attribute) establishes an actual grouping value.
        for tree in trees:
            for agg in tree.find_all(exp.Count):
                key=agg.this
                if not isinstance(key,exp.Distinct) or len(key.expressions)!=1 or not isinstance(key.expressions[0],exp.Column):
                    continue
                col=key.expressions[0]
                if not terms(col.name) <= terms(req.question):continue
                host=agg.find_ancestor(exp.Select)
                ref=req.required(col,sources(host,req))
                if ref:break
            if ref:break
        if ref is None:
            owners=[o for o in req.schema if terms(o['name']) and terms(o['name']) <= terms(head)]
            if len(owners)!=1:return
            key=primary(owners[0])
            if not key:return
            ref=(owners[0]['name'],key['name'])
    else:
        if not isinstance(target,exp.Column):return
        choices=req.owners[target.name.lower()]
        if len(choices)==1:ref=choices[0]
        elif trees:ref=req.required(target,sources(trees[0],req))
        if not ref:return
    owner,name=ref
    keys=[column(owner,name)]
    if not count and op=='union' and lt==rt==owner:
        query=exp.select(keys[0]).from_(table(owner)).where(exp.or_(lp,rp))
        if req.distinct:query=query.distinct()
        yield 14,rendered(query),'apply either condition to rows of the requested source'
        return
    # For "customers who have both X and Y", intersect on identity so homonyms
    # from different customers cannot satisfy separate halves of the request.
    entity=primary(req.tables[owner.lower()]) if not count and terms(owner) <= terms(head) else None
    if grounded and entity and op=='intersect' and lt==rt and isinstance(lp,exp.EQ) and isinstance(rp,exp.EQ) and lp.this==rp.this and lp.expression!=rp.expression:
        route=plans(req,owner,[lt])
        if route is not None and all(step.parent==dest for step,dest in route):
            return
    if entity:keys=[column(owner,entity['name'])]
    a=connected(req,owner,keys,[lt]);b=connected(req,owner,keys,[rt])
    if a is None or b is None:return
    a=a.where(lp);b=b.where(rp)
    joined={'intersect':a.intersect,'union':a.union,'except':a.except_}[op](b)
    if count:out=exp.select(exp.Count(this=exp.Star())).from_(joined.subquery('qualifying'))
    elif entity:
        out=exp.select(column(owner,name)).from_(table(owner)).where(keys[0].copy().isin(query=joined))
        if req.distinct:out=out.distinct()
    else:out=joined
    yield 13,rendered(out),'combine conditional populations by '+op


def ranked_union(req,trees):
    parts=re.split(r'\bor\b',req.text,maxsplit=1)
    if len(parts)!=2:return
    levels=[bool(re.search(r'\b(maximum|highest|largest|minimum|lowest|smallest|greatest)\b',s)) for s in parts]
    if sum(levels)!=1:return
    high=parts[levels.index(True)]
    other=parts[levels.index(False)]
    desc=bool(re.search(r'\b(maximum|highest|largest|greatest)\b',high))
    extremum=exp.Max if desc else exp.Min
    other=re.split(r'[?.!](?:\s|$)',other)[0]
    high=re.split(r'[?.!](?:\s|$)',high)[0]
    count_bound=group_bound(other)
    for tree in trees[:2]:
        seed=tree if isinstance(tree,exp.Select) else tree.find(exp.Select)
        if seed is None:continue
        for outputs in projected(req,seed,sources(seed,req)):
            all_cols=[c for item in outputs for c in item.find_all(exp.Column)]
            owners={c.table for c in all_cols}
            if len(owners)!=1:continue
            owner=next(iter(owners))
            if len(outputs)==1 and isinstance(outputs[0],(exp.Max,exp.Min)):
                if type(outputs[0]) is not extremum or len(all_cols)!=1:continue
                col=all_cols[0]
                lit=re.search(r'''(?:char(?:acter)?|contain\w*|substring)\s+['"]([^'"]+)['"]''',other)
                if not lit:continue
                a=exp.select(outputs[0].copy()).from_(table(owner))
                pattern='%'+lit[1].replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
                where=exp.Escape(this=exp.Like(this=col.copy(),expression=exp.Literal.string(pattern)),expression=exp.Literal.string('\\'))
                b=exp.select(col.copy()).from_(table(owner)).where(where)
                yield 15,rendered(a.union(b)),'combine the global extremum with independently matching values'
            elif count_bound and all(isinstance(x,exp.Column) for x in outputs):
                needle=re.search(r'\b(?:than|least|most|exactly|over|under)\s+(?:\d+|one|two|three|four|five)\s+(?:of\s+)?([a-z_]+)',other)
                if not needle:continue
                children=[t['name'] for t in req.schema if set(words(t['name']))==set(words(needle[1]))]
                if len(children)!=1:continue
                child=children[0]
                edges=[e for e in req.graph[owner] if e.child==child and e.parent==owner and e not in req.inferred]
                if len(edges)!=1:continue
                key=primary(req.tables[owner.lower()])
                if not key:continue
                m=re.search(r'\b(?:maximum|highest|largest|greatest|minimum|lowest|smallest)\s+(?:the )?(.+)',high)
                lex=terms(m[1]) if m else set()
                numeric=[c['name'] for c in req.tables[owner.lower()]['columns'] if not c['pk'] and re.search(r'INT|NUM|REAL|DEC|FLOA|DOUB',c['type'],re.I) and not re.search(r'(?:^|_)id$',c['name'],re.I)]
                def measure_words(s):
                    return {'amount' if w in ('value','amount','price','cost') else re.sub(r'ed$','',w) for w in s}
                scores=sorted(((len(measure_words(words(c)) & measure_words(lex)),c) for c in numeric),reverse=True)
                if not scores or not scores[0][0] or (len(scores)>1 and scores[0][0]==scores[1][0]):continue
                measure=column(owner,scores[0][1])
                threshold,n=count_bound;idcol=column(owner,key['name'])
                e=edges[0]
                group=exp.select(idcol.copy()).from_(table(owner)).join(table(child),on=e.predicate()).group_by(idcol.copy()).having(
                    threshold(this=exp.Count(this=exp.Star()),expression=exp.Literal.number(n)))
                top=exp.select(extremum(this=measure.copy())).from_(table(owner))
                cond=exp.or_(idcol.isin(query=group),exp.EQ(this=measure,expression=top.subquery()))
                out=exp.select(*[f.copy() for f in outputs]).from_(table(owner)).where(cond)
                yield 15,rendered(out),'qualify each entity by a related count or its own extreme value'


def comparison_class(req, sql):
    probe=comparison_probe(req,sql)
    if not probe:return
    tree,sub,source,fields,_=probe
    # An unqualified role noun can bind to a unique categorical field. Names,
    # addresses, identifiers and numeric attributes do not identify the role.
    domains={'job','profession','occupation','role','category','type','kind','class','species'}
    typed=[field for field in fields if set(words(field)) & domains]
    noun=re.search(r'\bthan (?:all|every|any) (?:the )?([a-z]+)\s*[?.!]?$',req.text)
    if len(typed)!=1 or not noun or terms(noun[1]) <= terms(source.name):return
    sub.where(exp.EQ(this=exp.Lower(this=exp.Trim(this=column(source.alias_or_name,typed[0]))),expression=exp.Literal.string(noun[1])),copy=False)
    yield 15,rendered(tree),'restrict an unqualified comparator to the named class'


def plans_for(req,sqls,mode):
    comparative=bool(re.search(r'\bthan (?:all|every|any)\b',req.text))
    if not re.search(r'\b(both|either|or|but not)\b',req.text) and not comparative:return []
    trees=[]
    for s in dict.fromkeys(sqls):
        try:trees.append(validate_sql(s))
        except (ValueError,SqlglotError,RecursionError):continue
    if not trees:return []
    by_key={}
    if comparative and mode in ('typed','grounded') and (mode!='grounded' or not re.search(r'\bthan any\b',req.text)):
        for score,new,why in comparison_class(req,sqls[0]):
            by_key[sql_key(new)]=(score,new,why)
    sources=[alternatives(req,trees,mode=='grounded')]
    if mode!='cohorts':sources.insert(0,ranked_union(req,trees))
    for candidates in sources:
        for score,new,why in candidates:
            if len(new.encode())<=16000:
                by_key.setdefault(sql_key(new),(score,new,why))
    return sorted(by_key.values(),key=lambda x:(-x[0],len(x[1]),x[1]))
