"""Test whether all requested columns, conditions and row identity live on one table."""
import re
from sqlglot import exp
from sqlglot.errors import SqlglotError
from mp3_sql.sqlite_tool import validate_sql
from harness_lab.grain_repair.scoped import candidates
from harness_lab.intent_repair.semantics import simple,prepare,rendered,table,split_and
from harness_lab.intent_repair.roles import stems
from harness_lab.intent_repair.pool import sql_key

FUNCTION=stems('show list find return display give tell get select provide me what which how who whose their all every each as well do we have is are was were has had does number many much count names types different distinct unique ordered alphabetically alphabetical order ascending descending sort by from of to for any a the an and or in with at on of entries records details information corresponding include including respectively where be there having maximum minimum highest lowest greatest least top highest largest smallest amount total average first last most greater less than above below between per contain contains equal equals any also out both not function please ids')
# These words change population even when they do not resemble a schema identifier.
RELATIVE=re.compile(r"\b(who|whose|which have|which has|which are|that have|that has|even if|without|never|associated|related|used by|correspond to|belong)\b")


def one_table(sql,req):
    tree,scope=simple(sql,req)
    if tree is None or not tree.args.get('joins') or tree.find(exp.Window):
        return
    frame=prepare(tree,scope,req)
    if frame is None:
        return
    fields=list(frame.find_all(exp.Column))
    owners={c.table for c in fields}
    if len(owners)!=1:
        return
    owner=next(iter(owners))
    schema=req.tables[owner.casefold()]
    name_tokens=stems(owner)
    qterms=stems(req.question)
    if not name_tokens&qterms:
        return
    if frame.find(exp.AggFunc) and frame.args.get('group'):
        return
    if (frame.args.get('group') or frame.args.get('having') or
        any(isinstance(p,exp.Count) for p in frame.expressions) and re.search(r'\b(per|each|who|whose)\b',req.text)):
        return
    if RELATIVE.search(req.text):
        return
    available=name_tokens|set().union(*(stems(c['name']) for c in schema['columns']))
    grounded=stems(' '.join(s.name for s in frame.find_all(exp.Literal)))
    unknown=qterms-(available|grounded|FUNCTION)
    if unknown:
        return
    actual_names=set(scope.values())-{owner}
    for n in actual_names:
        extra=(stems(n)-name_tokens)&qterms
        if extra-(grounded|FUNCTION):
            return
    if req.negation and not frame.args.get('where'):
        return
    frame.set('from',exp.From(this=table(owner)))
    yield 8.8,rendered(frame),'all requirements bound on one table'


def connective(sql,req):
    tree=validate_sql(sql)
    if not isinstance(tree,exp.Select) or len(list(tree.find_all(exp.Select)))!=1:
        return
    w=tree.args.get('where')
    if not w or not isinstance(w.this,(exp.And,exp.Or)):
        return
    q=re.sub(r"""'[^']*'|"[^"]*" """.strip(),'',req.text)
    if not re.search(r'\bor\b',q) or not isinstance(w.this,exp.And) or re.search(r'\bboth|between\b',q):
        return
    a,b=w.this.this,w.this.expression
    types=(exp.EQ,exp.LT,exp.LTE,exp.GT,exp.GTE,exp.Like)
    if not all(isinstance(e,types) and isinstance(e.this,exp.Column) and isinstance(e.expression,exp.Literal) and req.support(e.expression) for e in (a,b)):
        return
    literal1=req.text.find(a.expression.name.lower())
    literal2=req.text.find(b.expression.name.lower())
    if literal1<0 or literal2<0 or not re.search(r'\bor\b',req.text[min(literal1,literal2):max(literal1,literal2)]):
        return
    w.set('this',exp.or_(a.copy(),b.copy()))
    yield 10,rendered(tree),'explicit disjunction'


def minimal_candidates(req,sql):
    out=candidates(req,sql)
    for f in (one_table,connective):
        try:
            for score,s,reason in f(sql,req):
                if len(s.encode())<=16000 and sql_key(s)!=sql_key(sql):
                    out.append((score,s,reason))
        except (ValueError,SqlglotError,RecursionError):
            continue
    return out
