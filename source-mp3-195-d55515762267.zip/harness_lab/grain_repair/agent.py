"""Use the counting subject to resolve an outstanding discrepancy, then check the repair."""
from harness_lab.intent_repair.semantics import Requirement
from harness_lab.intent_repair.pool import sql_key
from harness_lab.grain_repair.compiler import public_candidates


class GrainAgent:
    generate=staticmethod(public_candidates)

    def __init__(self,old,early=False):
        self.old=old
        self.early=early
        self.incumbent=None
        self.candidates=[]
        self.decision={}
        self.preempted=False

    def begin(self,obs,sql):
        self.incumbent=sql
        schema=next((h['observation'] for h in obs['history'] if h['tool']=='schema'),None)
        if schema:
            req=Requirement(obs['task']['question'],obs['example']['columns'],schema)
            self.candidates=sorted(self.generate(req,sql),key=lambda c:(-c[0],c[1]))

    def act(self,obs):
        history=obs['history']
        if self.incumbent is None:
            act=self.old.act(obs)
            if act['tool']=='submit':
                self.begin(obs,act['sql'])
            elif self.early and self.old.incumbent is not None and act['tool']=='check' and obs['remaining']==1 and not any(h['tool']=='check' and h['observation']['matches_example'] for h in history):
                self.begin(obs,act['sql'])
                if not self.candidates:
                    self.incumbent=None
                    return act
                self.preempted=True
            else:
                return act
        known={sql_key(h['sql']):h for h in history if h['tool']=='check'}
        match=known.get(sql_key(self.incumbent),{}).get('observation',{}).get('matches_example',False)
        for score,sql,why in self.candidates[:2]:
            if match and score<7.5:
                continue
            key=sql_key(sql)
            if key in known:
                if known[key]['observation']['matches_example']:
                    self.decision={'action':why,'score':score,'early':self.preempted}
                    return dict(tool='submit',sql=known[key]['sql'])
            elif obs['remaining']:
                return dict(tool='check',sql=sql)
        return dict(tool='submit',sql=self.incumbent)
