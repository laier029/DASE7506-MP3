"""Compile the existing row population, a qualified group, or a scalar comparison separately."""
import re
from sqlglot import exp
from sqlglot.errors import SqlglotError
from harness_lab.grain_repair.cardinality import CardinalityAgent
from harness_lab.grain_repair.compiler import count_focus, named_measure
from harness_lab.intent_repair.pool import sql_key
from harness_lab.intent_repair.reconstruct import projected, sources, group_bound
from harness_lab.intent_repair.roles import stems
from harness_lab.intent_repair.semantics import Requirement, column, table, rendered, words
from mp3_sql.sqlite_tool import validate_sql


def output_on(tree, req):
    for row in projected(req, tree, sources(tree, req)):
        if row and all(isinstance(c, exp.Column) for c in row) and len({c.table for c in row}) == 1:
            yield row[0].table, row


def extrema(tree, req):
    match = re.search(r'\b(highest|lowest|largest|smallest|maximum|minimum|greatest|least)\b\s+(?:value of (?:the )?)?([a-z_][a-z _]+)', req.text)
    if not match or req.negation or req.qnums or req.order or re.search(r'\b(?:who|where|whose|with a|than|either|or|before|after|between|among|per|for each|group)\b', req.text):
        return
    following = words(re.split(r'[?.!,]|\b(?:of|across|in|among|was|were|for|from|that)\b',match[2])[0])
    for owner, fields in output_on(tree, req):
        schema=req.tables[owner.casefold()]
        measure=[c for c in schema['columns'] if tuple(words(c['name'])) == following and not c['pk']]
        if len(measure)!=1 or len(req.mentioned - {owner}) or not req.mentioned:
            continue
        key=column(owner,measure[0]['name'])
        direction=match[1] in ('highest','largest','maximum','greatest')
        current=sources(tree,req)
        explicit=[lit for lit in tree.find_all(exp.Literal) if req.support(lit)]
        if explicit:
            continue
        unusual=any(n!=owner for n in current.values()) or not (tree.find(exp.Max,exp.Min) or (tree.args.get('limit') and tree.args.get('order')))
        if not unusual:
            continue
        result=exp.select(*fields).from_(table(owner))
        result=result.order_by(exp.Ordered(this=key,desc=direction,nulls_first=not direction)).limit(1)
        yield 12,rendered(result),'rank the requested entity by its own measure'


def common_count(tree, req):
    focus=count_focus(req)
    if not focus or req.qnums or req.negation or re.search(r'\b(who|with|having|during|that (?:are|have)|whose|by|before|after)\b',req.text):
        return
    named=named_measure(req,focus[1],sources(tree,req).values())
    if not named:
        return
    asc=focus[0] in ('least','fewest','smallest','lowest','minimum')
    for owner,fields in output_on(tree,req):
        if named!=owner or set(req.mentioned)-{owner}:
            continue
        if tree.args.get('group') and tree.args.get('order') and tree.args['order'].find(exp.Count) and tree.args.get('limit') and not tree.args.get('having'):
            continue
        hint=bool(re.search(r'\b(number|count|frequency|common|often)\b',req.text))
        if not hint:
            continue
        query=exp.select(*fields).from_(table(owner)).group_by(*[c.copy() for c in fields])
        query=query.order_by(exp.Ordered(this=exp.Count(this=exp.Star()),desc=not asc,nulls_first=asc)).limit(1)
        yield 12,rendered(query),'count rows for each displayed group'


def qualifying_members(tree, req):
    if not group_bound(req.text) or not re.search(r'\ball (?:of )?(?:those|their|these|the)\b',req.text):
        return
    clause=re.search(r'\b(?:for each|for every|each|every) ([\w]+)\b',req.text)
    if not clause or req.negation:
        return
    for owner, fields in output_on(tree, req):
        if not stems(owner) <= stems(req.question):
            continue
        cols=[c for c in req.tables[owner.casefold()]['columns'] if words(c['name']) == words(clause[1])]
        if len(cols)!=1 or any(c.name==cols[0]['name'] for c in fields):
            continue
        key=column(owner,cols[0]['name'])
        op,n=group_bound(req.text)
        sub=exp.select(key.copy()).from_(table(owner)).group_by(key.copy()).having(op(this=exp.Count(this=exp.Star()),expression=exp.Literal.number(n)))
        query=exp.select(*fields).from_(table(owner)).where(key.copy().isin(query=sub))
        if any(req.support(lit) and lit.name!=str(n) for lit in tree.find_all(exp.Literal)):
            continue
        yield 13,rendered(query),'return every member of the qualifying groups'


def options(req, sql):
    try:
        tree=validate_sql(sql)
        if not isinstance(tree,exp.Select):
            return []
        result=[]
        for f in (extrema,common_count,qualifying_members):
            for score,new,why in f(tree,req):
                if sql_key(new)!=sql_key(sql) and len(new.encode())<=16000:
                    result.append((score,new,why))
        return sorted(result,key=lambda x:(-x[0],x[1]))
    except (ValueError,SqlglotError,RecursionError):
        return []


def comparison_probe(req, sql):
    hit=re.search(r'\bthan (?:all|every|any) (?:the )?([a-z]+)\s*[?.!]?$',req.text)
    if not hit or hit[1] in ('other','one','person','people','row','record') or any(w in req.text for w in ('either',' both ')):
        return
    root=validate_sql(sql)
    candidates=[]
    for comp in root.find_all(exp.GT,exp.LT,exp.GTE,exp.LTE):
        if not isinstance(comp.this,exp.Column) or not isinstance(comp.expression,exp.Subquery):
            continue
        sub=comp.expression.this
        if not isinstance(sub,exp.Select) or sub.args.get('where') or sub.args.get('joins') or sub.args.get('limit') or not sub.args.get('from'):
            continue
        source=sub.args['from'].this
        if not isinstance(source,exp.Table) or source.name.casefold() not in req.tables:
            continue
        if len(sub.expressions)!=1 or not isinstance(sub.expressions[0].unalias(),(exp.Max,exp.Min)):
            continue
        cols=[c['name'] for c in req.tables[source.name.casefold()]['columns'] if re.search(r'CHAR|CLOB|TEXT|STRING|ENUM',c['type'],re.I)]
        if not 1<=len(cols)<=12:
            continue
        needle=exp.Literal.string(hit[1])
        selects=[]
        for c in cols:
            val=column(source.name,c)
            matched=exp.EQ(this=exp.Lower(this=exp.Trim(this=val.copy())),expression=needle.copy())
            selects.append(exp.Min(this=exp.Case().when(matched,val.copy())))
        probe=rendered(exp.select(*selects).from_(table(source.name)))
        candidates.append((root,sub,source,cols,probe))
    return candidates[0] if len(candidates)==1 else None


class ScopeAgent:
    def __init__(self, old, variant):
        self.old=CardinalityAgent(old,'justified')
        self.variant=variant
        self.sql=None
        self.req=None
        self.candidates=[]
        self.decision={}
        self.probe=None

    def act(self,obs):
        history=obs['history']
        if self.sql is None:
            a=self.old.act(obs)
            if a['tool']!='submit' and not (self.variant!='scope' and a['tool']=='check' and obs['remaining']==1 and self.old.old.incumbent is not None):
                return a
            schema=next((h['observation'] for h in history if h['tool']=='schema'),None)
            if not schema:
                return a
            self.req=Requirement(obs['task']['question'],obs['example']['columns'],schema)
            self.candidates=options(self.req,a['sql'])
            if a['tool']!='submit' and not self.candidates:
                return a
            self.sql=a['sql']
            if self.variant=='scope_probe' and obs['remaining']>=2:
                try:
                    self.probe=comparison_probe(self.req,self.sql)
                except (ValueError,SqlglotError,RecursionError):
                    self.probe=None
        if self.probe:
            tree,sub,source,cols,query=self.probe
            result=next((h['observation'] for h in history if h['tool']=='execute' and h['sql']==query),None)
            if result is None and obs['remaining']>=2:
                return dict(tool='execute',sql=query)
            if result and result['ok'] and len(result['rows'])==1:
                hit=[(c,v) for c,v in zip(cols,result['rows'][0]) if v is not None]
                if len(hit)==1:
                    field,value=hit[0]
                    sub.where(exp.EQ(this=column(source.alias_or_name,field),expression=exp.Literal.string(value)),copy=False)
                    self.candidates.insert(0,(15,rendered(tree),'restrict the population used for comparison'))
            self.probe=None
        checks={sql_key(h['sql']):h for h in history if h['tool']=='check'}
        for score,candidate,reason in self.candidates[:2]:
            h=checks.get(sql_key(candidate))
            if h and h['observation']['matches_example']:
                self.decision=dict(action=reason,score=score)
                return dict(tool='submit',sql=h['sql'])
            if not h and obs['remaining']:
                return dict(tool='check',sql=candidate)
        self.decision=self.old.decision
        return dict(tool='submit',sql=self.sql)
