"""Check the type of the ranked measurement before replacing it with a count."""
from sqlglot import exp
from sqlglot.errors import SqlglotError
from harness_lab.grain_repair.compiler import RANK,NUMERIC
from harness_lab.grain_repair.minimal import minimal_candidates
from harness_lab.intent_repair.roles import stems
from harness_lab.intent_repair.reconstruct import sources
from mp3_sql.sqlite_tool import validate_sql


def explicit_quantity(root,req):
    hit=RANK.search(req.text)
    if not hit:
        return False
    phrase=stems(req.text[hit.end():].split('?')[0].split('.')[0])
    scope=sources(root,req)
    order=root.args.get('order')
    measured=list(order.find_all(exp.Column)) if order else []
    for extent in root.find_all(exp.Min,exp.Max):
        measured.extend(extent.find_all(exp.Column))
    for c in measured:
        ref=req.required(c,scope)
        if not ref:
            continue
        name=stems(ref[1])
        field=next((f for f in req.tables[ref[0].lower()]['columns'] if f['name']==ref[1]),None)
        if name and name<=phrase and field and NUMERIC.search(field['type']) and not field['pk']:
            return True
    return False


def typed_candidates(req,sql):
    raw=minimal_candidates(req,sql)
    if not any(reason=='count related rows' for _,_,reason in raw):
        return raw
    try:
        tree=validate_sql(sql)
        order=tree.args.get('order')
        correct_count_order=bool(order and order.find(exp.Count) and tree.args.get('limit') and tree.args.get('group'))
        scope=set(sources(tree,req).values())
        out=[]
        for row in raw:
            score,alt,reason=row
            if reason=='count related rows':
                if explicit_quantity(tree,req):
                    continue
                proposed=set(sources(validate_sql(alt),req).values())
                if correct_count_order and len(scope)==1 and not proposed.issubset(scope):
                    continue
            out.append(row)
        return out
    except (SqlglotError,ValueError,RecursionError):
        return []
