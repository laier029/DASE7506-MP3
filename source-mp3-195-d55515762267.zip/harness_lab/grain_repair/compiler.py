"""Compile a question's counting unit and scoped qualifiers with declared schema paths."""
import re
from sqlglot import exp
from sqlglot.errors import SqlglotError
from harness_lab.intent_repair.reconstruct import projected, sources, conditions, limit_value, group_bound
from harness_lab.intent_repair.roles import plans, stems
from harness_lab.intent_repair.semantics import column, table, rendered, words
from harness_lab.intent_repair.staged import public_match
from harness_lab.intent_repair.iterative import alternative_sets
from harness_lab.intent_repair.pool import sql_key
from mp3_sql.sqlite_tool import validate_sql

RANK=re.compile(r'\b(most|fewest|least|greatest|largest|smallest|highest|lowest|maximum|minimum)\b')
SKIP=set('the different distinct various different kinds kind types type quantity number total count of times its their have does do we there are is a an in many how which that who has had'.split())
META={'ref','reference','lookup','catalog','category','code','type','list','definition','master'}
NUMERIC=re.compile(r'INT|NUM|DEC|REAL|DOUB|FLOAT',re.I)


def dedup(seq):
    return list(dict.fromkeys(seq))


def count_focus(req):
    hit=RANK.search(req.text)
    if not hit or re.match(r'\s+(?:recent|expensive|valuable|old|young|late|early)\b',req.text[hit.end():]):
        return None
    if req.negation or group_bound(req.text):
        return None
    right=re.split(r'[?.!,;]|\b(?:for each|also|among|whose|that|which|where|from the)\b',req.text[hit.end():],maxsplit=1)[0]
    seq=[w for w in words(right) if w not in SKIP][:5]
    return hit[1],seq,right


def grouping_columns(req,root,fields,entity):
    if entity:
        keys=sorted((c['pk'],c['name']) for c in req.tables[root.lower()]['columns'] if c['pk'])
        if keys:
            return [column(root,c) for _,c in keys]
    return [e.copy() for e in fields]


def named_measure(req,focus,sources_used):
    options=[]
    for t in req.schema:
        name=t['name']
        ws=stems(name)
        if not ws or not ws.issubset(set(focus)):
            continue
        hit=sum(3/(1+focus.index(w)) for w in ws)
        options.append((hit+.1*(name in sources_used),name))
    options.sort(reverse=True)
    if len(options)>1 and options[0][0]==options[1][0]:
        return None
    return options[0][1] if options else None


def catalog_count(root,req):
    m=re.fullmatch(r'\s*(?:how many|(?:what is |find |show )?(?:the )?(?:total )?number of|count (?:the )?(?:number of )?)([a-z -]{2,60}?)(?:\s+(?:are there|do we have|are available|in (?:the )?database))?[?.! ]*',req.text)
    if not m or re.search(r'\b(who|with|each|of the|for|have a|that|whose|associated|used|using)\b',m[1]):
        return
    if not len(req.targets)==1 or not isinstance(req.targets[0],exp.Count) or not isinstance(req.targets[0].this,exp.Star):
        return
    units=set(words(m[1]))-SKIP
    if not units:
        return
    type_requested=bool(set(words(m[1])) & {'type','kind','category'})
    matches=[]
    for t in req.schema:
        ws=set(words(t['name']))
        contents=ws-META
        if contents!=units and ws!=units:
            continue
        if type_requested and not ws&META:
            continue
        matches.append(t['name'])
    if len(matches)==1:
        t=matches[0]
        if len(list(root.find_all(exp.Select)))==1 and (root.args.get('joins') or root.find(exp.Distinct)
                or not any(s.name.casefold()==t.casefold() for s in root.find_all(exp.Table))):
            yield 8.0,rendered(exp.select(exp.Count(this=exp.Star())).from_(table(t))),'catalogue population'


def ranked(tree,req,focus):
    direction,units,raw=focus
    scope=sources(tree,req)
    filters=conditions(tree,req)
    if req.qnums or re.search(r'["\']',req.text):
        if not filters:
            return
    tally=named_measure(req,units,scope.values())
    current_order=tree.args.get('order')
    count_cue=re.search(r'\b(number|count|times|common|frequent|frequency)\b',req.text)
    if not tally and not count_cue:
        return
    asc=direction in {'fewest','least','smallest','lowest','minimum'}
    for fields in projected(req,tree,scope):
        display=[c for c in fields if isinstance(c,exp.Column)]
        if not display or any(not isinstance(c,(exp.Count,exp.Column)) for c in fields):
            continue
        owners=dedup(c.table for c in display)
        if len(owners)!=1:
            continue
        subject=owners[0]
        if not tally:
            # An unnamed measure needs one unambiguous fact table linked to the grouping entity.
            names=dedup(scope.values())
            child=[t for t in names if t!=subject and any(e.parent==subject and e.child==t for e in req.graph[subject])]
            if len(child)!=1:
                continue
            measure_table=child[0]
        else:
            measure_table=tally
        filter_tables=dedup(c.table for p in filters for c in p.find_all(exp.Column))
        need=dedup([*filter_tables,measure_table])
        path=plans(req,subject,need)
        if path is None:
            continue
        # A bridge already records the counted relationship; an unfiltered dimension lookup
        # is unnecessary when only the link rows, not a dimension attribute, are measured.
        if len(path)>=2 and path[-1][1]==measure_table and path[-1][0].parent==measure_table and measure_table not in filter_tables:
            path=path[:-1]
        groups=grouping_columns(req,subject,display,entity=subject!=measure_table)
        measure=exp.Count(this=exp.Star())
        label='count related rows'
        if subject==measure_table:
            numeric=[c for c in req.tables[subject.lower()]['columns'] if NUMERIC.search(c['type']) and not c['pk']
                     and set(words(c['name']))==set(words(measure_table))]
            if len(numeric)==1 and not count_cue and any(set(words(c.name)) & {'year','month','date','day','period','region'} for c in display):
                measure=exp.Sum(this=column(subject,numeric[0]['name']))
                label='sum stored quantities'
        frame=exp.select(*[c.copy() if isinstance(c,exp.Column) else exp.Count(this=exp.Star()) for c in fields]).from_(table(subject))
        for edge,dest in path:
            frame=frame.join(table(dest),on=edge.predicate())
        if filters:
            frame=frame.where(*[p.copy() for p in filters])
        proposed=frame.group_by(*groups).order_by(exp.Ordered(this=measure,desc=not asc,nulls_first=asc)).limit(limit_value(req.text))
        active=set(scope.values())
        needed={subject}|{dest for _,dest in path}
        overcount=any(any(e.child==n and e.parent in needed for e in req.graph.get(n,())) for n in active-needed)
        wrong_order=not current_order or (not current_order.find(exp.Count,exp.Sum) and
            not any(x.alias and x.alias.casefold() in {c.name.casefold() for c in current_order.find_all(exp.Column)} and x.find(exp.Count,exp.Sum) for x in tree.expressions))
        has_limit=bool(tree.args.get('limit'))
        wrong_unit=tally and measure_table not in active
        bad_group=not tree.args.get('group') or tree.args.get('having') and not group_bound(req.text)
        score=4.0+bool(tally)+bool(count_cue)+2*bool(overcount)+2*bool(wrong_order or not has_limit)+bool(wrong_unit or bad_group)
        if label=='sum stored quantities':
            score+=2
        if overcount or wrong_order or not has_limit or bad_group or wrong_unit or label=='sum stored quantities':
            yield score,rendered(proposed),label


def set_repairs(root,req):
    """Split mutually exclusive tests when the question asks for two populations."""
    if 'both' not in req.words or not isinstance(root,exp.Select):
        return
    if not root.args.get('where') or any(root.args.get(k) for k in ('order','limit','group','having')):
        return
    f=root.args['where'].this
    if not isinstance(f,(exp.And,exp.Or)):
        return
    lo,hi=f.this,f.expression
    if not all(isinstance(c,(exp.GT,exp.GTE,exp.LT,exp.LTE,exp.EQ)) and isinstance(c.this,exp.Column)
               and isinstance(c.expression,exp.Literal) and req.support(c.expression) for c in (lo,hi)):
        return
    if lo.this!=hi.this:
        return
    if type(lo)==type(hi)==exp.EQ and lo.expression==hi.expression:
        return
    if isinstance(lo,(exp.GT,exp.GTE)) and isinstance(hi,(exp.LT,exp.LTE)):
        try:
            if float(lo.expression.name)<float(hi.expression.name):
                return
        except ValueError:
            return
    elif type(lo)!=type(hi) or type(lo)!=exp.EQ:
        return
    lhs=root.copy();rhs=root.copy()
    lhs.set('where',exp.Where(this=lo.copy()));rhs.set('where',exp.Where(this=hi.copy()))
    yield 9,rendered(exp.Intersect(this=lhs,expression=rhs,distinct=True)),'both qualifying populations'


def public_candidates(req,sql):
    try:
        root=validate_sql(sql)
        if not isinstance(root,exp.Select):
            return []
        results=list(catalog_count(root,req))+list(set_repairs(root,req))
        focus=count_focus(req)
        if focus:
            results+=list(ranked(root,req,focus))
        if re.search(r'\b(all|every)\b',req.text):
            for label,s in alternative_sets(sql,req):
                if label=='compare_set':
                    results.append((8.5,s,'universal comparison'))
        return [c for c in results if len(c[1].encode())<=16000 and sql_key(sql)!=sql_key(c[1])]
    except (ValueError,SqlglotError,RecursionError):
        return []
