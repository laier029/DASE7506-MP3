"""Ground numeric bounds in a stored measure, or preserve every qualifying subject row."""
import re
from sqlglot import exp
from sqlglot.errors import SqlglotError
from harness_lab.grain_repair.compiler import NUMERIC
from harness_lab.grain_repair.typed import typed_candidates
from harness_lab.intent_repair.reconstruct import conditions,group_bound,projected,sources
from harness_lab.intent_repair.semantics import column,table,rendered,words
from harness_lab.intent_repair.roles import plans,stems
from harness_lab.intent_repair.pool import sql_key
from mp3_sql.sqlite_tool import validate_sql

COUNT_NAMES={'number','num','quantity','total','count','qty'}


def measure_bound(tree,req):
    bound=group_bound(req.text)
    if not bound or req.negation or RANK_CONFLICT.search(req.text):
        return
    hit=re.search(r'\b(?:at least|at most|more than|greater than|fewer than|less than|over|exactly)\s+(?:\d+|one|two|three|four|five|ten)\s+([a-z][a-z_]+(?:\s+[a-z]+){0,2})',req.text)
    if not hit:
        return
    noun=words(hit[1])
    if not noun:
        return
    matches=[]
    for t in req.schema:
        for c in t['columns']:
            names=set(words(c['name']))-{'of','the'}
            role=names-COUNT_NAMES
            if c['pk'] or not NUMERIC.search(c['type']) or not names & COUNT_NAMES:
                continue
            if role and role<=set(noun) and noun[0] in role:
                matches.append((t['name'],c['name']))
    if len(matches)!=1:
        return
    owner,measure=matches[0]
    if not stems(owner)&stems(req.question):
        return
    op,n=bound
    filters=conditions(tree,req)
    filters=[p for p in filters if not any(l.name==str(n) for l in p.find_all(exp.Literal))]
    scope=sources(tree,req)
    for items in projected(req,tree,scope):
        if any(not isinstance(x,exp.Column) for x in items):
            continue
        root=items[0].table
        needed=list(dict.fromkeys([c.table for c in items]+[owner]+[c.table for p in filters for c in p.find_all(exp.Column)]))
        path=plans(req,root,needed)
        if path is None:
            continue
        frame=exp.select(*[e.copy() for e in items]).from_(table(root))
        for edge,dest in path:
            frame=frame.join(table(dest),on=edge.predicate())
        frame=frame.where(op(this=column(owner,measure),expression=exp.Literal.number(n)),*(p.copy() for p in filters))
        if req.distinct:
            frame=frame.distinct()
        yield 8.6,rendered(frame),'threshold on a stored count'


RANK_CONFLICT=re.compile(r'\b(most|fewest|top|largest|highest|lowest|greatest|maximum|minimum|either| or )\b')


def subject_measure(tree,req):
    """When a single entity owns the measure, a child tests membership, not weight."""
    if not re.search(r'\b(who|which|that)\s+(?:have|has|had|took|take|use|used|made|own|participat\w*)\b',req.text):
        return
    if req.negation or req.order or req.ranking or len(list(tree.find_all(exp.Select)))!=1 or len(tree.expressions)!=1:
        return
    v=tree.expressions[0].unalias()
    if not isinstance(v,(exp.Avg,exp.Sum)) or not isinstance(v.this,exp.Column):
        return
    if any(tree.args.get(k) for k in ('group','having','order','limit','distinct')):
        return
    scope=sources(tree,req);ref=req.required(v.this,scope)
    if ref is None or not stems(ref[0]) & stems(req.question):
        return
    nodes=list(tree.find_all(exp.Table))
    if len(nodes)!=2 or len(scope)!=2 or len(tree.args.get('joins',[]))!=1:
        return
    parent=next((t for t in nodes if t.name.casefold()==ref[0].casefold()),None)
    child=next((t for t in nodes if t is not parent),None)
    if not parent or not child:
        return
    join=tree.args['joins'][0];eq=join.args.get('on')
    if join.side or not isinstance(eq,exp.EQ) or not all(isinstance(c,exp.Column) for c in (eq.this,eq.expression)):
        return
    refs={req.required(c,scope) for c in (eq.this,eq.expression)}
    if not any({(child.name.casefold(),fk['from'].casefold()),(fk['table'].casefold(),fk['to'].casefold())}==
               {(t.casefold(),c.casefold()) for pair in refs if pair for t,c in [pair]} for fk in req.tables[child.name.casefold()]['foreign_keys']):
        return
    qualified=eq.copy()
    for c in qualified.find_all(exp.Column):
        who=req.required(c,scope)
        if not who:
            return
        c.set('table',exp.to_identifier(parent.alias_or_name if who[0].casefold()==parent.name.casefold() else child.alias_or_name))
    sub=exp.select(exp.Literal.number(1)).from_(child.copy()).where(qualified)
    if tree.args.get('where'):
        flt=tree.args['where'].this.copy()
        for c in flt.find_all(exp.Column):
            who=req.required(c,scope)
            if not who:
                return
            c.set('table',exp.to_identifier(parent.alias_or_name if who[0].casefold()==parent.name.casefold() else child.alias_or_name))
        sub=sub.where(flt)
    answer=exp.select(tree.expressions[0].copy()).from_(parent.copy()).where(exp.Exists(this=sub))
    yield 9,rendered(answer),'aggregate each qualifying subject once'


def measure_candidates(req,sql):
    out=typed_candidates(req,sql)
    try:
        tree=validate_sql(sql)
        if isinstance(tree,exp.Select):
            for f in (measure_bound,subject_measure):
                out.extend((score,s,why) for score,s,why in f(tree,req) if sql_key(s)!=sql_key(sql) and len(s.encode())<=16000)
    except (ValueError,SqlglotError,RecursionError):
        pass
    return out
