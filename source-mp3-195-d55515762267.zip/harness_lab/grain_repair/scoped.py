"""Preserve output ownership and distinguish a qualifying group from a displayed row."""
import re
from sqlglot import exp
from sqlglot.errors import SqlglotError
from harness_lab.intent_repair.roles import stems
from harness_lab.intent_repair.semantics import column, rendered, words, split_and
from harness_lab.intent_repair.reconstruct import sources, group_bound
from harness_lab.intent_repair.iterative import alternative_sets
from harness_lab.grain_repair.compiler import public_candidates, count_focus
from mp3_sql.sqlite_tool import validate_sql


def target_support(before,after,req):
    old=sources(before,req); new=sources(after,req)
    agree=changed=0
    head=re.split(r'\b(who|which (?=have|has|is|was|are|were)|whose|that|with|for each|having|included|incurred|most|fewest|greatest|least|largest|highest|lowest|smallest)\b',req.text,maxsplit=1)[0]
    head_words=stems(head)
    for a,b in zip(before.expressions,after.expressions):
        a=a.unalias();b=b.unalias()
        if not isinstance(a,exp.Column) or not isinstance(b,exp.Column) or a.name.casefold()!=b.name.casefold():
            continue
        left=req.required(a,old);right=req.required(b,new)
        if not left or not right:
            continue
        if left==right:
            agree+=1
        elif a.table:
            changed+=1
        if stems(right[0]) and stems(right[0])<=head_words:
            agree+=1
    return min(2.5,.9*agree)-3*changed


def local_comparison(sql,req):
    if not re.search(r'\b(all|every|any)\b',req.text):
        return
    for label,s in alternative_sets(sql,req):
        if label!='compare_set':
            continue
        root=validate_sql(s)
        for sub in root.find_all(exp.Subquery):
            inner=sub.this
            if not isinstance(inner,exp.Select) or not inner.args.get('where'):
                continue
            src=inner.args.get('from')
            if not src or not isinstance(src.this,exp.Table) or inner.args.get('joins'):
                continue
            parent=sub.find_ancestor(exp.Select)
            local=src.this
            if not parent or not parent.args.get('from') or not isinstance(parent.args['from'].this,exp.Table):
                continue
            outer=parent.args['from'].this
            if (outer.name.casefold()!=local.name.casefold() or
                outer.alias_or_name.casefold()==local.alias_or_name.casefold()):
                continue
            changed=False
            for atom in split_and(inner.args['where'].this):
                if not isinstance(atom,exp.EQ) or not isinstance(atom.this,exp.Column) or not isinstance(atom.expression,exp.Literal):
                    continue
                if atom.this.table.casefold()!=outer.alias_or_name.casefold() or not req.support(atom.expression):
                    continue
                atom.this.set('table',exp.to_identifier(local.alias_or_name))
                changed=True
            if changed:
                yield 11,rendered(root),'bind comparison subset locally'


def display_members(tree,req):
    """Move a group-size qualification into a subquery, keeping one row per requested member."""
    if not group_bound(req.text) or not re.search(r'\b(all (?:those |these |the )?|for each|every|list all)\b',req.text):
        return
    if not tree.args.get('group') or not tree.args.get('having') or not tree.args.get('from') or tree.args.get('limit'):
        return
    if len(list(tree.find_all(exp.Select)))!=1 or not tree.args['having'].find(exp.Count):
        return
    groups=tree.args['group'].expressions
    if len(groups)!=1 or not isinstance(groups[0],exp.Column) or any(e.find(exp.AggFunc) for e in tree.expressions):
        return
    if all(isinstance(e.unalias(),exp.Column) and e.unalias().name.lower()==groups[0].name.lower() for e in tree.expressions):
        return
    key=groups[0]
    if not stems(key.name) & stems(req.question):
        return
    sub=tree.copy()
    sub.set('expressions',[key.copy()])
    sub.set('order',None)
    ans=tree.copy()
    ans.set('group',None);ans.set('having',None)
    ans=ans.where(key.copy().isin(query=sub))
    yield 9.5,rendered(ans),'display every qualifying group member'


def empty_relation(tree,req):
    if not req.negation or not re.search(r"\b(any|never|without|no)\b",req.text):
        return
    for pred in tree.find_all(exp.In):
        if not isinstance(pred.parent,exp.Not):
            continue
        sub=pred.args.get('query')
        if not isinstance(sub,exp.Subquery) or not isinstance(sub.this,exp.Select):
            continue
        inner=sub.this;w=inner.args.get('where')
        if not w or inner.args.get('joins') or not inner.args.get('from'):
            continue
        src=inner.args['from'].this
        if not isinstance(src,exp.Table) or src.name.casefold() not in req.tables:
            continue
        where=w.this
        if not isinstance(where,exp.Is) or not isinstance(where.expression,exp.Null) or not isinstance(where.this,exp.Column):
            continue
        if where.this.table and where.this.table.casefold()!=src.alias_or_name.casefold():
            continue
        col=next((c for c in req.tables[src.name.casefold()]['columns'] if c['name'].casefold()==where.this.name.casefold()),None)
        if col and (col['not_null'] or col['pk']) and not re.search(r'\b(null|unknown|blank|unset|unspecified|missing name)\b',req.text):
            inner.set('where',None)
            yield 10,rendered(tree),'exclude existing related records'


def candidates(req,sql):
    try:
        t=validate_sql(sql)
        if not isinstance(t,exp.Select):
            return []
        out=[]
        for score,s,why in public_candidates(req,sql):
            if why in ('count related rows','sum stored quantities'):
                target=validate_sql(s)
                score+=target_support(t,target,req)
            out.append((score,s,why))
        out+=list(local_comparison(sql,req))+list(display_members(t.copy(),req))+list(empty_relation(t.copy(),req))
        return [r for r in out if len(r[1].encode())<=16000]
    except (ValueError,SqlglotError,RecursionError):
        return []
