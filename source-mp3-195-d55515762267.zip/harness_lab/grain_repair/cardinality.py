"""Tie a public-match replacement to a concrete counting or population discrepancy."""
import re

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.grain_repair.agent import GrainAgent
from harness_lab.grain_repair.compiler import count_focus, named_measure
from harness_lab.grain_repair.measure import measure_candidates
from harness_lab.intent_repair.pool import sql_key
from harness_lab.intent_repair.reconstruct import group_bound, sources
from harness_lab.intent_repair.roles import stems
from harness_lab.intent_repair.semantics import Requirement, rendered
from mp3_sql.sqlite_tool import validate_sql


def tables_used(tree):
    return {t.name.casefold() for t in tree.find_all(exp.Table)}


def row_projection(tree, req):
    if not tree.args.get('distinct') or req.distinct or req.ranking:
        return
    if (not tree.args.get('from') or not isinstance(tree.args['from'].this, exp.Table)
            or tree.args.get('group') or tree.args.get('limit')
            or any(not isinstance(c.unalias(), exp.Column) for c in tree.expressions)):
        return
    entity = tree.args['from'].this
    if not stems(entity.name) or not stems(entity.name) <= stems(req.question):
        return
    if not re.search(r'\b(all|each|every|whose|which (?:are|have)|that (?:are|have))\b', req.text):
        return
    joins = tree.args.get('joins', [])
    if joins:
        # A LEFT anti-join contributes exactly one row for an unmatched parent.
        if len(joins) != 1 or joins[0].side != 'LEFT' or not tree.args.get('where'):
            return
        missing = tree.args['where'].this
        if (not isinstance(missing, exp.Is) or not isinstance(missing.expression, exp.Null)
                or not isinstance(missing.this, exp.Column) or not isinstance(joins[0].this, exp.Table)
                or missing.this.table.casefold() != joins[0].this.alias_or_name.casefold()):
            return
        child = req.tables.get(joins[0].this.name.casefold(), {})
        edge = joins[0].args.get('on')
        if not isinstance(edge, exp.EQ) or not all(isinstance(c, exp.Column) for c in (edge.this, edge.expression)):
            return
        refs = {(c.table.casefold(), c.name.casefold()) for c in (edge.this, edge.expression)}
        fk = any(f['table'].casefold() == entity.name.casefold() and
                 {(entity.alias_or_name.casefold(), f['to'].casefold()), (joins[0].this.alias_or_name.casefold(), f['from'].casefold())} == refs
                 for f in child.get('foreign_keys', []))
        guaranteed = any(c['name'].casefold() == missing.this.name.casefold() and (c['pk'] or c['not_null']) for c in child.get('columns', []))
        if not fk or not guaranteed:
            return
    elif len(list(tree.find_all(exp.Select))) > 1:
        return
    new = tree.copy()
    new.set('distinct', None)
    yield 10, rendered(new), 'one display row per qualifying entity'


def group_members(tree, req):
    if (not group_bound(req.text) or not re.search(r'\ball (?:of )?(?:their|those|these|the)\b', req.text)
            or not tree.args.get('group') or not tree.args.get('having') or tree.args.get('joins')
            or tree.args.get('limit') or len(list(tree.find_all(exp.Select))) != 1):
        return
    keys = tree.args['group'].expressions
    if len(keys) != 1 or not isinstance(keys[0], exp.Column) or not stems(keys[0].name) <= stems(req.question):
        return
    having = tree.args['having'].this
    op, bound = group_bound(req.text)
    if (not isinstance(having, op) or not isinstance(having.this, exp.Count)
            or not isinstance(having.expression, exp.Literal) or having.expression.name != str(bound)):
        return
    if not all(isinstance(e.unalias(), exp.Column) for e in tree.expressions):
        return
    if all(c.unalias().name.casefold() == keys[0].name.casefold() for c in tree.expressions):
        return
    sub = tree.copy()
    sub.set('expressions', [keys[0].copy()])
    sub.set('order', None)
    frame = tree.copy()
    frame.set('group', None)
    frame.set('having', None)
    frame = frame.where(keys[0].copy().isin(query=sub))
    yield 12, rendered(frame), 'group qualifies all its members'


def justified(why, before, after, req):
    if why in ('aggregate each qualifying subject once', 'one display row per qualifying entity',
               'group qualifies all its members', 'exclude existing related records',
               'explicit disjunction', 'both qualifying populations', 'bind comparison subset locally'):
        return True
    if why == 'catalogue population':
        return not tables_used(before) & tables_used(after) and bool(before.find(exp.Count, exp.Distinct))
    if why == 'threshold on a stored count':
        return bool(before.args.get('having') and group_bound(req.text))
    if why == 'sum stored quantities':
        return bool(before.find(exp.Count) and after.find(exp.Sum))
    if why == 'all requirements bound on one table':
        return len(tables_used(after)) == 1 and bool(re.search(r'\b(all|every|each)\b', req.text))
    if why != 'count related rows':
        return False
    focus = count_focus(req)
    if not focus:
        return False
    named = named_measure(req, focus[1], sources(before, req).values())
    if not named or named.casefold() not in tables_used(after):
        return False
    removed = tables_used(before) - tables_used(after)
    multiplies = any(f['table'].casefold() == named.casefold() for t in removed
                     for f in req.tables.get(t, {}).get('foreign_keys', []))
    # Replacing an already matching ranked count requires a specific extra child
    # of the requested counting unit. A broad difference in syntax is insufficient.
    return multiplies and bool(re.search(r'\b(count|number|how many)\b', req.text))


class CardinalityAgent(GrainAgent):
    def __init__(self, old, variant):
        super().__init__(old, early=True)
        self.variant = variant

    def begin(self, obs, sql):
        self.incumbent = sql
        schema = next((h['observation'] for h in obs['history'] if h['tool'] == 'schema'), None)
        if not schema:
            return
        req = Requirement(obs['task']['question'], obs['example']['columns'], schema)
        matched = any(h['tool'] == 'check' and h['observation']['matches_example'] and sql_key(h['sql']) == sql_key(sql)
                      for h in obs['history'])
        try:
            before = validate_sql(sql)
            if not isinstance(before, exp.Select):
                return
            proposed = measure_candidates(req, sql)
            if self.variant in ('entity', 'membership'):
                proposed.extend(row_projection(before, req))
            if self.variant == 'membership':
                proposed.extend(group_members(before, req))
            self.candidates = sorted((c for c in proposed if not matched or justified(c[2], before, validate_sql(c[1]), req)),
                                     key=lambda c: (-c[0], c[1]))
        except (ValueError, SqlglotError, RecursionError):
            self.candidates = []
