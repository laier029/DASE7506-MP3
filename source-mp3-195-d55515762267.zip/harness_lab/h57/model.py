"""Pinned Qwen3 CPU repair decoder. SQL payloads remain unconstrained until AST validation."""
import time
from pathlib import Path

from harness_lab.h33.runtime import LocalGenerator, _LOCK, _rss_bytes, _sha
from harness_lab.h57 import protocol
from mp3_sql.common import digest

CAP = 384


class ActionPrefix:
    """Mask logits through KEEP/EOS or a complete valid action/slot header."""
    def __init__(self, tokenizer, valid_headers, prompt_len):
        self.prompt_len = prompt_len
        self.trie = {}
        self.free = object()
        for header in valid_headers:
            seq = tokenizer.encode(header, add_special_tokens=False)
            if tokenizer.decode(seq,skip_special_tokens=False) != header:
                raise ValueError("Action header is not tokenizer-roundtrippable")
            node = self.trie
            for t in seq:
                node = node.setdefault(t,{})
            if header == "KEEP":
                node[tokenizer.eos_token_id] = {self.free:True}
            else:
                node[self.free] = True
        self.payload_started = False

    def __call__(self, input_ids, scores):
        if self.payload_started:
            return scores
        if len(input_ids) != 1:
            raise ValueError("Action grammar requires single-task greedy decoding")
        node = self.trie
        for token in input_ids[0,self.prompt_len:].tolist():
            node = node[token]
        if self.free in node:
            self.payload_started = True
            return scores
        allowed = list(node)
        masked = scores.new_full(scores.shape,float("-inf"))
        masked[:,allowed] = scores[:,allowed]
        return masked


class Model(LocalGenerator):
    def __init__(self, adapter=None):
        super().__init__({"model_key":"base"})
        self.adapter = Path(adapter) if adapter else None
        self.identity = None

    def _load(self):
        if self.identity is not None:
            return self._loaded
        torch, tokenizer, model, base_id = super()._load()
        hashes = {}
        if self.adapter:
            from peft import PeftConfig, PeftModel
            if {p.name for p in self.adapter.iterdir()} != {"adapter_model.safetensors","adapter_config.json"}:
                raise ValueError("Expected a two-file safetensors LoRA export")
            config = PeftConfig.from_pretrained(str(self.adapter),local_files_only=True)
            if (config.base_model_name_or_path != self.repository or config.revision != self.revision
                    or config.peft_type != "LORA" or config.modules_to_save or config.bias != "none"
                    or set(config.target_modules) != {"q_proj","v_proj"}):
                raise ValueError("Adapter incompatible with H57 Qwen3 base")
            hashes = {p.name:digest(p) for p in self.adapter.iterdir()}
            model = PeftModel.from_pretrained(model,str(self.adapter),is_trainable=False,local_files_only=True)
        model.eval()
        count = sum(p.numel() for p in model.parameters())
        if count > 1_000_000_000 or any(p.dtype!=torch.float32 or p.device.type!="cpu" for p in model.parameters()):
            raise ValueError("CPU model or parameter cap violated")
        self.identity = {"repository":self.repository,"revision":self.revision,"base_parameters":base_id["actual_parameters"],
            "actual_parameters":count,"adapter_sha256":hashes,"device":"cpu","dtype":"float32","threads":4,
            "torch_version":base_id["torch_version"],"transformers_version":base_id["transformers_version"],
            "chat_template_sha256":base_id["chat_template_sha256"],"verified_base_metadata_sha256":base_id["verified_assets"]["metadata_sha256"]}
        self._loaded = (torch,tokenizer,model,self.identity)
        return self._loaded

    def generate(self, context):
        from transformers import LogitsProcessorList
        started = time.perf_counter()
        with _LOCK:
            torch,tok,model,identity = self._load()
            messages = protocol.messages(context)
            prompt = tok.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=False)
            inputs = tok(prompt,return_tensors="pt",add_special_tokens=False)
            n = int(inputs.input_ids.shape[-1])
            receipt = {"messages":messages,"rendered_prompt":prompt,"prompt_sha256":_sha(prompt),"prompt_tokens":n,
                "identity":identity,"generation_parameters":{"seed":42,"do_sample":False,"enable_thinking":False,
                "max_new_tokens":CAP,"threads":4,"constrained_headers":protocol.headers(context)}}
            if n > self.max_input_tokens or n + CAP > model.config.max_position_embeddings:
                # No shortened or hidden schema; fail closed and return the already checked incumbent.
                return {**receipt,"status":"prompt_limit","text":"","raw_text":"","new_tokens":0,
                        "generated_token_ids":[],"truncated":False,"seconds":time.perf_counter()-started,
                        "process_peak_rss_bytes":_rss_bytes()}
            constraint = ActionPrefix(tok,receipt["generation_parameters"]["constrained_headers"],n)
            with torch.inference_mode(),torch.random.fork_rng(devices=[]):
                torch.random.default_generator.manual_seed(42)
                seq = model.generate(**inputs,do_sample=False,temperature=None,top_p=None,top_k=None,use_cache=True,
                    max_new_tokens=CAP,pad_token_id=tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id,
                    logits_processor=LogitsProcessorList([constraint]))
            ids = seq[0,n:].tolist()
            eos = model.generation_config.eos_token_id
            ended = bool(ids and ids[-1] in (eos if isinstance(eos,list) else [eos]))
            raw = tok.decode(ids,skip_special_tokens=False)
            complete = tok.decode(ids[:-1],skip_special_tokens=False) if ended else ""
            return {**receipt,"status":"generated","text":complete.strip(),"raw_text":raw,
                    "generated_token_ids":ids,"new_tokens":len(ids),"truncated":not ended,
                    "seconds":time.perf_counter()-started,"process_peak_rss_bytes":_rss_bytes()}
