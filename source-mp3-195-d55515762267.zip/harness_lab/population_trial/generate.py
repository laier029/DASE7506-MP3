"""Public-only candidate generators for count identity and the scope of qualifications."""
import re

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.diagnosis_trial.compiler import _base, _edges, _column, _mentions, _physical, _q, _render
from harness_lab.h41.intent import by_name, numeric_col, primary, tokens
from harness_lab.h60.agent import sql_candidate
from harness_lab.h61.agent import comparable_sql
from harness_lab.h69.binding import _conjuncts, _scope
from harness_lab.h70.compiler import _graph, _paths
from mp3_sql.sqlite_tool import validate_sql


def matched_prefix(words, names):
    matches = [(len(tokens(name)), name) for name in names
               if tokens(name) and words[:len(tokens(name))] == tokens(name)]
    return [name for size,name in matches if size == max(m[0] for m in matches)]


def quantity_phrase(question):
    hits = re.findall(r'\b(?:how many|(?:the |greatest |largest |most |least |fewest )?number of|count (?:the )?)\s+([^?.!,;]+)', question, re.I)
    if len(hits) != 1:
        return ()
    text = re.sub(r'^(?:(?:different|distinct|unique|total|individual|separate)\s+)+', '', hits[0], flags=re.I)
    return tokens(text)


def count_candidates(row):
    q, schema = row['question'], row['schema']
    words = quantity_phrase(q)
    if not words:
        return
    tree, scope = _base(row['current_sql'], schema)
    if tree.find(exp.Window) or tree.args.get('offset'):
        return
    catalog = {t['name'].casefold(): t for t in schema}
    units = matched_prefix(words, [t['name'] for t in schema])
    if words[0] == 'time':
        # A frequency may name its event after a verb, e.g. "times a person attended events".
        units = [t['name'] for t in schema if _mentions(words[1:7],t['name'])]
    refs = {t['name']:s.alias_or_name for s,t in scope.values()}
    counts = list(tree.find_all(exp.Count))
    if any(c.args.get('expressions') or c.find_ancestor(exp.Window,exp.Filter) for c in counts):
        return
    if len({_render(c) for c in counts}) > 1:
        return

    # Explicit categorical quantities such as number of card types count actual distinct values.
    columns = [(t['name'],c['name']) for _,t in scope.values() for c in t['columns']]
    properties = matched_prefix(words,[field for _,field in columns])
    fields = [(tab,f) for tab,f in columns if f in properties]
    if len(fields)==1 and not units and counts and (re.search(r'\b(different|distinct|unique|types?|kinds?|categories|statuses)\b',q,re.I)):
        tab,f = fields[0]
        if all(isinstance(c.this,exp.Distinct) and len(c.this.expressions)==1 and _physical(c.this.expressions[0],scope)==(tab,f) for c in counts):
            return
        result = tree.copy()
        for c in result.find_all(exp.Count):
            c.set('this',exp.Distinct(expressions=[_column(refs[tab],f)]))
        yield 'count_property', _render(result)

    if len(units)!=1:
        return
    unit = units[0]
    key = primary(by_name(schema,unit))
    if not key:
        return
    if unit in refs and counts and (len(refs)>1 or any(not isinstance(c.this,exp.Star) for c in counts)):
        must_rebind = False
        for c in counts:
            arg = c.this
            if isinstance(arg,exp.Distinct):
                if len(arg.expressions)!=1:
                    return
                arg = arg.expressions[0]
                if _physical(arg,scope)==(unit,key['name']):
                    continue
            # Guard conditional counts and expressions other than a direct column or COUNT(*).
            if not isinstance(arg,(exp.Star,exp.Column)):
                return
            if isinstance(arg,exp.Column) and not _physical(arg,scope):
                return
            must_rebind = True
        if must_rebind and (len(refs)>1 or any(_physical(c.this,scope)!=(unit,key['name']) for c in counts)):
            result=tree.copy()
            for c in result.find_all(exp.Count):
                c.set('this',exp.Distinct(expressions=[_column(refs[unit],key['name'])]))
            yield 'count_entity',_render(result)

    # Rebuild a grouped path only when the existing source fails to identify the counted table
    # or its path uses other relations. Do not discard filters, ordering, join restrictions or aliases in them.
    if not tree.args.get('group') or not counts or any(tree.args.get(k) for k in ('where','having','limit','order','distinct')):
        return
    if any(not isinstance(j.args.get('on'), exp.EQ) or not all(isinstance(x,exp.Column) for x in
           (j.args['on'].this,j.args['on'].expression)) or j.side not in ('','LEFT') or j.method or j.kind not in ('','INNER')
           for j in tree.args.get('joins',[])):
        return
    outputs=[None if isinstance(e.unalias(),exp.Count) else _physical(e.unalias(),scope) for e in tree.expressions]
    attrs=[x for x in outputs if x]
    if not attrs or len({x[0] for x in attrs})!=1 or any(x is None and not isinstance(e.unalias(),exp.Count) for x,e in zip(outputs,tree.expressions)):
        return
    anchor=attrs[0][0]
    if anchor==unit:
        return
    group = [_physical(e,scope) for e in tree.args['group'].expressions]
    if not group or any(not x or x[0]!=anchor for x in group):
        return
    graph=_graph(catalog)
    paths=[(edges,nodes) for edges,nodes in _paths(anchor,graph) if nodes[-1]==unit]
    if not paths:
        return
    shortest=min(len(edges) for edges,_ in paths)
    paths=[(edges,nodes) for edges,nodes in paths if len(edges)==shortest]
    # Multiple roles become separate offline alternatives when the wording cannot bind a unique role.
    positive=re.search(r'\b(with at least|having|that have|who have|with one or more)\b',q,re.I)
    include_zero=bool(re.search(r'\b(each|all|per|every|including)\b',q,re.I)) and not positive
    for edges,nodes in paths:
        if set(nodes)==set(refs) and len(paths)==1 and not include_zero:
            continue
        src=_q(anchor)
        join=' LEFT JOIN ' if include_zero else ' JOIN '
        for e,node in zip(edges,nodes[1:]):
            src+=join+_q(node)+' ON '+_render(e.predicate())
        fields=[_render(_column(*x)) if x else 'COUNT(DISTINCT '+_render(_column(unit,key['name']))+')' for x in outputs]
        grouping=group
        ak=primary(by_name(schema,anchor))
        if ak and _mentions(tokens(q),anchor) and re.search(r'\b(each|every|per)\b',q,re.I) and set(group)<=set(attrs):
            grouping=[(anchor,ak['name'])]
        yield 'count_path','SELECT '+', '.join(fields)+' FROM '+src+' GROUP BY '+', '.join(_render(_column(*x)) for x in grouping)


def stored_quantity(row):
    # A total can be stored on detail rows. Counting those rows loses their individual quantities.
    q=row['question']
    phrase=quantity_phrase(q)
    if not phrase or not re.search(r'\btotal (?:number|count) of\b',q,re.I):
        return
    tree,scope=_base(row['current_sql'],row['schema'])
    if not tree.args.get('group') or any(tree.args.get(k) for k in ('having','limit','offset','order','distinct')):
        return
    targets=[]
    for _,(tab,table) in scope.items():
        for col in table['columns']:
            name=tokens(col['name'])
            metric=tuple(w for w in name if w not in {'number','num','of','total','count'})
            if metric and len(metric)<len(name) and numeric_col(col) and phrase[:len(metric)]==metric:
                targets.append((table['name'],col['name'],tab.alias_or_name))
    if len(targets)!=1:
        return
    owner,field,alias=targets[0]
    columns=tree.expressions
    affected=[ix for ix,e in enumerate(columns) if _physical(e.unalias(),scope)==(owner,field) or isinstance(e.unalias(),exp.Count)]
    if len(affected)!=1 or any(e.find(exp.AggFunc) for j,e in enumerate(columns) if j not in affected):
        return
    other=[g for g in tree.args['group'].expressions if _physical(g,scope)!=(owner,field)]
    if not other or any(not _physical(g,scope) for g in other):
        return
    ix=affected[0]
    expr=exp.Sum(this=_column(alias,field))
    if columns[ix].alias:
        expr=expr.as_(columns[ix].alias,quoted=True)
    tree.set('expressions',[expr if j==ix else e for j,e in enumerate(columns)])
    tree.set('group',exp.Group(expressions=other))
    yield 'count_stored_total',_render(tree)


def literal_mentioned(lit,question):
    return isinstance(lit,exp.Literal) and re.search(r'(?<!\w)'+re.escape(lit.this)+r'(?!\w)',question,re.I) is not None


def atom(part):
    if type(part) in (exp.GT,exp.GTE,exp.LT,exp.LTE,exp.EQ) and isinstance(part.this,exp.Column) and isinstance(part.expression,exp.Literal):
        return part.this,part.expression
    return None


def qualifies(positive, negative=False):
    marker=exp.Case().when(positive.copy(),exp.Literal.number(1)).else_(exp.Literal.number(0))
    return exp.EQ(this=exp.Max(this=marker),expression=exp.Literal.number(0 if negative else 1))


def group_result(tree, scope, conds, outer, negative, question):
    if any(tree.args.get(k) for k in ('group','having','order','limit','offset','windows','with','qualify')):
        return
    displays=[e.unalias() for e in tree.expressions]
    count=False
    if len(displays)==1 and isinstance(displays[0],exp.Count) and isinstance(displays[0].this,exp.Distinct):
        displays=displays[0].this.expressions
        if len(displays)!=1:
            return
        count=True
    refs=[_physical(e,scope) for e in displays]
    if not refs or not all(refs) or len({k[0] for k in refs})!=1:
        return
    anchor=refs[0][0]
    table=next(t for _,t in scope.values() if t['name']==anchor)
    key=primary(table)
    groups=[e.copy() for e in displays]
    names_requested = any(set(tokens(field)) & {'name','id','firstname','lastname'} for _,field in refs)
    if not count and key and names_requested and _mentions(tokens(question),anchor):
        alias=next(t.alias_or_name for t,s in scope.values() if s['name']==anchor)
        groups=[_column(alias,key['name'])]
    result=tree.copy()
    result.set('expressions',[e.copy() for e in displays])
    result.set('distinct',None)
    parts=[p.copy() for p in outer]
    if count:
        parts.append(exp.Not(this=exp.Is(this=displays[0].copy(),expression=exp.Null())))
    result.set('where',exp.Where(this=exp.and_(*parts)) if parts else None)
    result.set('group',exp.Group(expressions=groups))
    result.set('having',exp.Having(this=exp.and_(qualifies(conds[0]),qualifies(conds[1],negative))))
    if count:
        result=exp.select('COUNT(*)').from_(result.subquery('eligible_groups'))
    return _render(result)


def scope_candidates(row):
    q,schema=row['question'],row['schema']
    both=bool(re.search(r'\bboth\b.*\band\b',q,re.I))
    negative=bool(re.search(r'\b(?:but not|but (?:have|has|with) no|and (?:no|never)|without|except)\b',q,re.I))
    if not both and not negative:
        return
    tree=validate_sql(row['current_sql'])
    catalog={t['name'].casefold():t for t in schema}
    if not isinstance(tree,exp.Select) or not tree.args.get('where') or tree.find(exp.With,exp.Window,exp.SetOperation):
        return
    scope=_scope(tree,catalog)
    if not scope or len({t['name'] for _,t in scope.values()})!=len(scope):
        return
    where=tree.args['where'].this
    parts=list(_conjuncts(where))
    if both and len(list(tree.find_all(exp.Select)))==1:
        # Bind both comparisons to the same detail attribute but allow different rows to satisfy them.
        alternatives=[]
        for p in parts:
            u=p.unnest()
            if isinstance(u,exp.In) and isinstance(u.this,exp.Column) and len(u.expressions)==2:
                alternatives.append(([exp.EQ(this=u.this.copy(),expression=v.copy()) for v in u.expressions],[p]))
            if isinstance(u,exp.Or):
                alternatives.append(([u.this.unnest(),u.expression.unnest()],[p]))
        atoms=[p for p in parts if atom(p) and literal_mentioned(atom(p)[1],q)]
        if len(atoms)==2:
            alternatives.append((atoms,atoms))
        for terms,removed in alternatives:
            args=[atom(t) for t in terms]
            if not all(args) or not all(literal_mentioned(v,q) for _,v in args):
                continue
            refs=[_physical(c,scope) for c,_ in args]
            if not refs[0] or refs[0]!=refs[1] or _render(terms[0])==_render(terms[1]):
                continue
            if all(isinstance(t,exp.EQ) for t in terms) and args[0][1].this==args[1][1].this:
                continue
            sql=group_result(tree,scope,terms,[p for p in parts if p not in removed],False,q)
            if sql:
                yield 'scope_both',sql
        return
    if not negative or len(list(tree.find_all(exp.Select)))!=2:
        return
    neg=[p for p in parts if isinstance(p,exp.Not) and isinstance(p.this,exp.In) and p.this.args.get('query')]
    if len(neg)!=1:
        return
    member=neg[0].this
    sub=member.args['query'].this
    if not isinstance(sub,exp.Select) or len(sub.expressions)!=1 or not sub.args.get('where') or any(sub.args.get(k) for k in ('joins','having','group','limit','order','offset')):
        return
    inner=_scope(sub,catalog)
    if len(inner)!=1:
        return
    _,inner_meta=next(iter(inner.values()))
    inner_key=_physical(sub.expressions[0],inner)
    left_key=_physical(member.this,scope)
    if not inner_key or not left_key:
        return
    links={(c,p) for c,p in _edges(schema)}
    if left_key!=inner_key and (inner_key,left_key) not in links:
        return
    n=atom(sub.args['where'].this)
    if not n or not literal_mentioned(n[1],q):
        return
    attr=_physical(n[0],inner)
    if not attr:
        return
    positives=[p for p in parts if atom(p) and _physical(atom(p)[0],scope)==attr and literal_mentioned(atom(p)[1],q)]
    if len(positives)!=1 or atom(positives[0])[1].this.casefold()==n[1].this.casefold():
        return
    pos=positives[0]
    outer_alias=next((s.alias_or_name for s,t in scope.values() if t['name']==inner_meta['name']),None)
    if not outer_alias:
        return
    negative_term=sub.args['where'].this.copy()
    negative_term.set('this',_column(outer_alias,attr[1]))
    remaining=[p for p in parts if p not in [neg[0],pos]]
    sql=group_result(tree,scope,[pos,negative_term],remaining,True,q)
    if sql:
        yield 'scope_excluded_group',sql
    # The successful and excluded observations can also refer to the *same participant*.
    # Each alternative uses a real FK of the detail table. Retain the enclosing count and projection.
    for child,_ in sorted(links):
        if child[0]!=inner_meta['name'] or child==inner_key:
            continue
        newsub=sub.copy()
        newsub.set('from',exp.From(this=exp.Table(this=exp.to_identifier(child[0],quoted=True)).as_('excluded_record')))
        if 'excluded_record' in scope:
            continue
        not_condition=sub.args['where'].this.copy()
        not_condition.set('this',_column('excluded_record',attr[1]))
        newsub.set('where',exp.Where(this=exp.and_(not_condition,exp.EQ(this=_column('excluded_record',child[1]),expression=_column(outer_alias,child[1])))))
        newsub.set('expressions',[exp.Literal.number(1)])
        newsub.set('distinct',None)
        base=tree.copy()
        base.set('where',exp.Where(this=exp.and_(*(p.copy() for p in parts if p!=neg[0]),exp.Not(this=exp.Exists(this=newsub)))))
        yield 'scope_excluded_entity',_render(base)


def comparator_candidates(row):
    q=row['question']
    match=re.search(r'\b(higher|greater|more|lower|less|smaller) than (?:the [\w -]+? of )?(?:all|every)\b',q,re.I)
    if not match:
        return
    tree=validate_sql(row['current_sql'])
    if not isinstance(tree,exp.Select) or len(list(tree.find_all(exp.Select)))!=2:
        return
    for c in tree.find_all(exp.GT if match[1].lower() in ('higher','greater','more') else exp.LT):
        if not isinstance(c.expression,exp.Subquery):
            continue
        sub=c.expression.this
        if not isinstance(sub,exp.Select) or len(sub.expressions)!=1 or not isinstance(sub.expressions[0],exp.Column):
            continue
        if not sub.args.get('where') or any(sub.args.get(k) for k in ('joins','group','having','limit','offset','order')):
            continue
        catalog={t['name'].casefold():t for t in row['schema']}
        if not (_physical(c.this,_scope(tree,catalog)) and _physical(sub.expressions[0],_scope(sub,catalog))):
            continue
        lits=list(sub.args['where'].find_all(exp.Literal))
        if not lits or not all(literal_mentioned(v,q) for v in lits):
            continue
        fn=exp.Max if isinstance(c,exp.GT) else exp.Min
        sub.set('expressions',[fn(this=sub.expressions[0].copy())])
        yield 'scope_comparison',_render(tree)


def generate(row):
    old=comparable_sql(row['current_sql'])
    found={}
    for make in (count_candidates,stored_quantity,scope_candidates,comparator_candidates):
        try:
            for kind,sql in make(row):
                try:
                    sql=sql_candidate(sql,row['schema'])
                except (ValueError,RecursionError):
                    continue
                norm=comparable_sql(sql)
                if norm!=old:
                    found.setdefault(norm,{'family':kind,'sql':sql})
        except (ValueError,KeyError,TypeError,SqlglotError,RecursionError):
            continue
    return list(found.values())

