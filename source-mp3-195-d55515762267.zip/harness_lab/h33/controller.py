from copy import deepcopy

import json

from pathlib import Path

import re

from sqlglot import exp

from mp3_sql.common import BUDGET

from mp3_sql.sqlite_tool import validate_sql

def _query(sql):
    tree = validate_sql(sql)
    if any(isinstance(node, (exp.Merge, exp.Alter)) for node in tree.walk()):
        raise ValueError("Writing or administrative SQL is not allowed")
    if any(node.name.casefold() in {"load_extension", "readfile", "writefile"}
           for node in tree.find_all(exp.Anonymous)):
        raise ValueError("File and extension functions are not allowed")
    return tree
