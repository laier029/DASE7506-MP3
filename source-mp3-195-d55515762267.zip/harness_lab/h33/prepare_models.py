"""Offline verification of supported inference files against pinned public repository metadata."""
import hashlib
import json
from pathlib import Path


MODELS = {'base': {'repository': 'Qwen/Qwen3-0.6B', 'revision': 'c1899de289a04d12100db370d81485cdf75e47ca',
                   'directory': 'Qwen3-0.6B-c1899de289a04d12100db370d81485cdf75e47ca'}}
REQUIRED = ('config.json', 'generation_config.json', 'model.safetensors', 'tokenizer.json',
            'tokenizer_config.json', 'vocab.json', 'merges.txt')


def verify_model(directory, model):
    source = Path(__file__).with_name('base-metadata.json').read_bytes()
    meta = json.loads(source)
    spec = MODELS[model]
    if (meta['id'], meta['sha']) != (spec['repository'], spec['revision']):
        raise ValueError('Pinned base metadata mismatch')
    siblings = {row['rfilename']: row for row in meta['siblings']}
    for name in REQUIRED:
        path = Path(directory) / name
        record = siblings[name]
        size = record['size']
        if not path.is_file() or path.stat().st_size != size:
            raise ValueError('Wrong size or missing base asset: ' + name)
        if 'lfs' in record:
            digest, expected = hashlib.sha256(), record['lfs']['sha256']
        else:
            digest, expected = hashlib.sha1(f'blob {size}\0'.encode()), record['blobId']
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                digest.update(block)
        if digest.hexdigest() != expected:
            raise ValueError('Base asset digest mismatch: ' + name)
    for name in ('adapter_config.json', 'chat_template.jinja', 'added_tokens.json', 'special_tokens_map.json', 'chat_templates'):
        if (Path(directory) / name).exists():
            raise ValueError('Unexpected inference override for this Qwen revision: ' + name)
    return {'verified': True, 'metadata_sha256': hashlib.sha256(source).hexdigest(),
            'stored_tensor_parameters': meta['safetensors']['total'], 'repository': meta['id'], 'revision': meta['sha']}
