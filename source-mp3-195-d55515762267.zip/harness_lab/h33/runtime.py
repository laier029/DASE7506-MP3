"""One pinned public Qwen3 checkpoint, native template, auditable CPU generation."""

import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import threading
import time

from harness_lab.h33.prepare_models import MODELS, verify_model


_LOCK = threading.Lock()


class GenerationError(RuntimeError):
    def __init__(self, record):
        self.record = record
        super().__init__(record["error"])


def _sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _rss_bytes():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if sys.platform == "darwin" else value * 1024)


def verify_model_assets(directory, model_key):
    return verify_model(directory, model_key)


class LocalGenerator:
    """No task memory or cross-model fallback; load each process's checkpoint once."""

    def __init__(self, config):
        self.model_key = config.get("model_key", "base")
        if self.model_key not in MODELS:
            raise ValueError("Unknown fixed model key")
        spec = MODELS[self.model_key]
        self.repository, self.revision = spec["repository"], spec["revision"]
        for key, expected in (("model_repository", self.repository), ("model_revision", self.revision),
                              ("threads", 4), ("seed", 42), ("do_sample", False),
                              ("max_input_tokens", 12000)):
            value = config.get(key, expected)
            if value != expected or type(value) is not type(expected):
                raise ValueError(f"H33 fixes {key}={expected!r}")
        if "enable_thinking" in config:
            raise ValueError("H33 uses the native tokenizer default; omit enable_thinking")
        raw = config.get("model_path") or os.environ.get("MP3_BASE_MODEL")
        self.directory = Path(raw or Path("models") / spec["directory"]).expanduser().resolve()
        self.threads, self.seed, self.max_input_tokens = 4, 42, 12000
        self._loaded = None

    def _load(self):
        if self._loaded is None:
            manifest = verify_model_assets(self.directory, self.model_key)
            import torch
            import transformers
            from transformers import AutoModelForCausalLM, AutoTokenizer

            torch.set_num_threads(4)
            torch.set_num_interop_threads(1)
            tokenizer = AutoTokenizer.from_pretrained(str(self.directory), local_files_only=True,
                                                       trust_remote_code=False)
            model = AutoModelForCausalLM.from_pretrained(
                str(self.directory), local_files_only=True, trust_remote_code=False,
                use_safetensors=True, torch_dtype=torch.float32,
            ).to("cpu")
            model.eval()
            parameters = list(model.parameters())
            count = sum(p.numel() for p in parameters)
            if not 0 < count <= 1_000_000_000:
                raise ValueError("Loaded model exceeds the actual parameter limit")
            if model.config.model_type != "qwen3":
                raise ValueError("Unexpected loaded architecture")
            if any(p.device.type != "cpu" or p.dtype != torch.float32 for p in parameters):
                raise ValueError("All model parameters must be CPU float32")
            template = tokenizer.get_chat_template()
            model_config = model.config.to_json_string()
            generation_config = model.generation_config.to_json_string()
            shapes = {name: list(parameter.shape) for name, parameter in model.named_parameters()}
            identity = {
                "repository": self.repository, "revision": self.revision, "actual_parameters": count,
                "stored_tensor_parameters": manifest["stored_tensor_parameters"],
                "device": "cpu", "dtype": "float32", "threads": torch.get_num_threads(),
                "interop_threads": torch.get_num_interop_threads(),
                "torch_version": torch.__version__, "transformers_version": transformers.__version__,
                "model_config": json.loads(model_config), "model_config_sha256": _sha(model_config),
                "published_generation_config": json.loads(generation_config),
                "generation_config_sha256": _sha(generation_config),
                "parameter_shapes": shapes,
                "parameter_shapes_sha256": _sha(json.dumps(shapes, sort_keys=True, separators=(",", ":"))),
                "chat_template": template, "chat_template_sha256": _sha(template),
                "verified_assets": manifest,
            }
            self._loaded = (torch, tokenizer, model, identity)
        return self._loaded

    def generate(self, messages, max_new_tokens=2048):
        if type(max_new_tokens) is not int or not 1 <= max_new_tokens <= 2048:
            raise ValueError("max_new_tokens must be between 1 and 2048 including reasoning")
        if not isinstance(messages, list) or not messages or any(
            not isinstance(message, dict) or set(message) != {"role", "content"}
            or message["role"] not in {"system", "user", "assistant"}
            or not isinstance(message["content"], str) for message in messages
        ):
            raise ValueError("Messages must contain only a role and string content")
        started = time.perf_counter()
        record = {
            "repository": self.repository, "revision": self.revision,
            "generation_parameters": {"do_sample": False, "seed": 42, "max_new_tokens": max_new_tokens,
                                      "temperature": None, "top_p": None, "top_k": None,
                                      "use_cache": True, "chat_template_kwargs": {"add_generation_prompt": True},
                                      "thinking_policy": "native_tokenizer_default"},
        }
        try:
            with _LOCK:
                load_started = time.perf_counter()
                torch, tokenizer, model, identity = self._load()
                record.update(model=identity, load_seconds=time.perf_counter() - load_started)
                prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                record.update(rendered_prompt=prompt, prompt_sha256=_sha(prompt),
                              chat_template_sha256=identity["chat_template_sha256"],
                              prompt_open_thinking=prompt.rstrip().endswith("<think>"))
                inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
                prompt_tokens = int(inputs["input_ids"].shape[-1])
                record["prompt_tokens"] = prompt_tokens
                if prompt_tokens > self.max_input_tokens:
                    raise ValueError("Prompt exceeds 12000 tokens; refusing to truncate evidence")
                if prompt_tokens + max_new_tokens > model.config.max_position_embeddings:
                    raise ValueError("Prompt and generation exceed the model context")
                pad_id = tokenizer.pad_token_id
                if pad_id is None:
                    pad_id = tokenizer.eos_token_id
                record["generation_parameters"]["pad_token_id"] = pad_id
                generation_started = time.perf_counter()
                with torch.random.fork_rng(devices=[]), torch.inference_mode():
                    torch.random.default_generator.manual_seed(self.seed)
                    output = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False,
                                            temperature=None, top_p=None, top_k=None,
                                            pad_token_id=pad_id, use_cache=True)
                record["generation_seconds"] = time.perf_counter() - generation_started
                token_ids = output[0, prompt_tokens:].tolist()
                raw = tokenizer.decode(token_ids, skip_special_tokens=False)
                text = tokenizer.decode(token_ids, skip_special_tokens=True)
                eos = model.generation_config.eos_token_id
                eos_ids = set(eos if isinstance(eos, list) else [eos])
                stopped = bool(token_ids and token_ids[-1] in eos_ids)
                truncated = len(token_ids) >= max_new_tokens and not stopped
                record.update(text=text, decoded_text=text, raw_text=raw, generated_text=raw,
                              generated_token_ids=token_ids, new_tokens=len(token_ids),
                              stopped_on_eos=stopped, truncated=truncated,
                              final_available=bool(text.strip()) and not truncated,
                              seconds=time.perf_counter() - started, status="generated",
                              process_peak_rss_bytes=_rss_bytes())
                return record
        except Exception as error:
            record.update(status="runtime_error", error=f"{type(error).__name__}: {error}",
                          seconds=time.perf_counter() - started, process_peak_rss_bytes=_rss_bytes())
            raise GenerationError(record) from error
