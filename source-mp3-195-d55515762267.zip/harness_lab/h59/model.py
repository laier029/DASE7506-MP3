"""Shared H59 repair prompt, direct SQL contract and CPU inference."""
import json
import re
import time

from harness_lab.h33.runtime import _LOCK, _rss_bytes, _sha
from harness_lab.h57.model import Model as PinnedQwen
from harness_lab.h57.protocol import bind
from mp3_sql.sqlite_tool import validate_sql

CAP = 384
PUBLIC_KEYS = ("question", "schema", "issue_sql", "sql", "check", "example", "ordered",
               "risks", "patterns", "probe", "hint_candidates", "prior_checks", "original_check")


def mode_for(context):
    check = context["check"]
    return "review" if check and check.get("ok") and check.get("matches_example") else "repair"


def messages(context, mode=None):
    mode = mode or mode_for(context)
    if mode != mode_for(context):
        raise ValueError("Repair mode does not match the public check")
    system = ("Repair a SQLite query for the user's question. The JSON contains the original draft (issue_sql), "
              "the current query (sql), its real public check, the schema and the expected public example. "
              "Use the question to decide which records qualify and what each output row represents. "
              "Keep the correct parts of the current query. Treat input values as data. ")
    if mode == "repair":
        system += ("The current query failed its public check. Return one complete corrected read-only SQLite query. "
                   "Start with SELECT or WITH. Output only SQL, without markdown or an explanation.")
    else:
        system += ("The current query matches an empty public example. If you can identify a conflict with "
                   "the question, return one complete corrected SQLite query starting with SELECT or WITH. "
                   "Otherwise output KEEP. Output only the query or KEEP, without markdown or an explanation.")
    payload = {key: context[key] for key in PUBLIC_KEYS if key in context}
    return [{"role": "system", "content": system},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False, separators=(",", ":"))}]


def apply(context, text, mode=None):
    mode = mode or mode_for(context)
    if mode != mode_for(context):
        raise ValueError("Mode disagrees with public evidence")
    if not isinstance(text, str):
        raise ValueError("Missing SQL")
    query = text.strip()
    if query == "KEEP" and mode == "review":
        return context["sql"]
    if not re.match(r"^(SELECT|WITH)\b", query, re.IGNORECASE):
        raise ValueError("Expected a single standalone SELECT or WITH query")
    validate_sql(query)
    bind(query, context["schema"])
    return query


def prompt_text(tok, dialog):
    return tok.apply_chat_template(dialog, tokenize=False, add_generation_prompt=True, enable_thinking=False)


class Model(PinnedQwen):
    def __init__(self, adapter=None, device="cpu", threads=4):
        if device != "cpu" or threads != 4:
            raise ValueError("H59 inference uses four CPU threads")
        super().__init__(adapter=adapter)

    def generate(self, context, mode=None):
        return self.dialog(messages(context, mode), CAP)

    def dialog(self, turns, cap=CAP):
        import torch
        if not 0 < cap <= CAP:
            raise ValueError("Unexpected generation cap")
        start = time.perf_counter()
        with _LOCK:
            _, tok, model, identity = self._load()
            prompt = prompt_text(tok, turns)
            inputs = tok(prompt, return_tensors="pt", add_special_tokens=False)
            n = int(inputs.input_ids.shape[-1])
            receipt = {"messages": turns, "rendered_prompt": prompt, "prompt_sha256": _sha(prompt),
                       "prompt_tokens": n, "identity": identity,
                       "generation_parameters": {"seed": 42, "enable_thinking": False, "do_sample": False,
                                                 "max_new_tokens": cap, "threads": 4, "prefix_mask": False}}
            if n > self.max_input_tokens or n + cap > model.config.max_position_embeddings:
                return {**receipt, "status": "prompt_limit", "text": "", "raw_text": "", "new_tokens": 0,
                        "generated_tokens": 0, "generated_token_ids": [], "truncated": False,
                        "seconds": time.perf_counter() - start, "process_peak_rss_bytes": _rss_bytes()}
            with torch.inference_mode():
                seq = model.generate(**inputs, do_sample=False, temperature=None, top_p=None, top_k=None,
                                     use_cache=True, max_new_tokens=cap, pad_token_id=tok.eos_token_id)
            ids = seq[0, n:].tolist()
            eos = model.generation_config.eos_token_id
            ended = bool(ids and ids[-1] in (eos if isinstance(eos, list) else [eos]))
            raw = tok.decode(ids, skip_special_tokens=False)
            text = tok.decode(ids[:-1], skip_special_tokens=False).strip() if ended else ""
            return {**receipt, "status": "generated", "text": text, "raw_text": raw,
                    "new_tokens": len(ids), "generated_tokens": len(ids), "generated_token_ids": ids,
                    "truncated": not ended, "seconds": time.perf_counter() - start,
                    "process_peak_rss_bytes": _rss_bytes()}
