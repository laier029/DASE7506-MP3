"""Distinguish entity-level scalar aggregates from unrequested child-row weighting."""
import re
import statistics

from sqlglot import exp

from harness_lab.h41 import intent
from harness_lab.h41.verifier import matches
from harness_lab.h41.world import compare_world
from mp3_sql.sqlite_tool import validate_sql


def scalar_query(sql):
    tree = validate_sql(sql)
    if not isinstance(tree, exp.Select) or len(tree.expressions) != 1:
        return None
    if any(v for k, v in tree.args.items() if k not in {"expressions", "from", "joins"}):
        return None
    source = tree.args.get("from")
    if not source or not isinstance(source.this, exp.Table):
        return None
    value = tree.expressions[0].unalias()
    if not isinstance(value, (exp.Avg, exp.Count)):
        return None
    joins = tree.args.get("joins", [])
    if len(joins) > 1 or any(not isinstance(j.this, exp.Table) for j in joins):
        return None
    tables = [source.this, *(j.this for j in joins)]
    if any(t.db or t.catalog or not isinstance(t.this, exp.Identifier) for t in tables):
        return None
    aliases = {t.alias_or_name.casefold(): t.name for t in tables}
    if len(aliases) != len(tables) or len({t.name.casefold() for t in tables}) != len(tables):
        return None
    return value, aliases, joins


def resolve(column, aliases, schema):
    if not isinstance(column, exp.Column):
        return None
    names = [aliases.get(column.table.casefold())] if column.table else aliases.values()
    found = []
    for name in names:
        table = intent.by_name(schema, name) if name else None
        field = intent.by_name(table["columns"], column.name) if table else None
        if field:
            found.append((table["name"], field["name"]))
    return intent.unique(found)


def measure_words(field):
    words = list(intent.tokens(field))
    # Normalize generic count-column spellings such as nb_X, X_count, or number_of_X.
    markers = {"number", "num", "no", "nb", "count", "total"}
    count_field = bool(words and (words[0] in markers or words[-1] in markers))
    noun = " ".join(w for w in words if w not in markers | {"of"})
    return noun, count_field


def entity_question(question, parent, field):
    text = re.sub(r"^(?:(?:what (?:is|are)|give(?: me)?|return|show|find|list)\s+)?(?:the\s+)?",
                  "", question.lower().strip().rstrip("?.!"))
    normalized = " ".join(intent.tokens(text))
    owner = " ".join(intent.tokens(parent["name"]))
    if field is None:
        return normalized in {
            f"how many {owner}", f"how many {owner} are there", f"number of {owner}",
            f"total number of {owner}", f"count of {owner}",
        }
    noun, count_field = measure_words(field["name"])
    if not noun or not intent.numeric_col(field):
        return False
    measures = [noun] if not count_field else [f"number of {noun}", f"count of {noun}", f"{noun} count"]
    phrases = set()
    for measure in measures:
        phrases.add(f"{owner} {measure}")
        for prep in ("for", "across", "of", "per", "among"):
            phrases.update(f"{measure} {prep} {det}{owner}" for det in ("", "all ", "the ", "each "))
    if count_field:
        phrases.update((f"number of {owner} {noun}", f"count of {owner} {noun}"))
    return any(normalized == f"{agg} {phrase}" for agg in ("average", "mean") for phrase in phrases)


def design(question, schema, sqls):
    """Support only a plain aggregate vs the same aggregate with one PK/detail equijoin."""
    queries = [scalar_query(sql) for sql in sqls]
    if not all(queries) or sorted(len(q[2]) for q in queries) != [0, 1]:
        return None
    plain, joined = sorted(queries, key=lambda q: len(q[2]))
    agg, scopes, _ = plain
    other, join_scopes, (join,) = joined
    if type(agg) != type(other) or join.side not in ("", "LEFT") or join.kind not in ("", "INNER", "OUTER"):
        return None
    parent = intent.by_name(schema, next(iter(scopes.values())))
    pk = intent.primary(parent) if parent else None
    if not pk or parent["name"].casefold() not in {n.casefold() for n in join_scopes.values()}:
        return None
    detail_name = next(n for n in join_scopes.values() if n.casefold() != parent["name"].casefold())
    detail = intent.by_name(schema, detail_name)
    if not detail:
        return None
    pair = (parent["name"], pk["name"])
    cond = join.args.get("on")
    if not isinstance(cond, exp.EQ) or join.args.get("using") or join.args.get("method"):
        return None
    ends = [resolve(c, join_scopes, schema) for c in (cond.this, cond.expression)]
    if not all(ends) or pair not in ends:
        return None
    child_table, child_key = ends[1 - ends.index(pair)]
    if child_table != detail["name"]:
        return None
    declared = [f for f in detail["foreign_keys"] if f["from"].casefold() == child_key.casefold()]
    if declared:
        if len(declared) != 1 or declared[0]["table"].casefold() != parent["name"].casefold():
            return None
        if declared[0]["to"] and declared[0]["to"].casefold() != pk["name"].casefold():
            return None
    elif child_key.casefold() != pk["name"].casefold():
        return None
    field = None
    if isinstance(agg, exp.Avg):
        target = resolve(agg.this, scopes, schema)
        if not target or resolve(other.this, join_scopes, schema) != target:
            return None
        field = intent.by_name(parent["columns"], target[1])
        if not field or field["pk"]:
            return None
    else:
        for value, aliases in ((agg.this, scopes), (other.this, join_scopes)):
            if isinstance(value, exp.Distinct) and len(value.expressions) == 1:
                value = value.expressions[0]
            if not isinstance(value, exp.Star) and resolve(value, aliases, schema) != pair:
                return None
    if intent.choose(schema, parent["name"]) is None or not entity_question(question, parent, field):
        return None
    if field and any(c is not field and entity_question(question, parent, c) for c in parent["columns"]):
        return None
    return parent, pk, field, detail, child_key


def worlds(schema, parent, pk, field, detail, child_key):
    """Calculate answers independently as an average or count over the explicit population."""
    noun, is_count = measure_words(field["name"]) if field else ("", False)
    child_count = is_count and noun == " ".join(intent.tokens(detail["name"]))
    for label, counts, values in (
        ("unequal_fanout", [1, 2, 3], [6, 9, 18]),
        ("missing_details", [4, 0, 2, 0], [12, 18, 24, 30]),
    ):
        if child_count:
            values = counts
        rows = {parent["name"]: [], detail["name"]: []}
        for n, copies in enumerate(counts, 1):
            p = intent.entity_row(parent, n)
            if not p:
                raise ValueError("Cannot represent parent identity")
            if field:
                p[field["name"]] = values[n - 1]
            rows[parent["name"]].append(p)
            for _ in range(copies):
                child_rows = rows[detail["name"]]
                item = intent.entity_row(detail, len(child_rows) + 1) or {}
                item[child_key] = p[pk["name"]]
                for link in detail["foreign_keys"]:
                    source = intent.by_name(detail["columns"], link["from"])
                    if source["name"] in item or not (source["pk"] or source["not_null"]):
                        continue
                    target = intent.by_name(schema, link["table"])
                    key = intent.primary(target) if target else None
                    if (not key or target in (parent, detail) or target["foreign_keys"] or
                            (link["to"] and key["name"].casefold() != link["to"].casefold())):
                        raise ValueError("Unresolved required auxiliary parent")
                    entries = rows.setdefault(target["name"], [])
                    entry = intent.entity_row(target, len(entries) + 1)
                    if not entry:
                        raise ValueError("Cannot represent auxiliary parent")
                    entries.append(entry)
                    item[source["name"]] = entry[key["name"]]
                child_rows.append(item)
        expected = statistics.mean(values) if field else len(counts)
        yield label, rows, [[expected]]


def judge(question, schema, incumbent_sql, candidate_sql, ordered=False):
    result = {"choice": "abstain", "reason": "unsupported_aggregate_or_population", "worlds": []}
    if not incumbent_sql or not candidate_sql:
        return result
    try:
        spec = design(question, schema, [incumbent_sql, candidate_sql])
        if not spec:
            return result
        for label, rows, expected in worlds(schema, *spec):
            pair = compare_world(schema, rows, incumbent_sql, candidate_sql, ordered=ordered)
            if pair["status"] != "executed":
                return {**result, "reason": "synthetic_constraints_or_execution", "detail": pair["reason"]}
            record = {"case": label, "rows": rows, "expected": expected}
            for key in ("incumbent", "candidate"):
                record[key] = pair[key]["rows"]
                record[key + "_pass"] = matches(pair[key], expected, 1, ordered)
            result["worlds"].append(record)
        passes = [key for key in ("incumbent", "candidate") if all(w[key + "_pass"] for w in result["worlds"])]
        if len(passes) == 1:
            result.update(choice="model" if passes == ["candidate"] else "v16", reason="entity_grain_separated")
        else:
            result["reason"] = "no_unique_supported_answer"
    except (ValueError, KeyError, AttributeError, TypeError, RecursionError) as exc:
        result.update(reason="inconclusive", detail=str(exc)[:180])
    return result
