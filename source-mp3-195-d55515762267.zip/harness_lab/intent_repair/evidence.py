"""Separate public-failure recovery from public ties that require a concrete contradiction."""

import re

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.expanded import ExpandedAgent

from harness_lab.intent_repair.feedback import feedback_pool

from harness_lab.intent_repair.iterative import alternative_sets,evidence_action

from harness_lab.intent_repair.pool import sql_key,sql_features

from harness_lab.intent_repair.semantics import Requirement,column,rendered,table,words

from harness_lab.intent_repair.reconstruct import route,sources,conditions,projected,unique

from harness_lab.intent_repair.patterns import retrieve

from harness_lab.intent_repair.expanded import describe, library, DEST as PREVIOUS

from mp3_sql.sqlite_tool import validate_sql

DEST=PREVIOUS.parent/'evidence'

def exclusions(sql,req):
    """Construct the subject population and subtract only the disqualifying population."""
    root=validate_sql(sql)
    if not isinstance(root,exp.Select) or not req.negation:
        return
    scope=sources(root,req)
    predicates=conditions(root,req)
    for cols in projected(req,root,scope):
        owners=unique(c.table for e in cols for c in e.find_all(exp.Column))
        if len(owners)!=1:
            continue
        subject=owners[0]
        aggregates=[e for e in cols if isinstance(e,exp.AggFunc)]
        if aggregates and len(cols)!=1:
            continue
        pks=[c['name'] for c in req.tables[subject.lower()]['columns'] if c['pk']]
        if not pks:
            continue
        named=sorted(n for n in req.mentioned if n!=subject)
        sources_needed=unique(c.table for e in predicates for c in e.find_all(exp.Column))
        options=[unique(named+sources_needed),unique(sources_needed)]
        if not predicates:
            options+=[[t] for t in unique(scope.values()) if t!=subject]
        for names in options:
            stmt=route(subject,names,req)
            if stmt is None or not (stmt.args.get('joins') or predicates):
                continue
            if predicates:
                stmt=stmt.where(*(p.copy() for p in predicates))
            if not aggregates:
                all_subjects=exp.select(*(e.copy() for e in cols)).from_(table(subject))
                excluded=stmt.copy()
                excluded.set('expressions',[e.copy() for e in cols])
                yield 'subtract_display',rendered(all_subjects.except_(excluded))
            if len(pks)==1:
                pk=column(subject,pks[0])
                invalid=stmt.copy()
                invalid.set('expressions',[pk.copy()])
                ans=exp.select(*(e.copy() for e in cols)).from_(table(subject))
                yield 'subtract_entity',rendered(ans.where(exp.Not(this=pk.isin(query=invalid))))

def facts(sql,req):
    try:
        root=validate_sql(sql)
    except (ValueError,SqlglotError,RecursionError):
        return {}
    if not isinstance(root,exp.Select):
        return {}
    scope=sources(root,req)
    extras=[]
    for j in root.args.get('joins',[]):
        if not isinstance(j.this,exp.Table) or j.side or j.kind not in ('','INNER'):
            continue
        bound=scope.get(j.this.alias_or_name.lower())
        if not bound or bound in req.mentioned:
            continue
        eq=j.args.get('on')
        if not isinstance(eq,exp.EQ) or not all(isinstance(c,exp.Column) for c in (eq.this,eq.expression)):
            continue
        refs=[req.required(c,scope) for c in (eq.this,eq.expression)]
        if not all(refs):
            continue
        for child,fk in refs:
            if child==bound:
                continue
            for edge in req.tables[child.lower()]['foreign_keys']:
                if edge['from'].casefold()!=fk.casefold() or edge['table'].casefold()!=bound.casefold():
                    continue
                # Joining an optional, unused parent can exclude subjects.
                if not any(c['name'].casefold()==fk.casefold() and not c['not_null'] and not c['pk']
                           for c in req.tables[child.lower()]['columns']):
                    continue
                if not any(c.find_ancestor(exp.Join) is not j and req.required(c,scope) in
                    [(bound,x['name']) for x in req.tables[bound.lower()]['columns']] for c in root.find_all(exp.Column)):
                    extras.append(bound)
    role=set()
    for j in root.find_all(exp.Join):
        eq=j.args.get('on')
        if isinstance(eq,exp.EQ):
            for c in eq.find_all(exp.Column):
                ref=req.required(c,scope)
                if not ref:
                    continue
                for fk in req.tables[ref[0].lower()]['foreign_keys']:
                    if fk['from'].casefold()==ref[1].casefold():
                        specific=set(words(fk['from']))-set(words(fk['table']))-set(words(fk['to']))-{'id','code','by','of','the'}
                        role.update(specific & set(req.words))
    return dict(extras=set(extras),role=role)

def identifiable(old,new,fbase,fnew,req):
    """Preserve an already passing SQL unless a particular semantic discrepancy improves."""
    f,g=old['features'],new['features']
    if g['width_error']>f['width_error'] or g['shape']<f['shape'] or g['unbound']>f['unbound']:
        return False
    if g['width_error']<f['width_error'] or (g['exact_shape']>f['exact_shape'] and g['shape']>f['shape']):
        return True
    if g['self_edges']<f['self_edges'] or g['unbound']<f['unbound']:
        return True
    if fbase.get('extras',set())-fnew.get('extras',set()) and g['sources']<f['sources'] and g['missing_subject']<=f['missing_subject']:
        return True
    if fnew.get('role',set())>fbase.get('role',set()) and g['bad_edges']<=f['bad_edges']:
        return True
    if req.negation and g.get('negative_present',0)>f.get('negative_present',0):
        return True
    return (g['grounded_literals']>f['grounded_literals'] and g['unexplained_literals']<=f['unexplained_literals']
            and g['missing_subject']<=f['missing_subject'])

def evidence_pool(question,example,original,incumbent,history,patterns=None):
    entries=feedback_pool(question,example,original,incumbent,history,patterns)
    schema=next((e['observation'] for e in history if e['tool']=='schema'),None)
    if not schema:
        return entries
    req=Requirement(question,example['columns'],schema)
    prior=retrieve(question,schema,patterns if patterns is not None else library(PREVIOUS/'patterns.json'))
    hints=next((e['observation'] for e in history if e['tool']=='repair_hint'),[])
    for s in unique([original,incumbent]+hints):
        for gen in (alternative_sets,exclusions):
            try:
                for lab,sql in gen(s,req):
                    k=sql_key(sql)
                    if k in entries:
                        continue
                    f=sql_features(sql,req)
                    if not f or len(sql.encode())>16000:
                        continue
                    f.update(incumbent=0,draft=0,hint=0,previous_check=0,derived=1,support=1,
                             public_empty=int(example['row_count']==0),explicit_set=1)
                    entries[k]=dict(sql=sql,features=f,actions=[lab],parents=[sql_key(s)])
                    describe(entries[k],req,prior)
            except (SqlglotError,ValueError,RecursionError):
                continue
    base=sql_key(incumbent)
    if base not in entries:
        return entries
    fbase=facts(incumbent,req)
    for k,e in entries.items():
        e['features'].setdefault('explicit_set',0)
        f=facts(e['sql'],req)
        e['features']['optional_parent']=len(f.get('extras',set()))
        e['features']['named_edge_role']=len(f.get('role',set()))
        e['tie_evidence']=k==base or identifiable(entries[base],e,fbase,f,req)
    public=next((e['observation'] for e in history if e['tool']=='check' and sql_key(e['sql'])==base),None)
    if public and public['matches_example']:
        return {k:v for k,v in entries.items() if v['tie_evidence']}
    return entries

class EvidenceAgent(ExpandedAgent):
    def begin(self,obs,sql):
        self.incumbent=sql
        self.prefix=None

    def act(self,obs):
        if self.incumbent is None:
            a=self.baseline.act(obs)
            if a['tool']!='submit':
                return a
            self.begin(obs,a['sql'])
        if self.prefix is None:
            matched=any(e['tool']=='check' and sql_key(e['sql'])==sql_key(self.incumbent)
                        and e['observation']['matches_example'] for e in obs['history'])
            if not matched:
                a=evidence_action(obs)
                if a:
                    return a
            self.prefix=len(obs['history'])
            self.entries=evidence_pool(obs['task']['question'],obs['example'],obs['issue_sql'],self.incumbent,
                obs['history'],self.params.get('patterns'))
        return super().act(obs)
