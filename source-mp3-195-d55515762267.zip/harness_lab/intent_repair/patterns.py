"""Retrieve anonymized TRAIN repair patterns; store no example SQL, values or task IDs."""

import hashlib

import json

import math

from collections import Counter

from functools import lru_cache

from sqlglot import exp

from harness_lab.intent_repair.semantics import words

from mp3_sql.sqlite_tool import validate_sql

VOCAB=set('different distinct unique each per all any both either or and no not never without except than at least most more less fewer greater higher highest greatest maximum minimum max min lowest least largest smallest average mean sum total number count how many top first last latest earliest ascending descending order sort alphabetical between from to before after more have has had with who which what whose that where how many by group same shared common once times only include including also contain every their together along but of in and as for not one two three four five ten equal over under'.split())

def question_features(q):
    seq=[]
    for w in words(q):
        t=w if w in VOCAB else 'n' if w.isdigit() else '_'
        if t!='_' or not seq or seq[-1]!='_':
            seq.append(t)
    return {(' '.join(seq[j:j+n])) for n in (1,2,3) for j in range(len(seq)-n+1)}-{'_'}

def schema_key(schema):
    names=sorted((t['name'],[c['name'] for c in t['columns']]) for t in schema)
    return hashlib.sha256(json.dumps(names).encode()).hexdigest()

@lru_cache(maxsize=4096)
def operators(sql):
    try:
        tree=validate_sql(sql)
    except (ValueError,RecursionError):
        return set()
    sels=list(tree.find_all(exp.Select))
    if not sels:
        return set()
    root=sels[0]
    tags={k for k in ('group','order','limit','where','having','distinct') if root.args.get(k)}
    for marker, cls in [('union',exp.Union),('intersect',exp.Intersect),('except',exp.Except),('exists',exp.Exists),
                         ('not',exp.Not),('count',exp.Count),('avg',exp.Avg),('sum',exp.Sum),('min',exp.Min),('max',exp.Max)]:
        if tree.find(cls):
            tags.add(marker)
    if len(sels)>1:
        tags.add('nested')
    if root.args.get('joins'):
        tags.add('join')
    if root.args.get('order') and any(x.args.get('desc') for x in root.args['order'].expressions):
        tags.add('desc')
    return tags

def retrieve(q,schema,library):
    wanted=question_features(q)
    fingerprint=schema_key(schema)
    scored=[]
    for record in library:
        if record['schema']==fingerprint:
            continue
        terms=set(record['terms'])
        sim=len(terms & wanted)/math.sqrt(len(terms)*max(1,len(wanted)))
        scored.append((sim,record['ops']))
    best=sorted(scored,key=lambda v:-v[0])[:9]
    votes=Counter()
    total=0
    for v,tags in best:
        weight=v**6
        total+=weight
        for t in tags:
            votes[t]+=weight
    return {k:v/total for k,v in votes.items()} if total else {}
