"""Use public result differences to distinguish multiplicity, ordering and filter errors."""

import re

from collections import Counter

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.expanded import ExpandedAgent,expanded_pool,describe,library,DEST as PREVIOUS

from harness_lab.intent_repair.patterns import retrieve

from harness_lab.intent_repair.semantics import Requirement, column, rendered, words

from harness_lab.intent_repair.pool import sql_features,sql_key

from harness_lab.intent_repair.reconstruct import projected,conditions,route,unique,sources,limit_value,group_bound

from mp3_sql.sqlite_tool import validate_sql

DEST=PREVIOUS.parent/'feedback'

STOP=set('an the to a for about because find give show of as is on in at with by per whose each their are have has from that where who list number id name'.split())

def residual(example,result):
    if not result or not result['ok']:
        return 'unbound'
    if result['matches_example']:
        return 'match'
    if len(result['columns'])!=len(example['columns']):
        return 'projection'
    if not result['truncated'] and example['row_count']==len(example['rows']):
        current=Counter(tuple(r) for r in result['rows'])
        required=Counter(tuple(r) for r in example['rows'])
        if current and required and current.keys()==required.keys():
            if current==required:
                return 'ordering'
            if all(required[r]==1 and current[r]>=1 for r in required):
                return 'duplicates'
    return 'values'

def alternates(tree,req):
    filt=conditions(tree,req)
    for j,e in enumerate(filt):
        if not isinstance(e,(exp.EQ,exp.GT,exp.GTE,exp.LT,exp.LTE)) or not isinstance(e.expression,exp.Literal):
            continue
        literal=e.expression.name
        loc=re.search(r'(?<!\w)'+re.escape(literal)+r'(?!\w)',req.question,re.I)
        if not loc:
            continue
        before=set(words(req.question[:loc.start()])[-5:])-STOP
        after=set(words(req.question[loc.end():])[:3])-STOP
        def fit(t,c):
            wf=set(words(c))-STOP
            return 1.8*len(wf&before)+len(wf&after)+.25*len(set(words(t))&(before|after))
        orig=(e.this.table,e.this.name)
        old=fit(*orig)
        possible=[]
        for t in req.schema:
            for c in t['columns']:
                new=(t['name'],c['name'])
                if new==orig or not (set(words(c['name']))&(before|after)):
                    continue
                strength=fit(*new)
                if strength>=old+1 and (not e.expression.is_string or not re.search('INT|REAL|NUM|DOUBLE|DECIMAL',c['type'],re.I)):
                    possible.append((strength,new))
        for _,ref in sorted(possible,key=lambda item:(-item[0],item[1]))[:2]:
            fixes=[p.copy() for p in filt]
            fixes[j].set('this',column(*ref))
            yield fixes

def repairs(s,req,feedback):
    try:
        tree=validate_sql(s)
    except (ValueError,SqlglotError):
        return
    if not isinstance(tree,exp.Select):
        return
    if feedback=='duplicates' and not tree.args.get('distinct') and not tree.args.get('group'):
        yield 'checked_duplicates',rendered(tree.distinct())
    binding=sources(tree,req)
    existing_order=tree.args.get('order')
    filts=conditions(tree,req)
    sets=[('shape',filts)]+[('predicate_owner',ps) for ps in alternates(tree,req)]
    for projection in projected(req,tree,binding):
        fields=unique(c.table for v in projection for c in v.find_all(exp.Column))
        if not fields:
            fields=[next(iter(binding.values()),'')]
        if not fields[0]:
            continue
        primary=fields[0]
        for kind,ps in sets:
            filter_tables=unique(c.table for v in ps for c in v.find_all(exp.Column))
            frame=route(primary,unique(fields+filter_tables),req)
            if frame is None:
                continue
            frame.set('expressions',[v.copy() for v in projection])
            if ps:
                frame=frame.where(*(v.copy() for v in ps))
            if req.distinct:
                frame=frame.distinct()
            if kind=='predicate_owner' and not (req.ranking or req.negation or req.order or group_bound(req.text)):
                yield kind,rendered(frame)
            if not (req.order or req.ranking) or req.negation or group_bound(req.text) or kind!='shape':
                continue
            order_field=None
            if existing_order and len(existing_order.expressions)==1:
                field=existing_order.expressions[0].this
                if isinstance(field,exp.Column):
                    order_field=req.required(field,binding)
            explicit=sorted((len(set(words(c['name']))-STOP),t['name'],c['name']) for t in req.schema for c in t['columns']
                if len(set(words(c['name']))-STOP)>0 and all(w in req.words for w in words(c['name']))
                and (t['name'] in fields or t['name'] in binding.values()))
            if not order_field and len(projection)==1 and req.order and isinstance(projection[0],exp.Column):
                order_field=(projection[0].table,projection[0].name)
            options=unique(([order_field] if order_field else [])+[(t,c) for _,t,c in reversed(explicit[-2:])])
            for t,c in options:
                stmt=route(primary,unique(fields+filter_tables+[t]),req)
                if stmt is None:
                    continue
                stmt.set('expressions',[v.copy() for v in projection])
                if ps:
                    stmt=stmt.where(*(v.copy() for v in ps))
                if req.distinct:
                    stmt=stmt.distinct()
                desc=bool(re.search(r'\b(descending|most|greatest|highest|largest|longest|oldest|top|latest|maximum)\b',req.text))
                value=column(t,c)
                ranked=stmt.order_by(exp.Ordered(this=value,desc=desc,nulls_first=not desc))
                if req.ranking:
                    ranked=ranked.limit(limit_value(req.text))
                yield 'target_order',rendered(ranked)
                if req.ranking and len(projection)==1 and isinstance(projection[0],exp.Column) and projection[0]!=value and re.search(r'\b(most|least|fewest|total|highest|largest)\b',req.text):
                    grouped=stmt.group_by(projection[0].copy()).order_by(exp.Ordered(this=exp.Sum(this=value.copy()),desc=desc,nulls_first=not desc)).limit(limit_value(req.text))
                    yield 'rank_group_total',rendered(grouped)

def feedback_pool(question,example,original,incumbent,history,patterns=None):
    entries=expanded_pool(question,example,original,incumbent,history,patterns)
    schema=next((e['observation'] for e in history if e['tool']=='schema'),None)
    if not schema:
        return entries
    req=Requirement(question,example['columns'],schema)
    prior=retrieve(question,schema,patterns if patterns is not None else library(PREVIOUS/'patterns.json'))
    known={sql_key(e['sql']):residual(example,e['observation']) for e in history if e['tool']=='check'}
    hints=next((e['observation'] for e in history if e['tool']=='repair_hint'),[])
    for s in unique([original,incumbent]+hints):
        parent=sql_key(s)
        try:
            for action,sql in repairs(s,req,known.get(parent,'unknown')):
                if len(sql.encode())>16000:
                    continue
                k=sql_key(sql)
                if k not in entries:
                    f=sql_features(sql,req)
                    if f is None:
                        continue
                    f.update(incumbent=0,draft=0,hint=0,previous_check=0,derived=1,support=1,public_empty=int(example['row_count']==0))
                    entries[k]=dict(sql=sql,features=f,actions=[],parents=[])
                    describe(entries[k],req,prior)
                item=entries[k]
                if action not in item['actions']:
                    item['actions'].append(action)
                if parent not in item['parents']:
                    item['parents'].append(parent)
        except (ValueError,SqlglotError,RecursionError):
            continue
    for e in entries.values():
        f=e['features']
        actions=e['actions']
        f['public_multiplicity_evidence']=int('checked_duplicates' in actions)
        f['predicate_rebound']=int('predicate_owner' in actions)
        f['order_rebound']=int('target_order' in actions or 'rank_group_total' in actions)
        if f['order_rebound']:
            q=validate_sql(e['sql'])
            if q.args.get('order'):
                expr=q.args['order'].expressions[0].this
                f['named_order'] = int(any(set(words(c.name))-STOP and (set(words(c.name))-STOP)<=set(req.words) for c in expr.find_all(exp.Column)))
            else:
                f['named_order']=0
        else:
            f['named_order']=0
    return entries

class FeedbackAgent(ExpandedAgent):
    def begin(self,obs,sql):
        self.incumbent=sql
        self.prefix=len(obs['history'])
        self.entries=feedback_pool(obs['task']['question'],obs['example'],obs['issue_sql'],sql,obs['history'],self.params.get('patterns'))
