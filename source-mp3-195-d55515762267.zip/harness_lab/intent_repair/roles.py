"""Ground relational phrases in declared edges and verify an actual change in SQL."""

from collections import deque

from functools import lru_cache

import re

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.semantics import Requirement, column, rendered, table, words

from harness_lab.intent_repair.reconstruct import projected,conditions,sources,unique,group_bound,limit_value

from harness_lab.intent_repair.pool import sql_key

from harness_lab.intent_repair.staged import StagedAgent,public_match,DEST as PRIOR

from harness_lab.value_trial.probe import locate,observed,patch,program_values

from mp3_sql.sqlite_tool import validate_sql

DEST=PRIOR.parent/'roles'

STOP=set('a an the this of in to and as at by from for on with who whose it any which id code name details record type information number data ref table is are do have be all'.split())

@lru_cache(maxsize=4096)
def stems(s):
    def stem(w):
        if w in ('won','win','winner','winning'):
            return 'win'
        if len(w)>5 and w.endswith(('ing','ed')):
            w=w[:-3] if w.endswith('ing') else w[:-2]
            if len(w)>2 and w[-1]==w[-2]:
                w=w[:-1]
        return w
    return frozenset(stem(w) for w in words(s) if w not in STOP)

def edge_key(e):
    return frozenset(((e.child,e.fk),(e.parent,e.pk)))

def used_edges(query,req):
    scope=sources(query,req)
    used=set()
    for j in query.find_all(exp.Join):
        eq=j.args.get('on')
        if isinstance(eq,exp.EQ) and all(isinstance(c,exp.Column) for c in (eq.this,eq.expression)):
            refs=[req.required(c,scope) for c in (eq.this,eq.expression)]
            if all(refs):
                used.add(frozenset(refs))
    return used

def plans(req,root,needed):
    """Find the shortest declared route, allowing the question to disambiguate competing roles."""
    want=stems(req.question)
    built={root}
    chosen=[]
    for target in needed:
        if target in built:
            continue
        queue=deque((src,[],set(built)) for src in sorted(built))
        candidates=[]
        while queue:
            cur,path,seen=queue.popleft()
            for edge in req.graph[cur]:
                if edge in req.inferred:
                    continue
                dest=edge.other(cur)
                if dest in seen:
                    continue
                new=path+[(edge,dest)]
                if dest==target:
                    candidates.append(new)
                elif len(new)<3:
                    queue.append((dest,new,seen|{dest}))
        if not candidates:
            return None
        def quality(route):
            roles=set()
            for e,_ in route:
                roles.update((stems(e.fk)-stems(e.parent)-stems(e.pk)) & want)
            transit=set().union(*(stems(dest)&want for _,dest in route[:-1]))
            return 2*len(roles)+len(transit)-1.1*len(route)
        scores=sorted(((quality(p),i) for i,p in enumerate(candidates)),reverse=True)
        if len(scores)>1 and scores[1][0]==scores[0][0]:
            return None
        path=candidates[scores[0][1]]
        chosen+=path
        built.update(n for _,n in path)
    return chosen

def proposals(sql,req,ordered,strict=False):
    try:
        tree=validate_sql(sql)
    except (ValueError,SqlglotError,RecursionError):
        return []
    if not isinstance(tree,exp.Select) or req.negation or group_bound(req.text):
        return []
    explicit=stems(re.sub(r"""'[^']*'|"[^"]*" """.strip(), " ", req.question)) if strict else stems(req.question)
    if strict and len(list(tree.find_all(exp.Select)))!=1:
        return []
    kw=sorted(t['name'] for t in req.schema if stems(t['name']) and stems(t['name'])<=explicit)
    existing=used_edges(tree,req)
    old_tables={t.name.casefold() for t in tree.find_all(exp.Table)}
    filters=conditions(tree,req)
    choices=[]
    for proj in projected(req,tree,sources(tree,req)):
        sources_needed=unique(c.table for e in proj for c in e.find_all(exp.Column))
        if not sources_needed:
            continue
        required=unique(sources_needed+[c.table for p in filters for c in p.find_all(exp.Column)]+kw)
        path=plans(req,sources_needed[0],required)
        if not path:
            continue
        evidence=set()
        new_edges=0
        role_evidence=set()
        bridges=set()
        for edge,dest in path:
            if edge_key(edge) not in existing:
                role=(stems(edge.fk)-stems(edge.parent)-stems(edge.pk))&explicit
                evidence|=role
                role_evidence|=role
                new_edges+=1
            if dest.casefold() not in old_tables and stems(dest)<=explicit:
                evidence|=stems(dest)
                if dest not in sources_needed and any(e.child==dest or e.parent==dest for e,_ in path if e!=edge):
                    bridges.add(dest)
        if strict and not (role_evidence or bridges or
                any(isinstance(e,exp.AggFunc) for e in proj) and any(isinstance(e,exp.Column) for e in proj)):
            continue
        if not evidence:
            continue
        frame=exp.select(*(e.copy() for e in proj)).from_(table(sources_needed[0]))
        for edge,dest in path:
            frame=frame.join(table(dest),on=edge.predicate())
        if filters:
            frame=frame.where(*(f.copy() for f in filters))
        display=[e for e in proj if isinstance(e,exp.Column)]
        aggregates=[e for e in proj if isinstance(e,exp.AggFunc)]
        if display and aggregates:
            frame=frame.group_by(*(e.copy() for e in display))
        if req.distinct:
            frame=frame.distinct()
        if req.ranking:
            if not aggregates or not display:
                continue
            desc=not bool(re.search(r'\b(lowest|least|fewest|smallest|bottom)\b',req.text))
            frame=frame.order_by(exp.Ordered(this=aggregates[0].copy(),desc=desc,nulls_first=not desc)).limit(limit_value(req.text))
        elif req.order or ordered:
            order=tree.args.get('order')
            if not order or len(order.expressions)!=1:
                continue
            value=order.expressions[0].this
            if not isinstance(value,exp.Column):
                continue
            ref=req.required(value,sources(tree,req))
            if not ref or ref[0] not in required:
                continue
            updated=order.copy()
            updated.expressions[0].set('this',column(*ref))
            frame.set('order',updated)
        out=rendered(frame)
        if len(out.encode())<=16000 and sql_key(out)!=sql_key(sql):
            choices.append((2*len(evidence)+int(bool(filters))-.1*new_edges,out,sorted(evidence)))
    return choices

class RoleAgent(StagedAgent):
    propose=staticmethod(proposals)
    def __init__(self,baseline,params):
        super().__init__(baseline,params)
        self.provisional=None
        self.plan=None
        self.options=[]

    def act(self,obs):
        hist=obs['history']
        if self.provisional is None:
            a=super().act(obs)
            if a['tool']!='submit' or obs['remaining']==0:
                return a
            self.provisional=a['sql']
            schema=next((e['observation'] for e in hist if e['tool']=='schema'),None)
            if not schema:
                return a
            self.req=Requirement(obs['task']['question'],obs['example']['columns'],schema)
            # An edit must address a relationship that was missing from the submitted SQL.
            # Draft and hints contribute predicates, but cannot invent the trigger.
            incumbent=self.propose(self.provisional,self.req,obs['ordered'])
            if incumbent:
                self.options=sorted(incumbent,key=lambda item:(-item[0],item[1]))
            chk=next((h['observation'] for h in hist if h['tool']=='check' and sql_key(h['sql'])==sql_key(self.provisional)),None)
            if chk and (not chk['matches_example'] or not chk['row_count']):
                self.plan=locate(self.provisional,schema,self.req.question)
            self.start=len(hist)
        if not hasattr(self,'start'):
            return dict(tool='submit',sql=self.provisional)
        if self.options:
            _,sql,reason=self.options[0]
            feedback=next((h for h in hist if h['tool']=='check' and sql_key(h['sql'])==sql_key(sql)),None)
            if feedback and feedback['observation']['matches_example']:
                self.decision=dict(actions=['declared_relation'],grounding=reason)
                return dict(tool='submit',sql=feedback['sql'])
            if feedback is None and obs['remaining']:
                return dict(tool='check',sql=sql)
        if self.plan:
            e=next((h for h in hist if h['tool']=='execute' and h['sql']==self.plan['sql']),None)
            if e is None and obs['remaining']>=2:
                return dict(tool='execute',sql=self.plan['sql'])
            if e:
                vals=program_values(self.plan,observed(e['observation']))
                new=patch(self.provisional,self.req.schema,self.plan,vals)
                if new:
                    check=next((h for h in hist if h['tool']=='check' and sql_key(h['sql'])==sql_key(new)),None)
                    if check and check['observation']['matches_example']:
                        self.decision=dict(actions=['observed_literal'],field=self.plan['field'])
                        return dict(tool='submit',sql=check['sql'])
                    if check is None and obs['remaining']:
                        return dict(tool='check',sql=new)
        return dict(tool='submit',sql=self.provisional)
