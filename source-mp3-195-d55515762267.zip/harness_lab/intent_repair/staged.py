"""Keep proposal ranking independent of the evidence required to overrule a passing query."""

from pathlib import Path

from harness_lab.intent_repair.expanded import ExpandedAgent, expanded_pool, DEST as FIRST

from harness_lab.intent_repair.evidence import EvidenceAgent, DEST as SECOND, identifiable, facts

from harness_lab.intent_repair.semantics import Requirement

from harness_lab.intent_repair.pool import sql_key

DEST=FIRST.parent/'staged'

def public_match(sql,history):
    return any(h['tool']=='check' and sql_key(h['sql'])==sql_key(sql) and h['observation']['matches_example']
               for h in history)

class StagedAgent(ExpandedAgent):
    def __init__(self,baseline,params):
        super().__init__(baseline,params)
        self.recovery=None

    def begin(self,obs,sql):
        super().begin(obs,sql)
        old=sql_key(sql)
        if old not in self.entries or not public_match(sql,obs['history']):
            return
        schema=next(h['observation'] for h in obs['history'] if h['tool']=='schema')
        req=Requirement(obs['task']['question'],obs['example']['columns'],schema)
        original=self.entries[old]
        oldfacts=facts(sql,req)
        self.entries={k:e for k,e in self.entries.items() if k==old or
                      identifiable(original,e,oldfacts,facts(e['sql'],req),req)}

    def act(self,obs):
        if self.recovery is None:
            ans=super().act(obs)
            if ans['tool']!='submit' or obs['remaining']==0 or public_match(ans['sql'],obs['history']):
                return ans
            recovery_params=self.params['recovery']
            if 'patterns' in self.params:
                recovery_params=dict(recovery_params,patterns=self.params['patterns'])
            self.recovery=EvidenceAgent(None,recovery_params)
            self.recovery.begin(obs,ans['sql'])
        a=self.recovery.act(obs)
        if self.recovery.decision:
            self.decision=self.recovery.decision
        return a
