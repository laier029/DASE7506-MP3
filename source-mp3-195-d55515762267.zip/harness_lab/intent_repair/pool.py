"""Generate and describe repair alternatives using only the current public episode."""

from collections import Counter

from functools import lru_cache

import math

import re

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.semantics import Requirement, sketches, words, norm, phrase, rendered

from mp3_sql.sqlite_tool import validate_sql

@lru_cache(maxsize=2048)
def sql_key(sql):
    try:
        root=validate_sql(sql)
        for x in root.find_all(exp.Identifier):
            if not x.args.get('quoted'):
                x.set('this',x.name.casefold())
        return rendered(root)
    except (ValueError,SqlglotError,RecursionError):
        return sql.strip()

def stripped(e):
    v=e.unalias().copy()
    for c in v.find_all(exp.Column):
        c.set('table', None)
    return norm(rendered(v))

def sql_features(sql, req):
    try:
        t=validate_sql(sql)
    except (ValueError,SqlglotError,RecursionError):
        return None
    selects=list(t.find_all(exp.Select))
    if not selects:
        return None
    outer=t if isinstance(t,exp.Select) else selects[0]
    tables=list(t.find_all(exp.Table))
    bindings={v.alias_or_name.lower():req.tables[v.name.lower()]['name']
              for v in tables if v.name.lower() in req.tables}
    used=set(bindings.values())
    fields=set()
    errs=0
    outside=set()
    for c in t.find_all(exp.Column):
        if c.find_ancestor(exp.Join):
            continue
        ref=req.required(c,bindings)
        if ref:
            outside.add(ref[0])
            fields.add(ref[1])
            errs+=ref[0] not in used
    sel=outer.expressions
    total=max(len(req.headers),len(sel),1)
    correct=sum(stripped(a)==stripped(b) for a,b in zip(sel,req.targets) if b is not None)
    field_names={w for c in fields for w in words(c)}
    qset=set(req.words)
    lits=[l for s in selects for part in ('where','having') if s.args.get(part) for l in s.args[part].find_all(exp.Literal)]
    double=[c for s in selects if s.args.get('where') for c in s.args['where'].find_all(exp.Column)
            if c.this.args.get('quoted') and not c.table and c.name.lower() not in req.owners]
    litnames=[v.name.strip('%').lower() for v in lits+double]
    matched=sum(req.support(v) for v in lits+double)
    joins=list(t.find_all(exp.Join))
    wrong_edges=unknown_edges=self_edges=0
    for join in joins:
        eq=join.args.get('on')
        if not isinstance(eq,exp.EQ) or not all(isinstance(c,exp.Column) for c in (eq.this,eq.expression)):
            unknown_edges+=1
            continue
        left,right=(req.required(c,bindings) for c in (eq.this,eq.expression))
        if not left or not right:
            unknown_edges+=1
            continue
        if left==right and eq.this.table==eq.expression.table:
            self_edges+=1
        declared={frozenset(((edge.child,edge.fk),(edge.parent,edge.pk))) for edge in req.graph[left[0]]}
        if frozenset((left,right)) not in declared:
            wrong_edges+=1
    missing_mentioned=req.mentioned-used
    redundant=used-outside-req.mentioned
    scalar_count=outer.find(exp.Count) is not None
    if not outside and len(used)==1:
        redundant=set()
    ordered=outer.args.get('order') is not None
    limit=outer.args.get('limit') is not None
    groups=outer.args.get('group') is not None
    distinct=bool(outer.args.get('distinct') or t.find(exp.Distinct))
    named_evidence=len(qset & field_names)
    stats=dict(shape=correct/total,exact_shape=float(correct==total),width_error=abs(len(req.headers)-len(sel)),
        sources=len(tables),nested=len(selects)-1,unused=len(redundant),unmentioned=len(used-req.mentioned),
        missing_subject=len(missing_mentioned),joins=len(joins),bad_edges=wrong_edges,unknown_edges=unknown_edges,
        self_edges=self_edges,unbound=errs,grounded_literals=matched,unexplained_literals=len(litnames)-matched,
        missing_num=sum(v not in litnames and v not in sql.lower() for v in req.qnums),
        columns_named=min(named_evidence,5),distinct_expected=float(req.distinct and distinct),
        distinct_unasked=float(distinct and not req.distinct),order_requested_missed=float(req.order and not ordered),
        gratuitous_order=float(ordered and not req.order and not req.ranking),
        rank_limit=float(req.ranking and limit),extra_limit=float(limit and not req.ranking),
        unwanted_group=float(groups and not scalar_count and not req.ranking and not re.search(r'\b(each|per|group|having|at least)\b',req.text)),
        no_relation_for_subject=float(bool(missing_mentioned) and scalar_count),
        complexity=min(5,len(list(t.walk()))/30))
    return stats

def build_pool(question, example, original, incumbent, history):
    schema=next((e['observation'] for e in history if e['tool']=='schema'),None)
    if not schema:
        return {}
    req=Requirement(question,example['columns'],schema)
    hints=next((e['observation'] for e in history if e['tool']=='repair_hint'),[])
    seeds=[(incumbent,'incumbent'),(original,'draft')]
    seeds.extend((h,'hint') for h in hints if isinstance(h,str))
    seeds.extend((e['sql'],'checked') for e in history if e['tool']=='check')
    entries={}
    def put(sql,tag,parent):
        if not isinstance(sql,str) or len(sql.encode())>16000 or not sql.strip():
            return
        key=sql_key(sql)
        if key not in entries:
            f=sql_features(sql,req)
            if f is None:
                return
            entries[key]=dict(sql=sql,features=f,tags=Counter(),parents=set())
        entries[key]['tags'][tag]+=1
        entries[key]['parents'].add(parent)
    seen=set()
    for s,tag in seeds:
        k=sql_key(s)
        put(s,tag,k)
        if k in seen:
            continue
        seen.add(k)
        for c,action in sketches(s,req):
            put(c,'sketch_'+action,k)
    for key,e in entries.items():
        tags=e.pop('tags')
        e['features'].update(incumbent=int('incumbent' in tags),draft=int('draft' in tags),
            hint=min(tags['hint'],4),previous_check=int('checked' in tags),
            derived=int(any(k.startswith('sketch') and v for k,v in tags.items())),
            support=min(len(e['parents']),4),public_empty=int(example['row_count']==0))
        e['parents']=sorted(e['parents'])
        e['actions']=sorted(tags)
    return entries
