"""A question, a public result shape and a schema-grounded description of one SQL."""

import re

from collections import defaultdict

from functools import lru_cache

from sqlglot import exp, parse_one

from sqlglot.errors import SqlglotError

from harness_lab.h41.intent import tokens

from harness_lab.failure_family.generate import catalog, path_from, signature

from mp3_sql.sqlite_tool import validate_sql

def norm(s):
    return re.sub(r'[^a-z0-9*]+', '', s.lower())

@lru_cache(maxsize=4096)
def words(s):
    return tokens(s)

def phrase(q, name):
    w = words(name)
    return bool(w and any(q[j:j+len(w)]==w for j in range(len(q)-len(w)+1)))

def column(t, c):
    return exp.column(c, table=t, quoted=True)

def table(t):
    return exp.Table(this=exp.to_identifier(t, quoted=True))

def rendered(tree):
    return tree.sql(dialect='sqlite', comments=False)

def split_and(node):
    if isinstance(node, exp.And):
        return split_and(node.this)+split_and(node.expression)
    return [node]

class Requirement:
    def __init__(self, question, headers, schema):
        self.question = question
        self.words = words(question)
        self.text = question.casefold()
        self.schema = schema
        self.tables = {t['name'].lower():t for t in schema}
        self.owners = defaultdict(list)
        for t in schema:
            for c in t['columns']:
                self.owners[c['name'].lower()].append((t['name'], c['name']))
        self.mentioned = {t['name'] for t in schema if phrase(self.words,t['name'])}
        self.headers = headers
        self.targets = []
        for h in headers:
            try:
                expr=parse_one(h,read='sqlite')
                if isinstance(expr,(exp.Column,exp.Count,exp.Sum,exp.Avg,exp.Min,exp.Max)) and all(
                        isinstance(n,(exp.Column,exp.Identifier,exp.Star,exp.Count,exp.Sum,exp.Avg,
                                      exp.Min,exp.Max,exp.Distinct)) for n in expr.walk()):
                    self.targets.append(expr)
                    continue
            except (SqlglotError,ValueError):
                pass
            self.targets.append(None)
        self.graph,self.inferred=catalog(schema)
        self.distinct=bool(re.search(r'\b(distinct|different|unique)\b',self.text))
        self.ranking=bool(re.search(r'\b(most|least|fewest|greatest|highest|lowest|largest|smallest|longest|shortest|youngest|oldest|top|first|last|latest|earliest|maximum|minimum)\b',self.text))
        self.order=bool(re.search(r'\b(order(?:ed)?|sort(?:ed)?|ascending|descending|alphabetical(?:ly)?)\b',self.text))
        self.qnums=set(re.findall(r'(?<!\w)\d+(?:\.\d+)?(?!\w)',self.text))
        self.negation=bool(re.search(r"\b(without|never|no|except|not|neither)\b|n't\b",self.text))

    def support(self, literal):
        text=literal.name.strip('%').casefold()
        if not text:
            return False
        return bool(re.search(r'(?<!\w)'+re.escape(text)+r'(?!\w)',self.text))

    def required(self, col, scope):
        choices=self.owners[col.name.casefold()]
        if not choices:
            return None
        key=col.table.casefold()
        present=[v for v in choices if v[0] in scope.values()]
        if key and key in scope:
            known=[v for v in choices if v[0]==scope[key]]
            if known:
                return known[0]
        if len(present)==1:
            return present[0]
        if len(choices)==1:
            return choices[0]
        explicit=[v for v in choices if v[0] in self.mentioned]
        return explicit[0] if len(explicit)==1 else None

def simple(sql, req):
    tree=validate_sql(sql)
    if (not isinstance(tree,exp.Select) or len(list(tree.find_all(exp.Select)))!=1
        or tree.find(exp.With,exp.Window,exp.SetOperation) or not tree.args.get('from')):
        return None,None
    src=[tree.args['from'].this]+[j.this for j in tree.args.get('joins',[])]
    if not all(isinstance(t,exp.Table) and t.name.lower() in req.tables for t in src):
        return None,None
    scope={t.alias_or_name.lower():req.tables[t.name.lower()]['name'] for t in src}
    if len(scope)!=len(src) or len(set(scope.values()))!=len(src):
        return None,None
    return tree,scope

def enum_targets(req, tree, scope):
    if any(t is None for t in req.targets):
        return None
    result=[]
    for j,token in enumerate(req.targets):
        out=token.copy()
        for col in out.find_all(exp.Column):
            # Public labels may contain aliases from an entirely different query.
            # An incumbent projection is a binding hint only when its field matches.
            refs=[]
            if j<len(tree.expressions):
                refs=[req.required(c,scope) for c in tree.expressions[j].find_all(exp.Column)
                      if c.name.lower()==col.name.lower()]
                refs=[x for x in refs if x]
            bare=exp.column(col.name)
            ref=refs[0] if len(set(refs))==1 else req.required(bare,scope)
            if ref is None:
                return None
            col.replace(column(*ref)) if col is not out else None
            if col is out:
                out=column(*ref)
        result.append(out)
    return result

def prepare(tree, scope, req):
    if any(j.side or j.kind not in ('','INNER','CROSS') or j.method or j.args.get('using') for j in tree.args.get('joins',[])):
        return None
    joins=tree.args.get('joins',[])
    if any(j.args.get('on') and not all(isinstance(a,exp.EQ) and isinstance(a.this,exp.Column)
            and isinstance(a.expression,exp.Column) for a in split_and(j.args['on'])) for j in joins):
        return None
    work=tree.copy()
    work.set('from',None)
    work.set('joins',[])
    for col in list(work.find_all(exp.Column)):
        ref=req.required(col,scope)
        if ref is None:
            return None
        col.replace(column(*ref))
    return work

def reconnect(work, original, scope, req, preserve_named=True):
    needed=list(dict.fromkeys(col.table for col in work.find_all(exp.Column)))
    if preserve_named:
        needed.extend(t for t in scope.values() if t in req.mentioned and t not in needed)
    if not needed:
        needed=[v for v in scope.values() if v in req.mentioned]
        if not needed and len(scope)==1:
            needed=list(scope.values())
    if not needed:
        return None
    old=set()
    for join in original.args.get('joins',[]):
        eq=join.args.get('on')
        if isinstance(eq,exp.EQ) and all(isinstance(c,exp.Column) for c in (eq.this,eq.expression)):
            refs=[req.required(c,scope) for c in (eq.this,eq.expression)]
            if all(refs):
                old.add(frozenset(refs))
    visited={needed[0]}
    plan=work.copy()
    plan.set('from',exp.From(this=table(needed[0])))
    for name in needed[1:]:
        if name in visited:
            continue
        path=path_from(visited,name,req.graph,req.inferred,old,set(req.words))
        if not path:
            return None
        for edge,next_table in path:
            plan.join(table(next_table),on=edge.predicate(),copy=False)
            visited.add(next_table)
    return plan

def literal_atoms(tree):
    where=tree.args.get('where')
    return split_and(where.this) if where else []

def strip_unsupported(tree, req):
    atoms=literal_atoms(tree)
    keep=[]
    for a in atoms:
        vals=list(a.find_all(exp.Literal))
        # An unrelated literal can expose a gratuitous restriction. Numeric flags,
        # schema codes, negation and domain synonyms remain possible counterevidence.
        if vals and all(not req.support(v) for v in vals):
            if not req.negation and not any(v.name in ('0','1') for v in vals):
                continue
        keep.append(a)
    if len(keep)==len(atoms):
        return None
    out=tree.copy()
    out.set('where',exp.Where(this=exp.and_(*(a.copy() for a in keep))) if keep else None)
    return out

def sketches(sql,req):
    try:
        t,scope=simple(sql,req)
        if t is None:
            return
        frame=prepare(t,scope,req)
        if frame is None:
            return
        headers=enum_targets(req,t,scope)
        variants=[(frame,'preserve')]
        if headers:
            out=frame.copy()
            out.set('expressions',headers)
            if not any(isinstance(v,exp.AggFunc) for v in headers) and not req.ranking and not out.args.get('having'):
                # Retain the original grouping as a separate candidate.
                if out.args.get('group'):
                    ungroup=out.copy()
                    ungroup.set('group',None)
                    variants.append((ungroup,'output_without_group'))
            variants.append((out,'output'))
        for v,label in list(variants):
            cleared=strip_unsupported(v,req)
            if cleared:
                variants.append((cleared,label+'+predicate'))
        for v,label in variants:
            args=[(v,label)]
            if req.distinct and not v.args.get('distinct') and not any(v.find_all(exp.AggFunc)):
                x=v.copy()
                x.set('distinct',exp.Distinct())
                args.append((x,label+'+distinct'))
            for candidate,action in args:
                new=reconnect(candidate,t,scope,req)
                if new:
                    yield rendered(new),action
    except (SqlglotError,ValueError,RecursionError):
        return
