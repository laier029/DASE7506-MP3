"""Compile subject, qualification and output requirements as a new SELECT when needed."""

import re

from itertools import product

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.h41.intent import primary

from harness_lab.h70.compiler import _t

from harness_lab.failure_family.generate import path_from

from harness_lab.intent_repair.semantics import column, rendered, words, phrase, split_and

from mp3_sql.sqlite_tool import validate_sql

def unique(seq):
    return list(dict.fromkeys(seq))

def sources(query, req):
    return {t.alias_or_name.casefold():req.tables[t.name.lower()]['name'] for t in query.find_all(exp.Table)
            if t.name.lower() in req.tables}

def route(root, required, req):
    nodes={root}
    frame=exp.select().from_(_t(root))
    for other in required:
        if other in nodes:
            continue
        steps=path_from(nodes,other,req.graph,req.inferred,set(),set(req.words))
        if not steps:
            return None
        for edge,name in steps:
            frame.join(_t(name),on=edge.predicate(),copy=False)
            nodes.add(name)
    return frame

def projected(req,t,bindings):
    if not req.targets or any(x is None for x in req.targets):
        return
    choices=[]
    for idx,e in enumerate(req.targets):
        cols=list(e.find_all(exp.Column))
        if not cols:
            choices.append([e])
            continue
        if len(cols)!=1:
            return
        col=cols[0]
        refs=list(req.owners[col.name.lower()])
        if not refs:
            return
        prior=[req.required(c,bindings) for c in t.expressions[idx].find_all(exp.Column)
               if c.name.lower()==col.name.lower()] if idx<len(t.expressions) else []
        def priority(ref):
            return (ref in prior,ref[0] in req.mentioned,ref[0] in bindings.values())
        refs.sort(key=priority,reverse=True)
        # Rebinding an ambiguous display column also requires independent support
        # from another projected field, the question or an existing table.
        other_fields={c.name.lower() for target in req.targets for c in target.find_all(exp.Column) if target is not e}
        refs=[r for r in refs if len(refs)==1 or any(priority(r)) or
              any(any(z[0]==r[0] for z in req.owners[w]) for w in other_fields)][:3]
        variants=[]
        for ref in refs:
            out=e.copy()
            old=next(out.find_all(exp.Column))
            if old is out:
                out=column(*ref)
            else:
                old.replace(column(*ref))
            variants.append(out)
        choices.append(variants)
    for j,combo in enumerate(product(*choices)):
        if j>=8:
            break
        yield combo

def conditions(tree,req):
    result=[]
    for s in tree.find_all(exp.Select):
        scope=sources(s,req)
        if not s.args.get('where'):
            continue
        for part in split_and(s.args['where'].this):
            atom=part.this if isinstance(part,exp.Not) else part
            if not isinstance(atom,(exp.EQ,exp.NEQ,exp.GT,exp.GTE,exp.LT,exp.LTE,exp.Like,exp.In,exp.Between)):
                continue
            if not isinstance(atom.this,exp.Column) or atom.find(exp.Select):
                continue
            x=atom.copy()
            col=x.this
            ref=req.required(col,scope)
            if not ref:
                continue
            col.replace(column(*ref))
            for field in list(x.find_all(exp.Column)):
                if field.table or not field.this.args.get('quoted') or req.owners[field.name.lower()]:
                    continue
                field.replace(exp.Literal.string(field.name))
            lits=list(x.find_all(exp.Literal))
            if not lits or any(not req.support(l) for l in lits):
                continue
            if isinstance(part,exp.Not) and not req.negation:
                continue
            if isinstance(x,exp.NEQ) and req.negation:
                x=exp.EQ(this=x.this.copy(),expression=x.expression.copy())
            result.append(x)
    return list({rendered(x):x for x in result}.values())[:5]

def limit_value(q):
    m=re.search(r'\b(?:top|first|bottom|last)\s+(\d+|one|two|three|four|five|ten)\b',q)
    if not m:
        return 1
    text=m[1]
    return int(text) if text.isdigit() else dict(one=1,two=2,three=3,four=4,five=5,ten=10)[text]

def group_bound(q):
    hit=re.search(r'\b(at least|at most|more than|greater than|fewer than|less than|over|exactly)\s+(\d+|one|two|three|four|five|ten)\b',q)
    if not hit:
        return None
    n=hit[2]
    n=int(n) if n.isdigit() else dict(one=1,two=2,three=3,four=4,five=5,ten=10)[n]
    op={'at least':exp.GTE,'at most':exp.LTE,'more than':exp.GT,'greater than':exp.GT,
        'fewer than':exp.LT,'less than':exp.LT,'over':exp.GT,'exactly':exp.EQ}[hit[1]]
    return op,n

def anchors(req):
    # Avoid interpreting the modifier in "train station" as a separate train.
    names=sorted(req.mentioned,key=lambda s:-len(words(s)))
    result=[]
    for n in names:
        if not any(phrase(words(longer),n) for longer in result):
            result.append(n)
    return result

def compile_frames(sql,req):
    try:
        tree=validate_sql(sql)
    except (ValueError,SqlglotError):
        return
    sels=list(tree.find_all(exp.Select))
    if not sels:
        return
    t=sels[0]
    binding=sources(tree,req)
    stated=anchors(req)
    filters=conditions(tree,req)
    f_tables=unique(c.table for p in filters for c in p.find_all(exp.Column))
    rel=unique(binding.values())
    filt=exp.and_(*(p.copy() for p in filters)) if filters else None
    threshold=group_bound(req.text)
    groups=bool(re.search(r'\b(each|per|group(?:ed)? by|for every|for different)\b',req.text))
    rank_count=bool(re.search(r'\b(most|fewest|least|number of|times|common|frequent|top)\b',req.text)) and req.ranking
    for projections in projected(req,t,binding):
        fields=unique(c.table for e in projections for c in e.find_all(exp.Column))
        if not fields:
            if len(stated)==1:
                fields=stated.copy()
            elif rel:
                fields=[rel[0]]
            else:
                continue
        root=fields[0]
        def base(extra=(),with_where=True):
            src=route(root,unique(fields+list(extra)+(f_tables if with_where else [])),req)
            if src is None:
                return None
            src.set('expressions',[e.copy() for e in projections])
            if filt is not None and with_where:
                src=src.where(filt.copy())
            return src
        out=base(stated)
        if out is None:
            continue
        display=[v for v in projections if isinstance(v,exp.Column)]
        aggregates=[v for v in projections if isinstance(v,exp.AggFunc)]
        if not req.negation and not req.ranking and not req.order and not threshold:
            if (filt is not None or not tree.find(exp.Where)) and not tree.find(exp.Having):
                if not (display and aggregates):
                    if req.distinct and not aggregates:
                        out=out.distinct()
                    yield 'scope_and_output',rendered(out)
                if len(set(fields))==1 and not aggregates and not filt and not tree.find(exp.Where):
                    if re.search(r'\b(who are (all )?the|which different|distinct|unique)\b',req.text):
                        yield 'distinct_subject',rendered(out.distinct())
        if len(display)==1 and len(projections)==1 and not filt and ' and ' in req.text:
            name=display[0].name.lower()
            same=[v for v in req.owners[name] if v[0] in stated]
            if len(same)==2 and not req.negation and not req.ranking and not req.order:
                queries=[exp.select(column(*v)).from_(_t(v[0])) for v in same]
                yield 'union_subjects',rendered(queries[0].union(queries[1]))
        if not aggregates and req.negation and len(set(fields))==1:
            outer=base(with_where=False)
            if outer is not None:
                # Exclude a subject exactly when a disqualifying relationship exists.
                inner_tables=[n for n in unique(stated+f_tables+rel) if n!=root]
                if inner_tables:
                    for required in [unique(stated+f_tables),unique(inner_tables+f_tables)]:
                        required=[z for z in required if z!=root]
                        if not required:
                            continue
                        frames=route(root,required,req)
                        joins=frames.args.get('joins',[]) if frames is not None else []
                        if not joins:
                            continue
                        first=joins[0]
                        sub=exp.select(exp.Literal.number(1)).from_(first.this.copy())
                        sub.set('joins',[j.copy() for j in joins[1:]])
                        subset=[p.copy() for p in filters if any(c.table!=root for c in p.find_all(exp.Column))]
                        sub=sub.where(first.args['on'].copy(),*subset)
                        outer_filters=[p.copy() for p in filters if all(c.table==root for c in p.find_all(exp.Column))]
                        proposed=outer.where(exp.Not(this=exp.Exists(this=sub)),*outer_filters)
                        yield 'exclude_related',rendered(proposed)
        if display and (rank_count or threshold or groups and aggregates):
            roles=[n for n in stated if n not in fields]
            if len(roles)>3:
                continue
            role_sets=[roles]
            for n in rel:
                if n not in fields and n not in roles:
                    role_sets.append(roles+[n])
            for role_set in role_sets[:5]:
                stmt=base(role_set)
                if stmt is None:
                    continue
                group_keys=[[e.copy() for e in display]]
                pk=primary(req.tables[root.lower()])
                if pk and root in stated:
                    group_keys.append([column(root,pk['name'])])
                for keys in group_keys:
                    alt=stmt.group_by(*keys)
                    count=exp.Count(this=exp.Star())
                    if threshold:
                        op,n=threshold
                        alt=alt.having(op(this=count.copy(),expression=exp.Literal.number(n)))
                    if rank_count:
                        desc=not re.search(r'\b(fewest|least|lowest|bottom)\b',req.text)
                        alt=alt.order_by(exp.Ordered(this=count.copy(),desc=desc,nulls_first=not desc)).limit(limit_value(req.text))
                    yield 'group_subject',rendered(alt)
