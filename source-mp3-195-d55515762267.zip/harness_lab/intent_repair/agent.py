"""Use the original tool trajectory, then check outstanding semantic repair proposals."""

import json

from pathlib import Path

from harness_lab.intent_repair.pool import build_pool,sql_key

from harness_lab.intent_repair.rank import ordered,score

class IntentRepairAgent:
    def __init__(self,baseline,params):
        self.baseline=baseline
        self.params=params
        self.incumbent=None
        self.entries={}
        self.prefix=None
        self.decision={}

    def begin(self,obs,sql):
        self.incumbent=sql
        self.prefix=len(obs['history'])
        self.entries=build_pool(obs['task']['question'],obs['example'],obs['issue_sql'],sql,obs['history'])

    def act(self,obs):
        if self.incumbent is None:
            action=self.baseline.act(obs)
            if action['tool']!='submit':
                return action
            self.begin(obs,action['sql'])
        history=obs['history']
        feedback={sql_key(e['sql']):e for e in history if e['tool']=='check'}
        key=sql_key(self.incumbent)
        if key in self.entries:
            w=self.params['weights']
            is_match=feedback.get(key,{}).get('observation',{}).get('matches_example') is True
            floor=score(self.entries[key],w)+self.params['threshold'] if is_match else -float('inf')
            for value,other,e in ordered(self.entries,key,w):
                if value<=floor:
                    break
                if other in feedback:
                    if feedback[other]['observation']['matches_example']:
                        self.decision=dict(actions=e['actions'],features=e['features'],score=value,
                                           source_score=score(self.entries[key],w))
                        return {'tool':'submit','sql':feedback[other]['sql']}
                elif obs['remaining']>0 and len(history)-self.prefix<3:
                    return {'tool':'check','sql':e['sql']}
        return {'tool':'submit','sql':self.incumbent}
