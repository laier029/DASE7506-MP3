"""Combine role-aware repairs, reconstructed SQL, and cross-schema operator retrieval."""

import json

import re

from functools import lru_cache

from pathlib import Path

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.agent import IntentRepairAgent

from harness_lab.intent_repair.pool import build_pool,sql_features,sql_key

from harness_lab.intent_repair.patterns import operators,retrieve

from harness_lab.intent_repair.reconstruct import compile_frames

from harness_lab.intent_repair.semantics import Requirement,words

from harness_lab.population_trial.generate import generate as population

from harness_lab.relational_trial.operators import classified,propose

from harness_lab.diagnosis_trial.compiler import compile_diagnosis,program_diagnosis

from harness_lab.failure_family.generate import generate as routes

from mp3_sql.sqlite_tool import validate_sql

DEST = Path(__file__).resolve().parent

@lru_cache(maxsize=2)
def library(path):
    return json.loads(Path(path).read_text())

def describe(e,req,prior):
    ops=operators(e['sql'])
    f=e['features']
    for k in ('group','order','limit','distinct','nested','not','count','join','having','desc'):
        f['retrieved_'+k]=prior.get(k,0) if k in ops else -prior.get(k,0)
    f['retrieval_agreement']=sum(prior.get(k,0) if k in ops else 1-prior.get(k,0)
                                 for k in ('group','order','limit','having','join','nested'))/6
    f['negative_present']=float(req.negation and bool(ops & {'not','except'}))
    f['negative_absent']=float(req.negation and not ops & {'not','except'})
    f['count_order']=float(req.ranking and 'order' in ops and 'count' in ops)
    f['individual_count']=float('count' in ops and len(req.targets)==1 and isinstance(req.targets[0],exp.Count))
    f['explicit_threshold']=float('having' in ops and bool(re.search(r'\b(at least|at most|more than|fewer than|less than)\b',req.text)))
    f['typed_frame']=float('group_subject' in e['actions'] or 'scope_and_output' in e['actions'])
    f['absent_frame']=float('exclude_related' in e['actions'])
    f['relation_frame']=float(any(s.startswith('rel_') for s in e['actions']))
    tree=validate_sql(e['sql'])
    f['compound_without_signal']=float(bool(ops & {'union','intersect','except'}) and not
                                          re.search(r'\b(both|and|either|or|not|without|except|never|no)\b',req.text))
    f['same_display_group']=0
    s=tree if isinstance(tree,exp.Select) else next(tree.find_all(exp.Select),None)
    if s is not None and s.args.get('group'):
        names={c.name.lower() for item in s.expressions if not item.find(exp.AggFunc) for c in item.find_all(exp.Column)}
        groups={c.name.lower() for c in s.args['group'].find_all(exp.Column)}
        f['same_display_group']=int(bool(names) and names==groups)

def expanded_pool(question,example,original,incumbent,history,patterns=None):
    entries=build_pool(question,example,original,incumbent,history)
    schema=next((e['observation'] for e in history if e['tool']=='schema'),None)
    if not schema:
        return entries
    req=Requirement(question,example['columns'],schema)
    prior=retrieve(question,schema,patterns if patterns is not None else library(DEST/'patterns.json'))
    hints=next((e['observation'] for e in history if e['tool']=='repair_hint'),[])
    seeds=list(dict.fromkeys([incumbent,original]+[s for s in hints if isinstance(s,str)]))
    for s in seeds:
        parent=sql_key(s)
        def add(sql,action):
            if not sql or len(sql.encode())>16000:
                return
            k=sql_key(sql)
            if k not in entries:
                features=sql_features(sql,req)
                if features is None:
                    return
                features.update(incumbent=0,draft=0,hint=0,previous_check=0,derived=1,support=1,
                                public_empty=int(example['row_count']==0))
                entries[k]=dict(sql=sql,features=features,actions=[],parents=[])
            e=entries[k]
            if action not in e['actions']:
                e['actions'].append(action)
            if parent not in e['parents']:
                e['parents'].append(parent)
                e['features']['support']=min(4,len(e['parents']))
        try:
            for label,sql in compile_frames(s,req):
                add(sql,label)
        except (SqlglotError,ValueError,RecursionError):
            pass
        row=dict(question=question,current_sql=s,schema=schema)
        for candidate in routes(row):
            add(candidate['sql'],'rel_path')
        for candidate in population(row):
            add(candidate['sql'],'rel_'+candidate['family'])
        diag=program_diagnosis(question,schema,s)
        default,_=compile_diagnosis(diag,schema,s)
        selected,_=propose(row,classified(question),dict(candidate=default,diagnosis=diag))
        add(default,'semantic_edit')
        add(selected,'rel_population')
    for e in entries.values():
        describe(e,req,prior)
    return entries

class ExpandedAgent(IntentRepairAgent):
    def begin(self,obs,sql):
        self.incumbent=sql
        self.prefix=len(obs['history'])
        self.entries=expanded_pool(obs['task']['question'],obs['example'],obs['issue_sql'],sql,obs['history'],
                                   self.params.get('patterns'))
