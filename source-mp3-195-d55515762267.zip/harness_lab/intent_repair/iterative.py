"""Request remaining tool evidence before composing two grounded edits."""

from pathlib import Path

import re

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.expanded import ExpandedAgent, expanded_pool,describe,library,DEST as PREVIOUS

from harness_lab.intent_repair.patterns import retrieve

from harness_lab.intent_repair.semantics import Requirement,sketches,rendered,words,column,table

from harness_lab.intent_repair.pool import sql_key,sql_features

from harness_lab.intent_repair.rank import score

from harness_lab.intent_repair.reconstruct import compile_frames

from harness_lab.population_trial.generate import generate as population

from mp3_sql.sqlite_tool import validate_sql

DEST=PREVIOUS.parent/'iterative'

def evidence_action(obs):
    hist=obs['history']
    if any(e['tool']=='repair_hint' for e in hist):
        return None
    original=obs['issue_sql']
    already=any(e['tool'] in ('check','execute') and e['sql']==original for e in hist)
    if obs['remaining']<2+int(not already):
        return None
    return dict(tool='repair_hint') if already else dict(tool='check',sql=original)

def alternative_sets(s,req):
    try:
        root=validate_sql(s)
    except (ValueError,RecursionError):
        return
    # Apply a scalar universal comparison to the extremum over its reference set.
    if re.search(r'\b(all|every|any)\b',req.text):
        for cls in (exp.GT,exp.GTE,exp.LT,exp.LTE):
            for idx,cmp in enumerate(root.find_all(cls)):
                sub=cmp.expression
                if not isinstance(sub,exp.Subquery) or not isinstance(sub.this,exp.Select):
                    continue
                arg=sub.this
                if len(arg.expressions)!=1 or not isinstance(arg.expressions[0],exp.Column) or arg.args.get('limit') or arg.args.get('group'):
                    continue
                new=root.copy()
                inner=list(new.find_all(cls))[idx].expression.this
                word=re.search(r'\b(?:greater|higher|more|less|lower|fewer|smaller|larger)\b[^.?]{0,65}\b(all|every|any)\b',req.text)
                if word:
                    universal=word[1] in ('all','every')
                    fn=exp.Max if (cls in (exp.GT,exp.GTE))==universal else exp.Min
                    inner.set('expressions',[fn(this=inner.expressions[0].copy())])
                    yield 'compare_set',rendered(new)
    # Both literal categories must hold for the same entity, on different detail rows.
    if not re.search(r'\bboth\b',req.text) or not isinstance(root,exp.Select) or len(list(root.find_all(exp.Select)))!=1:
        return
    if any(root.args.get(k) for k in ('order','group','having','limit','offset')):
        return
    where=root.args.get('where')
    if not where:
        return
    atoms=[]
    def walk(node):
        if isinstance(node,(exp.And,exp.Or)):
            walk(node.this);walk(node.expression)
        else:
            atoms.append(node)
    walk(where.this)
    if len(atoms)==1 and isinstance(atoms[0],exp.In):
        pred=atoms[0]
        if len(pred.expressions)==2 and all(isinstance(x,exp.Literal) and req.support(x) for x in pred.expressions):
            atoms=[exp.EQ(this=pred.this.copy(),expression=x.copy()) for x in pred.expressions]
    if (len(atoms)==2 and all(isinstance(a,exp.EQ) and isinstance(a.this,exp.Column) and
            isinstance(a.expression,exp.Literal) and req.support(a.expression) for a in atoms)
        and atoms[0].this==atoms[1].this and atoms[0].expression!=atoms[1].expression):
        sides=[root.copy(),root.copy()]
        for side,atom in zip(sides,atoms):
            side.set('where',exp.Where(this=atom.copy()))
        yield 'intersect_populations',rendered(sides[0].intersect(sides[1]))

def iterative_pool(question,example,original,incumbent,history,patterns,prior_weights):
    entries=expanded_pool(question,example,original,incumbent,history,patterns)
    schema=next((e['observation'] for e in history if e['tool']=='schema'),None)
    if not schema:
        return entries
    req=Requirement(question,example['columns'],schema)
    prior=retrieve(question,schema,patterns)
    ordered=sorted(entries.items(),key=lambda item:-score(item[1],prior_weights))
    beam=[]
    shapes=set()
    for k,e in ordered:
        if not e['features']['derived'] or e['features']['incumbent']:
            continue
        shape=re.sub(r'["`]|\bAS\s+', '',k,flags=re.I).casefold()
        if shape not in shapes:
            beam.append((k,e));shapes.add(shape)
        if len(beam)==3:
            break
    def add(sql,label,parent):
        if not sql or len(sql.encode())>16000:
            return
        k=sql_key(sql)
        if k not in entries:
            f=sql_features(sql,req)
            if not f:
                return
            f.update(incumbent=0,draft=0,hint=0,previous_check=0,derived=1,support=1,
                     public_empty=int(example['row_count']==0))
            entries[k]=dict(sql=sql,features=f,parents=[parent],actions=[label])
            describe(entries[k],req,prior)
        elif label not in entries[k]['actions']:
            entries[k]['actions'].append(label)
    parents=[(sql_key(incumbent),dict(sql=incumbent)),(sql_key(original),dict(sql=original))]+beam
    for parent,e in parents:
        try:
            for label,sql in alternative_sets(e['sql'],req):
                add(sql,label,parent)
        except (SqlglotError,ValueError,RecursionError):
            continue
    for parent,e in beam:
        for sql,label in sketches(e['sql'],req):
            add(sql,'compose_'+label,parent)
        for opt in population(dict(question=question,schema=schema,current_sql=e['sql'])):
            add(opt['sql'],'compose_'+opt['family'],parent)
    for e in entries.values():
        e['features']['composed']=int(any(a.startswith('compose') for a in e['actions']))
        e['features']['explicit_set']=int(any(a in ('compare_set','intersect_populations') for a in e['actions']))
    return entries

class IterativeAgent(ExpandedAgent):
    def begin(self,obs,sql):
        self.incumbent=sql
        self.prefix=None

    def act(self,obs):
        if self.incumbent is None:
            a=self.baseline.act(obs)
            if a['tool']!='submit':
                return a
            self.begin(obs,a['sql'])
        if self.prefix is None:
            action=evidence_action(obs)
            if action:
                return action
            self.prefix=len(obs['history'])
            self.entries=iterative_pool(obs['task']['question'],obs['example'],obs['issue_sql'],self.incumbent,
                obs['history'],self.params['patterns'],self.params['prior_weights'])
        return super().act(obs)
