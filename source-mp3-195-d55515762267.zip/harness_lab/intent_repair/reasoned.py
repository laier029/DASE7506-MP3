"""Require a relationship role or a connecting table; preserve per-entity measure weights."""

import re

from sqlglot import exp

from sqlglot.errors import SqlglotError

from harness_lab.intent_repair.roles import RoleAgent,proposals

from harness_lab.intent_repair.staged import DEST as PRIOR

from harness_lab.intent_repair.semantics import rendered

from harness_lab.intent_repair.reconstruct import sources

from mp3_sql.sqlite_tool import validate_sql

DEST=PRIOR.parent/'reasoned'

def subject_aggregate(sql,req):
    if not re.search(r'\b(who|which|that|with|having)\b',req.text):
        return None
    root=validate_sql(sql)
    if not isinstance(root,exp.Select) or len(list(root.find_all(exp.Select)))!=1 or len(root.expressions)!=1:
        return None
    agg=root.expressions[0].unalias()
    if not isinstance(agg,(exp.Avg,exp.Sum)) or not isinstance(agg.this,exp.Column):
        return None
    if any(root.args.get(k) for k in ('group','order','limit','having','offset','distinct')):
        return None
    joins=root.args.get('joins',[])
    if len(joins)!=1 or joins[0].side or joins[0].kind not in ('','INNER'):
        return None
    scope=sources(root,req)
    measure=req.required(agg.this,scope)
    if not measure or measure[0] not in req.mentioned or not root.args.get('from'):
        return None
    base=root.args['from'].this
    child=joins[0].this
    if not isinstance(base,exp.Table) or not isinstance(child,exp.Table) or base.name.casefold()!=measure[0].casefold():
        return None
    eq=joins[0].args.get('on')
    if not isinstance(eq,exp.EQ) or not all(isinstance(x,exp.Column) for x in (eq.this,eq.expression)):
        return None
    refs={req.required(x,scope) for x in (eq.this,eq.expression)}
    if None in refs or not any({(c['name'],f['from']),(f['table'],f['to'])}==refs for c in req.schema
                               if c['name'].casefold()==child.name.casefold() for f in c['foreign_keys']):
        return None
    if any(not c.table for c in list(eq.find_all(exp.Column))+list(agg.find_all(exp.Column))):
        return None
    sub=exp.select(exp.Literal.number(1)).from_(child.copy()).where(eq.copy())
    if root.args.get('where'):
        condition=root.args['where'].this
        if any(not c.table for c in condition.find_all(exp.Column)):
            return None
        sub=sub.where(condition.copy())
    out=exp.select(root.expressions[0].copy()).from_(base.copy()).where(exp.Exists(this=sub))
    return rendered(out)

def cautious(sql,req,ordered):
    choices=proposals(sql,req,ordered,strict=True)
    try:
        new=subject_aggregate(sql,req)
    except (ValueError,SqlglotError,RecursionError):
        new=None
    if new:
        choices.append((3.5,new,['per-subject measure']))
    return choices

class ReasonedAgent(RoleAgent):
    propose=staticmethod(cautious)
