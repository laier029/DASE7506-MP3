"""Learn cross-schema preferences among concrete edits on fitting questions only."""

def score(entry,w):
    return sum(w.get(k,0)*min(5,v) for k,v in entry['features'].items())

def ordered(pool,base,weights):
    return sorted(((score(e,weights),k,e) for k,e in pool.items() if k!=base),
                  key=lambda item:(-item[0],item[1]))
