"""Locate a bound category predicate and expose its public values within one execute."""
import re
import unicodedata
from collections import defaultdict

from sqlglot import exp
from harness_lab.h41.intent import tokens
from harness_lab.h60.agent import sql_candidate
from harness_lab.h69.binding import _scope, _resolve
from mp3_sql.sqlite_tool import validate_sql


def words(value):
    return re.findall(r'[^\W_]+', unicodedata.normalize('NFKC',value).casefold(), re.UNICODE)


def values_in(sql,schema):
    tree=validate_sql(sql)
    catalog={t['name'].casefold():t for t in schema}
    groups=defaultdict(list)
    for pred in tree.walk():
        if not isinstance(pred,(exp.EQ,exp.NEQ,exp.In)):
            continue
        scope=pred.find_ancestor(exp.Select)
        where=pred.find_ancestor(exp.Where)
        if not scope or not where or where.find_ancestor(exp.Select) is not scope:
            continue
        col, values=pred.this, pred.expressions if isinstance(pred,exp.In) else [pred.expression]
        if isinstance(col,exp.Literal) and len(values)==1 and isinstance(values[0],exp.Column):
            col,values=values[0],[col]
        ref=_resolve(col,_scope(scope,catalog))
        if not ref or not values or not all(isinstance(v,exp.Literal) for v in values):
            continue
        field=ref[2]
        if not re.search(r'CHAR|TEXT|CLOB|STRING|ENUM',field['type'],re.I):
            continue
        for v in values:
            if 0<len(v.this)<=64 and words(v.this) and not any(ord(c)<32 for c in v.this):
                groups[(ref[1]['name'],field['name'])].append(v)
    return tree, groups


def locate(sql,schema,question):
    try:
        _,groups=values_in(sql,schema)
    except (ValueError,RecursionError):
        return None
    q=' '+' '.join(words(question))+' '
    ranks=[]
    for (table,col),nodes in groups.items():
        old=list(dict.fromkeys(n.this for n in nodes))
        if len(old)>2:
            continue
        mentioned=sum(' '+' '.join(words(v))+' ' in q for v in old)
        score=(mentioned>0,len(set(tokens(col))&set(tokens(question))),mentioned)
        ranks.append((score,table,col,old))
    if not ranks:
        return None
    best=max(v[0] for v in ranks)
    tied=[r for r in ranks if r[0]==best]
    if len(tied)!=1:
        return None
    _,tab,col,old=tied[0]
    name=exp.column(col,quoted=True).sql(dialect='sqlite')
    source=exp.to_identifier(tab,quoted=True).sql(dialect='sqlite')
    norm='LOWER(TRIM('+name+'))'
    lits=[exp.Literal.string(s.casefold().strip()).sql(dialect='sqlite') for s in old]
    exact=' OR '.join(norm+'='+v for v in lits)
    contains=' OR '.join('INSTR('+norm+','+v+')>0' for v in lits)
    query=(f'SELECT DISTINCT {name} COLLATE BINARY AS observed_value FROM {source} '
           f"WHERE TYPEOF({name})='text' ORDER BY CASE WHEN {exact} THEN 0 WHEN {contains} THEN 1 ELSE 2 END, "
           f'{name} COLLATE BINARY LIMIT 9')
    return dict(table=tab,field=col,original=old,sql=query)


def observed(feedback):
    return list(dict.fromkeys(row[0] for row in feedback['rows'] if len(row)==1 and isinstance(row[0],str)
        and 0<len(row[0])<=64 and not any(ord(c)<32 for c in row[0]))) if feedback['ok'] else []


def program_values(plan, options):
    out=[]
    for value in plan['original']:
        if value in options:
            out.append(value)
            continue
        w=words(value)
        matches=[v for v in options if words(v)==w]
        if not matches:
            field=set(tokens(plan['field']))
            matches=[v for v in options if len(words(v))>len(w) and
                     any(words(v)[i:i+len(w)]==w for i in range(len(words(v))-len(w)+1)) and
                     (len(w)>=2 or set(words(v))-set(w)<=field)]
        out.append(matches[0] if len(matches)==1 else value)
    return out


def patch(sql,schema,plan,values):
    if values==plan['original']:
        return None
    tree,groups=values_in(sql,schema)
    changes=dict(zip(plan['original'],values,strict=True))
    for node in groups[plan['table'],plan['field']]:
        if changes[node.this]!=node.this:
            node.replace(exp.Literal.string(changes[node.this]))
    try:
        return sql_candidate(tree.sql(dialect='sqlite',comments=False),schema)
    except (ValueError,RecursionError):
        return None
