from pathlib import Path
from harness_lab.h60.agent import checked
from harness_lab.h65.agent import risks
from mp3_sql.common import BUDGET

ROOT = Path(__file__).resolve().parents[2]

def route(question, incumbent, history):
    flags = risks(question, incumbent, checked(history, incumbent))
    return bool(flags) and len(history) < BUDGET, flags
