"""V16 with one risk-gated H65-real proposal and frozen H66 tie acceptance."""
import json
import os
from pathlib import Path

from harness_lab.h60.agent import shared_model
from harness_lab.h65.agent import HybridAgent
from harness_lab.h66.judge import judge
from harness_lab.h67.routing_policy import ROOT, route


ADAPTER = ROOT / "outputs/h65-semantic-repair/train/real/adapter"


class RoutedAgent(HybridAgent):
    def act(self, obs):
        if self.v16_sql is None:
            action = self.program.act(obs)
            if action["tool"] != "submit":
                return action
            self.v16_sql = action["sql"]
            self.v16_calls = len(obs["history"])
            eligible, self.risk_flags = route(obs["task"]["question"], self.v16_sql, obs["history"])
            self.routed = eligible and obs["remaining"] > 0
            if not self.routed:
                return action

        action = super().act(obs)
        if (action["tool"] == "submit" and self.record["status"] == "both_match"
                and self.record["judge"]["choice"] == "abstain"):
            schema = next(e["observation"] for e in obs["history"] if e["tool"] == "schema")
            decision = judge(obs["task"]["question"], schema, self.v16_sql, self.model_sql, obs["ordered"])
            if decision["choice"] == "model":
                return {"tool": "submit", "sql": self.model_sql}
        return action


def create_agent(checkpoint=None):
    path = Path(checkpoint).resolve() if checkpoint else None
    cfg = json.loads(path.read_text()) if path else {}
    adapter = Path(os.environ.get("MP3_ADAPTER_DIR") or cfg.get("adapter", ADAPTER))
    if path and not adapter.is_absolute():
        adapter = path.parent / adapter
    return RoutedAgent(shared_model(str(adapter.resolve())))
