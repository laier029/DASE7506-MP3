"""Compile public-schema diagnoses without accepting SQL text from a selector."""
import math
import re

from sqlglot import exp
from sqlglot.errors import SqlglotError

from harness_lab.h41.intent import by_name, primary, projection, tokens
from harness_lab.h60.agent import sql_candidate
from harness_lab.h69.binding import COMPARISONS, _conjuncts, _resolve, _scope
from mp3_sql.sqlite_tool import validate_sql


OPS = {"=": exp.EQ, "!=": exp.NEQ, ">": exp.GT, ">=": exp.GTE, "<": exp.LT, "<=": exp.LTE}
CONTROL = {"action": "unknown"}


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _qualified(name):
    _require(isinstance(name, str) and name.count(".") == 1, "expected table.column")
    return name.split(".")


def _ref(name, schema):
    owner, field = _qualified(name)
    table = by_name(schema, owner)
    col = by_name(table["columns"], field) if table else None
    _require(col is not None, "unknown public table or column")
    return table["name"], col["name"]


def _column(owner, field):
    return exp.column(field, table=owner, quoted=True)


def _q(name):
    return exp.to_identifier(name, quoted=True).sql(dialect="sqlite")


def _render(node):
    return node.sql(dialect="sqlite", comments=False)


def _value(val):
    _require(type(val) in (str, int, float), "expected string or numerical literal")
    _require(not isinstance(val, str) or len(val) <= 256, "overlong string literal")
    _require(not isinstance(val, float) or math.isfinite(val), "nonfinite number")
    return exp.convert(val)


def _edges(schema):
    """Only declared roles into an entire single-column primary key."""
    edges = []
    for child in schema:
        for fk in child["foreign_keys"]:
            parent = by_name(schema, fk["table"])
            pk = primary(parent) if parent else None
            field = by_name(child["columns"], fk["from"])
            if (pk and field and child is not parent and not fk.get("seq")
                    and (not fk.get("to") or pk["name"].casefold() == fk["to"].casefold())):
                edge = ((child["name"], field["name"]), (parent["name"], pk["name"]))
                if edge not in edges:
                    edges.append(edge)
    return edges


def _base(sql, schema):
    t = validate_sql(sql)
    _require(isinstance(t, exp.Select) and len(list(t.find_all(exp.Select))) == 1
             and t.find(exp.With, exp.Window, exp.SetOperation) is None, "unsupported scope")
    scope = _scope(t, {v["name"].casefold(): v for v in schema})
    _require(scope and len({tbl["name"] for _, tbl in scope.values()}) == len(scope),
             "missing or repeated physical table")
    return t, scope


def _physical(col, scope):
    r = _resolve(col, scope)
    return (r[1]["name"], r[2]["name"]) if r else None


def _add_lookup(tree, scope, ref, schema):
    aliases = {tbl["name"]: table.alias_or_name for table, tbl in scope.values()}
    if ref[0] not in aliases:
        paths = [(c, p) for c, p in _edges(schema) if c[0] in aliases and p[0] == ref[0]]
        _require(len(paths) == 1, "no unique cardinality-preserving lookup")
        c, p = paths[0]
        actual = by_name(schema, p[0])
        used = set(scope)
        a = p[0]
        while a.casefold() in used:
            a = "_" + a
        tab = exp.Table(this=exp.to_identifier(p[0], quoted=True))
        if a != p[0]:
            tab = tab.as_(a, quoted=True)
        eq = exp.EQ(this=_column(aliases[c[0]], c[1]), expression=_column(a, p[1]))
        tree.append("joins", exp.Join(this=tab, side="LEFT", on=eq))
        scope[a.casefold()] = (tab, actual)
        aliases[p[0]] = a
    return _column(aliases[ref[0]], ref[1])


def _edit(d, sql, schema):
    t, scope = _base(sql, schema)
    _require(bool(d.keys() - {"action"}) and not d.keys() - {"action", "project", "filter", "count"},
             "unknown or missing edit operand")
    if "filter" in d:
        f = d["filter"]
        _require(isinstance(f, dict) and {"from", "to"} <= f.keys() <= {"from", "to", "value"},
                 "invalid literal filter")
        target = _ref(f["from"], schema)
        pairs = []
        if t.args.get("where"):
            for n in t.args["where"].walk():
                if isinstance(n, COMPARISONS):
                    for col, lit in ((n.this, n.expression), (n.expression, n.this)):
                        if isinstance(lit, exp.Literal) and _physical(col, scope) == target:
                            pairs.append((col, lit))
        _require(len(pairs) == 1, "filter site absent or ambiguous")
        col, lit = pairs[0]
        col.replace(_add_lookup(t, scope, _ref(f["to"], schema), schema))
        if "value" in f:
            lit.replace(_value(f["value"]))
    if "count" in d:
        counts = list(t.find_all(exp.Count))
        _require(counts and all(_render(c) == _render(counts[0]) for c in counts),
                 "no unambiguous count expression")
        column = _add_lookup(t, scope, _ref(d["count"], schema), schema)
        for cnt in counts:
            if isinstance(cnt.this, exp.Distinct):
                _require(len(cnt.this.expressions) == 1, "multiple distinct count arguments")
                cnt.this.set("expressions", [column.copy()])
            else:
                cnt.set("this", column.copy())
    if "project" in d:
        outputs = d["project"]
        _require(isinstance(outputs, list) and 1 <= len(outputs) <= 12, "invalid projection")
        columns = []
        for name in outputs:
            if name == "#count":
                old = [v for v in t.expressions if isinstance(v.unalias(), exp.Count)]
                _require(len(old) == 1, "no unique count projection")
                columns.append(old[0].copy())
            else:
                columns.append(_add_lookup(t, scope, _ref(name, schema), schema))
        t.set("expressions", columns)
    return _render(t)


def _move_predicate(part, scope, aliases):
    """Translate a qualification only if all columns have the same surviving owner."""
    term = part.copy()
    owners = set()
    for col in list(term.find_all(exp.Column)):
        ref = _physical(col, scope)
        _require(ref and ref[0] in aliases, "predicate depends on an unrepresented table")
        owners.add(ref[0])
        col.replace(_column(aliases[ref[0]], ref[1]))
    _require(len(owners) == 1, "cannot safely relocate predicate")
    return next(iter(owners)), term


def _aggregate(d, sql, schema):
    keys = {"action", "parent", "child", "outputs", "include_zero", "rank"}
    _require(keys <= d.keys() <= keys | {"condition"}, "missing or unknown aggregate operand")
    pk, fk = _ref(d["parent"], schema), _ref(d["child"], schema)
    edges = _edges(schema)
    _require((fk, pk) in edges, "no declared child role into parent key")
    _require(type(d["include_zero"]) is bool and d["rank"] in ("none", "most", "least"), "invalid population or rank")
    outs = d["outputs"]
    _require(isinstance(outs, list) and 1 <= len(outs) <= 12, "invalid aggregate projection")
    t, scope = _base(sql, schema)
    _require(not any(t.args.get(k) for k in ("having", "qualify", "offset")), "unsupported aggregate restrictions")
    parts = list(_conjuncts(t.args["where"].this)) if t.args.get("where") else []
    for j in t.args.get("joins", []):
        _require(j.kind in ("", "INNER") and j.side in ("", "LEFT") and not j.method
                 and j.args.get("on") is not None, "unsupported original join condition")
        found_edge = False
        for part in _conjuncts(j.args["on"]):
            if isinstance(part, exp.EQ):
                left, right = _physical(part.this, scope), _physical(part.expression, scope)
                if (left, right) in edges or (right, left) in edges:
                    found_edge = True
                    continue
            owner, _ = _move_predicate(part, scope, {pk[0]: "p", fk[0]: "c"})
            _require(j.side != "LEFT" or owner == fk[0] == by_name(schema, j.this.name)["name"],
                     "cannot preserve outer-join ON semantics")
            parts.append(part)
        _require(found_edge, "cannot discard unverified join predicate")
    # Only a single-table restriction can be moved independently of join multiplicity.
    preds = {pk[0]: [], fk[0]: []}
    alias = {pk[0]: "p", fk[0]: "c"}
    for part in parts:
        if any(isinstance(n, exp.Is) and isinstance(n.expression, exp.Null) for n in part.walk()):
            raise ValueError("nullable-side membership requires a separate interpretation")
        owner, term = _move_predicate(part, scope, alias)
        preds[owner].append(_render(term))
    if "condition" in d:
        f = d["condition"]
        _require(isinstance(f, dict) and set(f) == {"field", "op", "value"} and f["op"] in OPS,
                 "invalid aggregate condition")
        tab, col = _ref(f["field"], schema)
        _require(tab in alias, "condition outside aggregate population")
        term = OPS[f["op"]](this=_column(alias[tab], col), expression=_value(f["value"]))
        if _render(term) not in preds[tab]:
            preds[tab].append(_render(term))

    def where(items):
        return " WHERE " + " AND ".join("(" + p + ")" for p in items) if items else ""

    group_key = _render(_column("c", fk[1]))
    inner = (f"SELECT {group_key} AS entity_id, COUNT(*) AS n FROM {_q(fk[0])} AS c"
             f"{where(preds[fk[0]])} GROUP BY {group_key}")
    measure = "COALESCE(g.n, 0)" if d["include_zero"] else "g.n"
    selected = []
    for out in outs:
        if out == "#count":
            selected.append(measure)
        else:
            tab, col = _ref(out, schema)
            _require(tab == pk[0], "aggregate outputs must be parent attributes or #count")
            selected.append(_render(_column("p", col)))
    join = "LEFT JOIN" if d["include_zero"] else "JOIN"
    outer = (f"SELECT {', '.join(selected)} FROM {_q(pk[0])} AS p {join} ({inner}) AS g "
             f"ON g.entity_id = {_render(_column('p',pk[1]))}{where(preds[pk[0]])}")
    if d["rank"] != "none":
        order = "DESC" if d["rank"] == "most" else "ASC"
        outer += f" ORDER BY {measure} {order} LIMIT 1"
    return outer


def compile_diagnosis(diagnosis, schema, incumbent):
    """Return (bound, read-only query or None, reason); input contains no SQL fragments."""
    try:
        _require(isinstance(diagnosis, dict), "invalid diagnosis")
        action = diagnosis.get("action")
        if action in ("keep", "unknown"):
            _require(set(diagnosis) == {"action"}, "unexpected operand")
            return None, action
        _require(action in ("edit", "aggregate"), "unsupported action")
        sql = (_edit if action == "edit" else _aggregate)(diagnosis, incumbent, schema)
        sql_candidate(sql, schema)
        return sql, "compiled"
    except (ValueError, KeyError, TypeError, SqlglotError, RecursionError) as exc:
        return None, str(exc)


def _mentions(question_terms, name):
    phrase = tokens(name)
    return bool(phrase and any(question_terms[i:i + len(phrase)] == phrase
                               for i in range(len(question_terms) - len(phrase) + 1)))


def program_diagnosis(question, schema, incumbent):
    """Supply a conservative public-only diagnosis; selection never inspects grade data."""
    try:
        tree, scope = _base(incumbent, schema)
        qt = tokens(question)
        rank = re.search(r"\b(most|fewest|largest number of|smallest number of|highest number of)\b",
                         question, re.I)
        zero = re.search(r"\b(including|even if|even when|whether or not)\b.*\b(no|zero|none|any)\b", question, re.I)
        counts = [e for e in tree.expressions if isinstance(e.unalias(), exp.Count)]
        if counts and (rank or zero):
            found = []
            for child, parent in _edges(schema):
                if not (_mentions(qt, child[0]) and _mentions(qt, parent[0])):
                    continue
                outs = []
                for e in tree.expressions:
                    r = _physical(e.unalias(), scope)
                    if isinstance(e.unalias(), exp.Count):
                        outs.append("#count")
                    elif r and r[0] == parent[0]:
                        outs.append(".".join(r))
                    elif r == child:
                        outs.append(".".join(parent))
                    else:
                        break
                if len(outs) != len(tree.expressions):
                    continue
                how = "none" if not rank else ("least" if rank[1].lower() in ("fewest", "smallest number of") else "most")
                found.append({"action": "aggregate", "parent": ".".join(parent), "child": ".".join(child),
                              "include_zero": bool(zero), "rank": how, "outputs": outs})
            if len(found) == 1:
                return found[0]

        # An explicitly named schema field and quoted value jointly locate a direct
        # literal comparison. Multiple candidate slots or homonymous fields abstain.
        quoted = set(re.findall(r"""['"]([^'"]{1,80})['"]""", question))
        if len(quoted) == 1 and tree.args.get("where"):
            literal = next(iter(quoted))
            attrs = [(t["name"], c["name"]) for _, t in scope.values() for c in t["columns"]
                     if _mentions(qt, c["name"]) and not c.get("pk")]
            atoms = [n for n in tree.args["where"].walk() if isinstance(n, exp.EQ)
                     and isinstance(n.this, exp.Column) and isinstance(n.expression, exp.Literal)
                     and n.expression.is_string and _physical(n.this, scope)]
            if len(attrs) == len(atoms) == 1:
                current = _physical(atoms[0].this, scope)
                if attrs[0] != current or literal != atoms[0].expression.this:
                    return {"action": "edit", "filter": {"from": ".".join(current), "to": ".".join(attrs[0]),
                                                          "value": literal}}

        # A single, explicit output request can identify an unambiguous field name.
        m = re.fullmatch(r"(?:list|show|return|give)(?: me)? (?:the |all )?([a-z_ ]{1,64}?) "
                         r"(?:of|for) (?:all |the )?([a-z_ ]{1,50})[.?]?", question.strip(), re.I)
        if m and not (tree.args.get("group") or any(e.find(exp.AggFunc) for e in tree.expressions)):
            tables = [tab for tab in schema if tokens(tab["name"]) == tokens(m[2])]
            if len(tables) == 1:
                col = projection(tables[0], m[1].strip())
                if col:
                    return {"action": "edit", "project": [tables[0]["name"] + "." + col["name"]]}
        return CONTROL.copy()
    except (ValueError, KeyError, TypeError, SqlglotError, RecursionError):
        return CONTROL.copy()
