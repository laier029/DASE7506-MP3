"""Isolated Qwen decoding experiment; reuse the frozen CPU model loader."""

import math
import time

from agent_v2.runtime import LocalGenerator as FrozenLocalGenerator, _GENERATION_LOCK


def extract_answer(token_ids, tokenizer, enable_thinking):
    """Split by the closing token, never by text that happens to resemble a tag.

    Token counts partition all generated tokens. Thinking includes its closing
    marker; answer tokens include any terminal EOS token. Raw text retains all
    special tokens for audit, while text contains only the decoded final answer.
    """
    token_ids = list(token_ids)
    boundary = 0
    closed = True
    if enable_thinking:
        closing_id = tokenizer.convert_tokens_to_ids("</think>")
        if (type(closing_id) is not int or closing_id < 0
                or closing_id == tokenizer.unk_token_id):
            raise ValueError("Tokenizer does not define the </think> token")
        try:
            boundary = token_ids.index(closing_id) + 1
        except ValueError:
            boundary, closed = len(token_ids), False
    text = tokenizer.decode(token_ids[boundary:], skip_special_tokens=True).strip() if closed else ""
    return {
        "text": text,
        "generated_text": tokenizer.decode(token_ids, skip_special_tokens=False),
        "final_available": closed and bool(text),
        "thinking_tokens": boundary,
        "answer_tokens": len(token_ids) - boundary,
    }


class LocalGenerator(FrozenLocalGenerator):
    """Greedy baseline or seeded sampling, with one shared generation lock."""

    def __init__(self, config):
        super().__init__(config)
        self.enable_thinking = config.get("enable_thinking", False)
        self.do_sample = config.get("do_sample", False)
        self.temperature = config.get("temperature", 0.6)
        self.top_p = config.get("top_p", 0.95)
        self.top_k = config.get("top_k", 20)
        self.seed = config.get("seed", 42)
        for name in ("enable_thinking", "do_sample"):
            if type(getattr(self, name)) is not bool:
                raise ValueError(f"{name} must be boolean")
        if self.enable_thinking and not self.do_sample:
            raise ValueError("The thinking experiment requires do_sample=True")
        for name in ("temperature", "top_p"):
            value = getattr(self, name)
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if self.top_p > 1:
            raise ValueError("top_p must be at most 1")
        if type(self.top_k) is not int or self.top_k < 0:
            raise ValueError("top_k must be a nonnegative integer")
        if type(self.seed) is not int or not 0 <= self.seed < 2**63:
            raise ValueError("seed must be an integer from 0 to 2**63 - 1")

    def generate(self, messages, max_new_tokens):
        if type(max_new_tokens) is not int or not 1 <= max_new_tokens <= 2048:
            raise ValueError("max_new_tokens must be an integer from 1 to 2048, including thinking")
        if not isinstance(messages, list) or not messages:
            raise ValueError("messages must be a nonempty list")
        if any(not isinstance(message, dict)
               or set(message) != {"role", "content"}
               or message["role"] not in {"system", "user", "assistant"}
               or not isinstance(message["content"], str)
               for message in messages):
            raise ValueError("messages must contain only role and string content")

        parameters = {
            "enable_thinking": self.enable_thinking,
            "do_sample": self.do_sample,
            "temperature": self.temperature if self.do_sample else None,
            "top_p": self.top_p if self.do_sample else None,
            "top_k": self.top_k if self.do_sample else None,
            "seed": self.seed,
            "max_new_tokens": max_new_tokens,
        }
        started = time.perf_counter()
        with _GENERATION_LOCK:
            torch, tokenizer, model, parameter_count = self._load()
            prompt = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True,
                enable_thinking=self.enable_thinking,
            )
            inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
            prompt_tokens = int(inputs["input_ids"].shape[-1])
            if prompt_tokens > self.max_input_tokens:
                raise ValueError(
                    f"Prompt has {prompt_tokens} tokens; cap is {self.max_input_tokens}. "
                    "Refusing to silently truncate task evidence."
                )
            if prompt_tokens + max_new_tokens > model.config.max_position_embeddings:
                raise ValueError("Prompt plus requested generation exceeds model context")
            pad_token_id = tokenizer.pad_token_id
            if pad_token_id is None:
                pad_token_id = tokenizer.eos_token_id
            # The model is CPU-only. Seed only its CPU generator and restore that
            # RNG even when generation fails; do not change unrelated device RNGs.
            with torch.random.fork_rng(devices=[]), torch.inference_mode():
                torch.random.default_generator.manual_seed(self.seed)
                output = model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=self.do_sample,
                    temperature=parameters["temperature"],
                    top_p=parameters["top_p"],
                    top_k=parameters["top_k"],
                    pad_token_id=pad_token_id,
                    use_cache=True,
                )
            generated = output[0, prompt_tokens:].tolist()
            new_tokens = len(generated)
            eos = model.generation_config.eos_token_id
            eos_ids = set(eos if isinstance(eos, list) else [eos])
            stopped_on_eos = bool(new_tokens and generated[-1] in eos_ids)
            answer = extract_answer(generated, tokenizer, self.enable_thinking)

        return {
            **answer,
            "prompt_tokens": prompt_tokens,
            "new_tokens": new_tokens,
            "seconds": time.perf_counter() - started,
            "truncated": new_tokens >= max_new_tokens and not stopped_on_eos,
            "generation_parameters": parameters,
            "model": {
                "repository": self.repository,
                "revision": self.revision,
                "actual_parameters": parameter_count,
                "device": "cpu",
                "dtype": "float32",
                "threads": self.threads,
                "enable_thinking": self.enable_thinking,
            },
        }
