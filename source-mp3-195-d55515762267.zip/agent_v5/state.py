"""Episode evidence and candidate lineage, without a semantic truth oracle.

Canonical SQL is used only for proposal deduplication. Tool feedback is always
indexed by the exact submitted string. A public match is an observation about
one database, not a promotion of a proposal's assumptions into facts.
"""

from collections import Counter
from copy import deepcopy
from dataclasses import asdict, dataclass, field, replace
import hashlib
import json

from agent_v2.submission import canonical
from mp3_sql.common import BUDGET, MAX_SQL_BYTES


def _copy(value):
    json.dumps(value, ensure_ascii=False, allow_nan=False)
    return deepcopy(value)


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _merge(first, second):
    result = _copy(first)
    for value in second:
        if value not in result:
            result.append(_copy(value))
    return result


@dataclass(frozen=True)
class Candidate:
    id: str
    sql: str
    canonical_sql: str
    sources: list[str] = field(default_factory=list)
    parent_id: str | None = None
    operator: str | None = None
    evidence: list = field(default_factory=list)
    assumptions: list = field(default_factory=list)
    status: str = "unchecked"


class EpisodeState:
    """One task's append-only official history and separately stored proposals.

Public properties return defensive copies. Candidate IDs represent canonical
queries; their first derivation is retained when another source suggests the same
query. If an unchecked representative has a checked spelling variant, the exact
checked string becomes its representative. An already checked representative is
never silently replaced by feedback for a different string.
"""

    def __init__(self):
        self._original = None
        self._schema = []
        self._history = []
        self._remaining = BUDGET
        self._checks = {}
        self._candidates = {}
        self._incumbent_id = None
        self._incumbent_reason = None

    @property
    def task(self):
        return _copy(self._original["task"]) if self._original is not None else None

    @property
    def issue_sql(self):
        return self._original["issue_sql"] if self._original is not None else None

    @property
    def example(self):
        return _copy(self._original["example"]) if self._original is not None else None

    @property
    def ordered(self):
        return self._original["ordered"] if self._original is not None else None

    @property
    def schema(self):
        return _copy(self._schema)

    @property
    def history(self):
        return _copy(self._history)

    @property
    def remaining(self):
        return self._remaining

    @property
    def checks(self):
        return _copy(self._checks)

    @property
    def candidates(self):
        return deepcopy(self._candidates)

    @property
    def incumbent_id(self):
        return self._incumbent_id

    @property
    def incumbent_reason(self):
        return self._incumbent_reason

    @property
    def incumbent(self):
        return deepcopy(self._candidates[self._incumbent_id]) if self._incumbent_id else None

    @staticmethod
    def _status(check):
        if check is None:
            return "unchecked"
        result = check["observation"]
        if result["ok"] is False:
            return "execution_failed"
        return "public_match" if result["matches_example"] is True else "public_mismatch"

    def add_candidate(self, sql, source, parent_id=None, operator=None,
                      evidence=(), assumptions=()):
        if not isinstance(sql, str) or len(sql.encode()) > MAX_SQL_BYTES:
            raise ValueError("Candidate SQL must obey the official string limit")
        if not isinstance(source, str) or not source:
            raise ValueError("A candidate needs a nonempty source label")
        if parent_id is not None and parent_id not in self._candidates:
            raise ValueError("Candidate parent does not exist")
        if operator is not None and (not isinstance(operator, str) or not operator):
            raise ValueError("Operator must be a nonempty label or None")
        if not isinstance(evidence, (list, tuple)) or not isinstance(assumptions, (list, tuple)):
            raise ValueError("Evidence and assumptions must be lists or tuples")
        evidence, assumptions = _copy(list(evidence)), _copy(list(assumptions))
        key = canonical(sql)
        identity = "sql_" + hashlib.sha256(key.encode()).hexdigest()
        existing = self._candidates.get(identity)
        if existing is not None:
            if existing.canonical_sql != key:
                raise ValueError("Candidate identity collision")
            record = replace(existing, sources=_merge(existing.sources, [source]),
                             evidence=_merge(existing.evidence, evidence),
                             assumptions=_merge(existing.assumptions, assumptions))
        else:
            record = Candidate(identity, sql, key, [source], parent_id, operator,
                               evidence, assumptions, self._status(self._checks.get(sql)))
        self._candidates[identity] = record
        return deepcopy(record)

    @staticmethod
    def _validate_observation(observation):
        keys = {"task", "issue_sql", "example", "ordered", "remaining", "history"}
        if not isinstance(observation, dict) or set(observation) != keys:
            raise ValueError("Expected the official Observation fields")
        original = {key: observation[key] for key in ("task", "issue_sql", "example", "ordered")}
        task = original["task"]
        if (not isinstance(task, dict) or set(task) != {"id", "question"}
                or any(not isinstance(task[key], str) for key in task)
                or not isinstance(original["issue_sql"], str)
                or len(original["issue_sql"].encode()) > MAX_SQL_BYTES
                or not isinstance(original["example"], dict)
                or type(original["ordered"]) is not bool):
            raise ValueError("Malformed immutable task facts")
        history, remaining = observation["history"], observation["remaining"]
        if not isinstance(history, list) or type(remaining) is not int:
            raise ValueError("History and remaining budget have invalid types")
        fields = {"schema": {"tool"}, "repair_hint": {"tool"},
                  "check": {"tool", "sql"}, "execute": {"tool", "sql"},
                  "retrieve": {"tool", "query"}, "submit": {"tool", "sql"}}
        charged, used, original_executed = 0, set(), False
        for index, event in enumerate(history):
            if not isinstance(event, dict) or event.get("tool") not in fields:
                raise ValueError("Unknown history event")
            tool = event["tool"]
            expected = fields[tool] | ({"observation"} if tool != "submit" else set())
            if set(event) != expected:
                raise ValueError("Malformed history event fields")
            if tool in ("check", "execute", "submit"):
                if not isinstance(event["sql"], str) or len(event["sql"].encode()) > MAX_SQL_BYTES:
                    raise ValueError("History SQL violates the official string limit")
            if tool == "submit":
                if index != len(history) - 1:
                    raise ValueError("History continues after submission")
                continue
            action = {key: event[key] for key in fields[tool]}
            action_id = _digest(action)
            if action_id in used:
                raise ValueError("Repeated identical charged action")
            used.add(action_id)
            charged += 1
            feedback = event["observation"]
            if tool in ("schema", "retrieve", "repair_hint") and not isinstance(feedback, list):
                raise ValueError("Expected an official list observation")
            if tool == "retrieve" and (not isinstance(event["query"], str) or len(event["query"]) > 2000):
                raise ValueError("Invalid retrieve query")
            if tool == "repair_hint":
                if not original_executed or any(not isinstance(sql, str) or len(sql.encode()) > MAX_SQL_BYTES
                                                for sql in feedback):
                    raise ValueError("Hint requires prior exact original feedback and SQL strings")
            if tool in ("check", "execute"):
                if not isinstance(feedback, dict) or type(feedback.get("ok")) is not bool:
                    raise ValueError("Malformed execution feedback")
                if tool == "check" and type(feedback.get("matches_example")) is not bool:
                    raise ValueError("Check requires an explicit public-match observation")
                if event["sql"] == original["issue_sql"]:
                    original_executed = True
        if not 0 <= remaining <= BUDGET or remaining != BUDGET - charged:
            raise ValueError("Remaining budget differs from the charged history")
        return _copy(original), _copy(history)

    def sync(self, observation):
        original, history = self._validate_observation(observation)
        if self._original is not None and original != self._original:
            raise ValueError("Immutable task facts changed or a different task was supplied")
        if len(history) < len(self._history) or history[:len(self._history)] != self._history:
            raise ValueError("Official history must only append")
        if self._history and self._history[-1]["tool"] == "submit" and history != self._history:
            raise ValueError("Cannot resume a submitted episode")
        if self._original is None:
            self._original = original
            self.add_candidate(self.issue_sql, "original")
        for event in history[len(self._history):]:
            if event["tool"] == "schema":
                self._schema = _copy(event["observation"])
            elif event["tool"] == "repair_hint":
                for sql in event["observation"]:
                    self.add_candidate(sql, "hint")
            elif event["tool"] == "check":
                sql = event["sql"]
                self._checks[sql] = _copy(event)
                candidate = self.add_candidate(sql, "checked")
                if candidate.sql not in self._checks:
                    candidate = replace(candidate, sql=sql)
                self._candidates[candidate.id] = replace(
                    candidate, status=self._status(self._checks.get(candidate.sql)))
        self._history = history
        self._remaining = observation["remaining"]
        return self

    def set_incumbent(self, candidate_id, reason):
        candidate = self._candidates.get(candidate_id)
        if candidate is None or candidate.sql not in self._checks:
            raise ValueError("The exact incumbent SQL must have an actual prior check")
        if not isinstance(reason, str) or not reason:
            raise ValueError("Record why this candidate is the current incumbent")
        self._incumbent_id, self._incumbent_reason = candidate_id, reason
        return deepcopy(candidate)

    def snapshot(self):
        """Compact audit; the actual official trace remains available in history."""
        checks = []
        for sql, event in self._checks.items():
            result = event["observation"]
            checks.append({"sql": sql, "ok": result["ok"],
                           "matches_example": result["matches_example"],
                           "column_count": len(result.get("columns", [])),
                           "row_count": result.get("row_count"),
                           "truncated": result.get("truncated"), "error": result.get("error")})
        return _copy({
            "facts": {"task": self.task, "issue_sql": self.issue_sql,
                      "example": self.example, "ordered": self.ordered,
                      "schema_tables": len(self._schema), "schema_sha256": _digest(self._schema),
                      "history_length": len(self._history), "history_sha256": _digest(self._history),
                      "tool_counts": dict(Counter(event["tool"] for event in self._history)),
                      "remaining": self.remaining, "exact_checks": checks},
            "candidates": [asdict(candidate) for candidate in self._candidates.values()],
            "incumbent": {"id": self.incumbent_id, "reason": self.incumbent_reason},
            "interpretation": "Candidate evidence and assumptions remain hypotheses; public_match is not semantic proof.",
        })
