"""Pure, bounded edits of one global aggregate over an already bound field.

The SQL editor never decides that an operation answers a question. The optional
lexical requirement function is a conservative program baseline and returns a
semantic hypothesis, not a verified interpretation. No public example or grading
reference is read here.
"""

from dataclasses import dataclass
import re

from sqlglot import exp

from agent_v2.submission import parse_query
from harness_lab.h05.editor import _physical_sources, UnsupportedEdit


@dataclass(frozen=True)
class AggregateOption:
    name: str
    sql: str
    description: str
    target_sql: str
    current_operation: str
    preconditions: tuple[str, ...]
    field_sql: str | None = None
    binding: tuple[str, str] | None = None


def _bind(column, sources):
    if column.is_star or column.db or column.catalog:
        raise UnsupportedEdit("A single physical field is required")
    matches = [(table, item) for alias, table in sources
               for item in table["columns"]
               if item["name"].casefold() == column.name.casefold()
               and (not column.table or alias.casefold() == column.table.casefold())]
    if len(matches) != 1:
        raise UnsupportedEdit("Unknown or ambiguous field binding")
    return matches[0]


def _numeric(dtype):
    value = str(dtype or "").upper()
    return ("INT" in value or any(part in value for part in ("REAL", "FLOA", "DOUB"))
            or re.match(r"^(?:NUMERIC|DECIMAL|NUMBER)\b", value) is not None)


def _inspect(sql, schema):
    tree = parse_query(sql)
    if (not isinstance(tree, exp.Select) or len(tree.expressions) != 1
            or len(list(tree.find_all(exp.Select))) != 1
            or any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))
            or any(tree.args.get(key) for key in (
                "group", "having", "distinct", "order", "limit", "offset",
                "qualify", "windows", "laterals", "operation_modifiers"))):
        raise UnsupportedEdit("Expected an ungrouped single-output SELECT without nesting or row limits")
    if not isinstance(schema, list):
        raise UnsupportedEdit("Expected the official table schema list")
    if any(join.args.get("using") or str(join.args.get("method", "")).upper() == "NATURAL"
           for join in tree.args.get("joins", [])):
        raise UnsupportedEdit("Only joins with explicit field references are supported")
    for table in schema:
        if len({c["name"].casefold() for c in table["columns"]}) != len(table["columns"]):
            raise UnsupportedEdit("Ambiguous schema columns")
    sources = _physical_sources(tree, schema)
    for column in tree.find_all(exp.Column):
        _bind(column, sources)
    projection = tree.expressions[0]
    raw = projection.this if isinstance(projection, exp.Alias) else projection
    field = None
    if isinstance(raw, exp.Column):
        operation, field = "DETAIL", raw
    elif isinstance(raw, (exp.Avg, exp.Sum, exp.Count)):
        if raw.args.get("expressions") or len(list(tree.find_all(exp.AggFunc))) != 1:
            raise UnsupportedEdit("Expected exactly one simple aggregate")
        if isinstance(raw.this, exp.Column):
            field = raw.this
            operation = {exp.Avg: "AVG", exp.Sum: "SUM", exp.Count: "COUNT_VALUES"}[type(raw)]
        elif isinstance(raw, exp.Count) and isinstance(raw.this, exp.Star):
            operation = "COUNT_ROWS"
        else:
            raise UnsupportedEdit("The aggregate must contain a physical field, or COUNT(*)")
    else:
        raise UnsupportedEdit("Expressions, DISTINCT aggregates and detail stars are not supported")
    if isinstance(raw, exp.Column) and next(tree.find_all(exp.AggFunc), None) is not None:
        raise UnsupportedEdit("An aggregate outside the selected field is unsupported")
    metadata = _bind(field, sources) if field is not None else None
    return tree, projection, raw, field, operation, sources, metadata


def current_operation(sql, schema) -> str | None:
    """Return the supported current operation, or None without guessing."""
    try:
        return _inspect(sql, schema)[4]
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return None


def build_aggregate_options(sql, schema) -> list[AggregateOption]:
    """Keep sources/joins/filters/field fixed; change only one output operation.

KEEP retains the exact input string. The current operation is not duplicated as
another option. COUNT(*) has no bound field from which to infer AVG or SUM, so it
has only KEEP. Unsupported input returns an empty list.
"""
    try:
        tree, projection, raw, field, operation, _, metadata = _inspect(sql, schema)
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return []
    target = raw.sql(dialect="sqlite")
    field_sql = field.sql(dialect="sqlite") if field is not None else None
    binding = (metadata[0]["name"], metadata[1]["name"]) if metadata else None
    preconditions = ("one output expression", "no grouping, ordering, limits or nested scopes",
                     "all fields bound to the supplied physical schema",
                     "sources, joins and WHERE preserved; join multiplicity is not repaired")
    if field is not None:
        preconditions += ("the selected field's semantic identity remains an assumption",)
    options = [AggregateOption("KEEP", sql, "Keep the current query and output operation unchanged.",
                               target, operation, preconditions, field_sql, binding)]
    if field is None:
        return options
    descriptions = {
        "AVG": "Return one average of this field over matching rows; ignore NULL values.",
        "SUM": "Return one sum of this field over matching rows; ignore NULL values.",
        "COUNT_ROWS": "Return one count of matching rows, including rows with a NULL selected field.",
        "COUNT_VALUES": "Return one count of non-NULL values of this field; duplicates still count.",
    }
    allowed = (["AVG", "SUM"] if _numeric(metadata[1].get("type")) else [])
    allowed += ["COUNT_ROWS", "COUNT_VALUES"]
    for name in allowed:
        if name == operation:
            continue
        changed = tree.copy()
        body = (exp.Count(this=exp.Star()) if name == "COUNT_ROWS" else
                {"AVG": exp.Avg, "SUM": exp.Sum, "COUNT_VALUES": exp.Count}[name](this=field.copy()))
        replacement = (exp.Alias(this=body, alias=projection.args["alias"].copy())
                       if isinstance(projection, exp.Alias) else body)
        changed.set("expressions", [replacement])
        options.append(AggregateOption(name, changed.sql(dialect="sqlite"), descriptions[name],
                                       target, operation, preconditions, field_sql, binding))
    return options


def _words(value):
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", value)
    return re.findall(r"[a-z]+", value.lower().replace("_", " "))


def _singular(word):
    if len(word) > 3 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 3 and word.endswith("s") and not word.endswith(("ss", "us", "is")):
        return word[:-1]
    return word


def _mask_quotes(question):
    # Preserve offsets so each evidence span remains literal original text.
    return re.sub(r"'[^']*'|\"[^\"]*\"|‘[^’]*’|“[^”]*”",
                  lambda match: " " * len(match.group()), question)


def _requirement(operation=None, evidence=(), ambiguity=(), assumptions=()):
    return {"operation": operation, "evidence": list(evidence), "ambiguity": list(ambiguity),
            "assumptions": list(assumptions),
            "status": "semantic_hypothesis" if operation is not None else "unresolved"}


def infer_requirement(question, sql, schema) -> dict:
    """Propose a plainly requested global operation using conservative text cues.

This deliberately does not interpret arbitrary natural language, infer missing
thresholds, choose a new field or use public column labels. A returned operation
remains a hypothesis. GROUP/quantifier requests and aggregate words appearing in
filter comparisons are rejected instead of coerced into a scalar global query.
"""
    if not isinstance(question, str) or not question.strip():
        return _requirement(ambiguity=("missing_question",))
    try:
        _, _, _, field, current, sources, metadata = _inspect(sql, schema)
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return _requirement(ambiguity=("unsupported_sql_shape_or_binding",))
    text = _mask_quotes(question)
    # A global output edit cannot satisfy explicitly grouped, distinct or nested
    # aggregate requirements, even if a scalar result happens to match a sample.
    grouped = re.search(r"\b(?:each|per|every|by)\b", text, re.I)
    if grouped:
        return _requirement(ambiguity=("global_grain_not_established",), evidence=(question[grouped.start():grouped.end()],))
    boundary = re.search(r"\b(?:where|whose|with|having|that|who|when)\b", text, re.I)
    output = text[:boundary.start()] if boundary else text
    average = list(re.finditer(r"\b(?:average|mean)\b", output, re.I))
    counts = list(re.finditer(r"\b(?:how\s+many|number\s+of|count)\b(?:\s+(?:of|the|all)\b)?", output, re.I))
    sums = [m for m in re.finditer(r"\b(?:sum|total)\b", output, re.I)
            if not re.match(r"\s+(?:number|count)\b", output[m.end():], re.I)]
    kinds = [("AVG", average), ("SUM", sums), ("COUNT", counts)]
    present = [(name, matches) for name, matches in kinds if matches]
    if not present:
        return _requirement(ambiguity=("no_explicit_output_aggregate",))
    if len(present) != 1:
        return _requirement(ambiguity=("multiple_aggregate_interpretations",),
                            evidence=tuple(question[m.start():m.end()] for _, ms in present for m in ms))
    name, matches = present[0]
    cue = matches[0]
    evidence = [question[cue.start():cue.end()]]
    if re.search(r"\b(?:above|below|than|greater|higher|lower|less|more|fewer|at\s+least|at\s+most)\b", output[:cue.start()], re.I):
        return _requirement(ambiguity=("aggregate_cue_may_describe_a_filter",), evidence=evidence)
    if re.search(r"\b(?:distinct|different|unique)\b", output, re.I):
        return _requirement(ambiguity=("distinct_aggregate_not_supported",), evidence=evidence)
    if name in ("AVG", "SUM"):
        if field is None or not _numeric(metadata[1].get("type")):
            return _requirement(ambiguity=("no_existing_numeric_measure",), evidence=evidence)
        return _requirement(name, evidence, assumptions=(
            "the existing selected numeric field represents the requested measure",
            "the request describes a global rather than implicit per-entity aggregate"))
    if len(sources) != 1:
        return _requirement(ambiguity=("join_multiplicity_makes_count_ambiguous",), evidence=evidence)
    explicit_non_null = re.search(r"\b(?:non[ -]?null|not\s+null)\b", output, re.I)
    if explicit_non_null:
        if field is None:
            return _requirement(ambiguity=("non_null_count_has_no_bound_field",), evidence=evidence)
        target_words = [_singular(w) for w in _words(metadata[1]["name"])]
        following_words = [_singular(w) for w in _words(output[explicit_non_null.end():])]
        if not target_words or following_words[:len(target_words)] != target_words:
            return _requirement(ambiguity=("non_null_count_target_not_established",), evidence=evidence)
        evidence.append(question[explicit_non_null.start():explicit_non_null.end()])
        return _requirement("COUNT_VALUES", evidence,
                            assumptions=("the explicitly named selected field is the non-NULL counting target",))
    if re.search(r"\b(?:missing|known|available|recorded|present|filled|nonempty|non-empty)\b", output, re.I):
        return _requirement(ambiguity=("possible_non_null_count_requires_explicit_evidence",), evidence=evidence)
    subject = output[cue.end():]
    # Mention of the source somewhere else in the question is insufficient.
    # The immediately requested count subject must name its rows/entities.
    subject = re.split(r"\b(?:of|in|from|for|on|at)\b", subject, maxsplit=1, flags=re.I)[0]
    if re.search(r"\b(?:and|or)\b", subject, re.I):
        return _requirement(ambiguity=("multiple_count_entities",), evidence=evidence)
    subject = re.split(r"\b(?:are|is|were|was|exist|exists)\b", subject, maxsplit=1, flags=re.I)[0]
    subject_words = {_singular(w) for w in _words(subject)} - {"the", "a", "an", "all", "total"}
    table_words = {_singular(w) for w in _words(sources[0][1]["name"])}
    if (not subject_words or not (subject_words <= {"row", "record"}
                                  or table_words and table_words == subject_words)):
        return _requirement(ambiguity=("counted_entity_not_bound_to_single_table_rows",), evidence=evidence)
    return _requirement("COUNT_ROWS", evidence,
                        assumptions=("one physical source row represents the explicitly counted entity",))


def has_explicit_conflict(question, sql, schema) -> bool:
    """A program hypothesis conflicts with the supported current operation.

This is a narrowly supported trigger for checking a challenge, never permission
to submit an unchecked change or proof that the interpretation is correct.
"""
    requirement = infer_requirement(question, sql, schema)
    current = current_operation(sql, schema)
    return requirement["operation"] is not None and current is not None and requirement["operation"] != current
