"""A single evidence state and budget, followed by bounded semantic actions."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agent_v2.submission import canonical
from agent_v3.evidence import grounding_issues
from agent_v4.submission import SqlRepairAgent as V4Agent, load_config as v4_config
from agent_v5.aggregate import (build_aggregate_options, current_operation,
                                infer_requirement, has_explicit_conflict)
from agent_v5.context import build_messages, parse_choice
from agent_v5.state import EpisodeState
from harness_lab.h04.runtime import LocalGenerator
from mp3_sql.common import digest
from mp3_sql.predict import load_factory


DEFAULT_CONFIG = {
    "selector": "off", "base_policy": "champion", "use_model": False,
    "model_repository": "Qwen/Qwen3-0.6B",
    "model_revision": "c1899de289a04d12100db370d81485cdf75e47ca",
    "threads": 4, "max_input_tokens": 12000, "max_model_calls": 6,
    "max_new_tokens": 128, "log_dir": "outputs/agent-v5-model-logs",
    "enable_thinking": False, "do_sample": True, "temperature": 0.6,
    "top_p": 0.95, "top_k": 20, "seed": 42,
}
BASE_CONFIG_SHA256 = "7730cac32ddafd77c1049068b8e5fdd957a59bd331e1443c5dc87aebc79d169c"


def load_config(checkpoint=None):
    config = dict(DEFAULT_CONFIG)
    if checkpoint is not None:
        value = json.loads(Path(checkpoint).read_text())
        if not isinstance(value, dict) or set(value) - set(config):
            raise ValueError("Unknown v5 configuration")
        config.update(value)
    if config["selector"] not in ("off", "program", "model"):
        raise ValueError("Unknown selector")
    if config["base_policy"] not in ("champion", "v4_tools"):
        raise ValueError("Unknown baseline policy")
    if type(config["use_model"]) is not bool or config["use_model"] != (config["selector"] == "model"):
        raise ValueError("use_model must agree with selector")
    for name, maximum in (("max_model_calls", 6), ("max_new_tokens", 128),
                          ("max_input_tokens", 12000), ("threads", 4)):
        if type(config[name]) is not int or not 1 <= config[name] <= maximum:
            raise ValueError("Invalid " + name)
    if config["enable_thinking"] is not False or not isinstance(config["log_dir"], str) or not config["log_dir"]:
        raise ValueError("Nonthinking generation and an audit directory are required")
    LocalGenerator(config)  # Identity/config validation only; weights are lazy.
    return config


def baseline(config):
    if config["base_policy"] == "champion":
        checkpoint = ROOT / "submission/config.json"
        if digest(checkpoint) != BASE_CONFIG_SHA256:
            raise ValueError("The frozen champion checkpoint changed")
        return load_factory(ROOT / "submission/submission.py")(checkpoint)
    inherited = v4_config(ROOT / "agent_v4/config-tools-only.json")
    inherited["log_dir"] = str(Path(config["log_dir"]) / "base-policy")
    return V4Agent(inherited)


class SqlRepairAgent:
    def __init__(self, config, generator=None, base=None):
        self.config = dict(config)
        self.state = EpisodeState()
        self.base = base if base is not None else baseline(config)
        self.generator = generator
        self.model_calls = 0
        self.base_finished = False
        self.attempted = set()
        self.pending = None
        self.unresolved = []
        self.incumbent_sql = None

    def _log(self, record):
        folder = Path(self.config["log_dir"])
        folder.mkdir(parents=True, exist_ok=True)
        task_id = self.state.task["id"]
        path = folder / (hashlib.sha256(task_id.encode()).hexdigest()[:20] + ".jsonl")
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"task_id": task_id, **record}, ensure_ascii=False) + "\n")

    def _finish(self, reason):
        candidate = self.state.candidates[self.state.incumbent_id]
        sql = self.incumbent_sql
        if sql not in self.state.checks or canonical(sql) != candidate.canonical_sql:
            raise ValueError("Exact final SQL must have a real check")
        self._log({"phase": "finish", "reason": reason, "sql": sql,
                   "unresolved": self.unresolved, "state": self.state.snapshot()})
        return {"tool": "submit", "sql": sql}

    def _opportunities(self):
        incumbent = self.state.candidates[self.state.incumbent_id]
        inc_result = self.state.checks[incumbent.sql]["observation"]
        matched = inc_result.get("matches_example") is True
        candidates = [incumbent] + [c for c in self.state.candidates.values() if c.id != incumbent.id]
        for parent in candidates:
            event = self.state.checks.get(parent.sql)
            if event is None or event["observation"].get("ok") is not True:
                continue
            if matched and (parent.id != incumbent.id or not has_explicit_conflict(
                    self.state.task["question"], parent.sql, self.state.schema)):
                continue
            options = build_aggregate_options(parent.sql, self.state.schema)
            if len(options) <= 1:
                continue
            messages = build_messages(self.state.task["question"], parent.sql, self.state.schema,
                                      event, self.state.example, options)
            identity = hashlib.sha256(json.dumps(messages, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
            if identity in self.attempted:
                continue
            requirement = infer_requirement(self.state.task["question"], parent.sql, self.state.schema)
            yield parent, options, messages, identity, requirement, matched

    def _choose(self, options, messages, identity, requirement, parent):
        common = {"kind": "aggregate", "source_sql": parent.sql, "parent_id": parent.id,
                  "decision_id": identity, "requirement_hypothesis": requirement}
        if self.config["selector"] == "program":
            required = requirement["operation"]
            selection = ("KEEP" if required == current_operation(parent.sql, self.state.schema)
                         else required) if required else "UNRESOLVED"
            if selection not in {o.name for o in options} | {"UNRESOLVED"}:
                selection = "UNRESOLVED"
            self._log({"phase": "program_choice", **common, "selection": selection})
            return selection
        if self.model_calls >= self.config["max_model_calls"]:
            return "UNRESOLVED"
        self.model_calls += 1
        if self.generator is None:
            self.generator = LocalGenerator(self.config)
        record = {"phase": "generation", **common, "call": self.model_calls, "prompt": messages}
        try:
            result = self.generator.generate(messages, self.config["max_new_tokens"])
        except Exception as error:
            self._log({**record, "status": "runtime_error", "error": repr(error)})
            raise
        record.update({k: v for k, v in result.items() if k != "text"})
        record["raw_output"] = result.get("text", "")
        record["config"] = {k: self.config[k] for k in
                            ("enable_thinking", "do_sample", "seed", "max_new_tokens")}
        record["config"].update({k: self.config[k] if self.config["do_sample"] else None
                                 for k in ("temperature", "top_p", "top_k")})
        selection = parse_choice(result, options)
        status = ("rejected" if selection is None else "unchanged" if selection == "KEEP"
                  else "unresolved" if selection == "UNRESOLVED" else "accepted")
        self._log({**record, "selection": selection, "status": status})
        return selection

    def act(self, observation):
        self.state.sync(observation)
        self._log({"phase": "state", "state": self.state.snapshot()})
        if not self.base_finished:
            action = self.base.act(observation)
            if action["tool"] != "submit":
                return action
            incumbent = self.state.add_candidate(action["sql"], "baseline_incumbent")
            self.state.set_incumbent(incumbent.id, "baseline_policy_finished_inside_shared_budget")
            self.incumbent_sql = action["sql"]
            self.base_finished = True
        if self.config["selector"] == "off":
            return self._finish("baseline_adapter_only")
        if self.pending is not None:
            proposal = self.state.candidates[self.pending]
            event = self.state.checks.get(proposal.sql)
            if event is None:
                raise ValueError("A pending proposal did not receive its requested check")
            if event["observation"].get("matches_example") is True:
                self.state.set_incumbent(proposal.id, "supported_proposal_matched_public_check")
                self.incumbent_sql = proposal.sql
                return self._finish("checked_local_repair")
            self.pending = None
        if self.state.remaining <= 0:
            return self._finish("shared_tool_budget_exhausted")
        for parent, options, messages, identity, requirement, matched in self._opportunities():
            if self.config["selector"] == "model" and self.model_calls >= self.config["max_model_calls"]:
                break
            self.attempted.add(identity)
            choice = self._choose(options, messages, identity, requirement, parent)
            if choice in (None, "KEEP", "UNRESOLVED"):
                if choice != "KEEP":
                    self.unresolved.append({"parent_id": parent.id, "reason": "no_justified_local_selection"})
                continue
            option = next(o for o in options if o.name == choice)
            if matched and choice != requirement["operation"]:
                self.unresolved.append({"parent_id": parent.id, "reason": "proposal_does_not_address_declared_challenge"})
                continue
            if grounding_issues(option.sql, self.state.schema):
                self.unresolved.append({"parent_id": parent.id, "reason": "new_schema_or_scope_issue"})
                continue
            if any(canonical(sql) == canonical(option.sql) for sql in self.state.checks):
                continue
            proposal = self.state.add_candidate(option.sql, self.config["selector"] + "_aggregate",
                parent_id=parent.id, operator=choice, evidence=[requirement],
                assumptions=["Local semantic selection is a hypothesis, not proof of generalization"])
            self.pending = proposal.id
            self._log({"phase": "proposal", "operator": choice, "parent_id": parent.id,
                       "sql": proposal.sql, "preconditions": option.preconditions})
            return {"tool": "check", "sql": proposal.sql}
        return self._finish("no_supported_untried_semantic_action")


def create_agent(checkpoint=None):
    return SqlRepairAgent(load_config(checkpoint))
