"""One budget for cached hints and composable, grounded structural repairs."""
from dataclasses import replace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlglot import exp
from agent_v2.submission import canonical, parse_query
from agent_v3.evidence import grounding_issues
from agent_v5.submission import SqlRepairAgent as SharedController, load_config as shared_config
from agent_v10.join_repair import build_join_options
from agent_v11.topk import build_topk_options
from agent_v11.submission import infer_topk
from agent_v12.relocation import build_relocation_options


def tool_key(sql):
    """Deduplicate unused output aliases without ever borrowing tool feedback."""
    try:
        tree = parse_query(sql)
    except ValueError:
        return canonical(sql)
    if (not isinstance(tree, exp.Select) or len(list(tree.find_all(exp.Select))) != 1
            or any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))):
        return canonical(sql)
    aliases = {projection.alias.casefold() for projection in tree.expressions if isinstance(projection, exp.Alias)}
    others = tree.copy()
    others.set("expressions", [])
    if any(not column.table and column.name.casefold() in aliases for column in others.find_all(exp.Column)):
        return canonical(sql)
    normalized = tree.copy()
    normalized.set("expressions", [projection.this.copy() if isinstance(projection, exp.Alias) else projection.copy()
                                   for projection in tree.expressions])
    return canonical(normalized.sql(dialect="sqlite"))


def load_config(checkpoint=None):
    config = shared_config(checkpoint)
    if checkpoint is None:
        config.update(selector="program", log_dir="outputs/agent-v15-graph-logs")
    if config["base_policy"] != "champion" or config["selector"] not in ("off", "program") or config["use_model"]:
        raise ValueError("The bounded graph supports champion + off/program without a model")
    return config


class SqlRepairAgent(SharedController):
    def __init__(self, config, base=None):
        if config["base_policy"] != "champion" or config["selector"] not in ("off", "program") or config["use_model"]:
            raise ValueError("Unsupported graph configuration")
        super().__init__(config, base=base)
        self.pending_details = None
        self.edges = []
        self.rejected_hints = set()

    def _log(self, record):
        super()._log({"kind": "repair_graph", **record})

    def _plans(self):
        incumbent = replace(self.state.incumbent, sql=self.incumbent_sql)
        checks = self.state.checks
        matched = checks[self.incumbent_sql]["observation"].get("matches_example") is True
        if not matched:
            checked_keys = {tool_key(sql) for sql in checks}
            for event_index, hint_event in enumerate(self.state.history):
                if hint_event["tool"] != "repair_hint":
                    continue
                for hint_index, sql in enumerate(hint_event["observation"]):
                    identity = tool_key(sql)
                    if identity in checked_keys or identity in self.attempted or identity in self.rejected_hints:
                        continue
                    details = {"hint_event_index": event_index, "hint_index": hint_index, "sql": sql}
                    try:
                        parse_query(sql)
                    except ValueError as error:
                        record = {**details, "reason": "cached_hint_not_parseable_readonly_sql", "error": str(error)}
                        self.rejected_hints.add(identity)
                        self.unresolved.append(record)
                        self._log({"phase": "skip", **record})
                        continue
                    issues = grounding_issues(sql, self.state.schema)
                    if issues:
                        record = {**details, "reason": "cached_hint_has_grounding_issues", "issues": issues}
                        self.rejected_hints.add(identity)
                        self.unresolved.append(record)
                        self._log({"phase": "skip", **record})
                        continue
                    evidence = {"source": "official_repair_hint_history", **details}
                    yield (None, "CACHED_HINT", sql, evidence,
                           ["The hint is an untrusted proposal; parsing and grounding do not establish correctness."],
                           ["Unmatched incumbent", "Previously received hint", "Not already checked"])
            event = checks.get(self.state.issue_sql)
            if event is not None:
                original = self.state.add_candidate(self.state.issue_sql, "original")
                for option in build_relocation_options(self.state.issue_sql, self.state.schema, event):
                    if option.name != "KEEP":
                        yield original, option.name, option.sql, option.evidence, option.assumptions, option.preconditions
        parents = [incumbent]
        if not matched:
            parents += [parent for parent in self.state.candidates.values() if parent.id != incumbent.id]
        for parent in parents:
            event = checks.get(parent.sql)
            if event is None or event["observation"].get("ok") is not True:
                continue
            for option in build_join_options(parent.sql, self.state.schema):
                if option.name != "KEEP":
                    yield parent, option.name, option.sql, option.evidence, option.assumptions, option.preconditions
        for parent in parents:
            event = checks.get(parent.sql)
            if event is None or event["observation"].get("ok") is not True:
                continue
            for option in build_topk_options(parent.sql, self.state.schema):
                if option.name == "KEEP":
                    continue
                cue = infer_topk(self.state.task["question"], option)
                if cue["operation"] is not None:
                    yield parent, option.name, option.sql, cue, cue["assumptions"], option.preconditions

    def act(self, observation):
        self.state.sync(observation)
        self._log({"phase": "state", "state": self.state.snapshot()})
        if not self.base_finished:
            action = self.base.act(observation)
            if action["tool"] != "submit":
                return action
            if action["sql"] not in self.state.checks:
                raise ValueError("The exact baseline submission needs a real check")
            candidate = self.state.add_candidate(action["sql"], "baseline_incumbent")
            self.state.set_incumbent(candidate.id, "champion_finished_inside_shared_budget")
            self.incumbent_sql = action["sql"]
            self.base_finished = True
        if self.config["selector"] == "off":
            return self._finish("baseline_adapter_only")
        if self.pending is not None:
            details = self.pending_details
            event = self.state.checks.get(details["sql"])
            if event is None:
                raise ValueError("Each graph edge needs feedback for its exact checked SQL")
            result = event["observation"]
            self._log({"phase": "check", **details, "ok": result["ok"], "matches_example": result["matches_example"]})
            if result["ok"] is True and result["matches_example"] is True:
                self.state.set_incumbent(self.pending, "supported_graph_candidate_matched_public_check")
                self.incumbent_sql = details["sql"]
                self._log({"phase": "adopt", **details,
                           "interpretation": "Public match is not proof; examine only this incumbent's remaining supported conflicts"})
            else:
                self.unresolved.append({"candidate_id": self.pending, "reason": "partial_candidate_did_not_match"})
            self.pending, self.pending_details = None, None
        if self.state.remaining <= 0:
            return self._finish("shared_tool_budget_exhausted")
        checked_keys = {tool_key(sql) for sql in self.state.checks}
        for parent, operator, sql, evidence, assumptions, preconditions in self._plans():
            parent_id = parent.id if parent is not None else None
            identity = tool_key(sql)
            if identity in checked_keys or identity in self.attempted:
                self._log({"phase": "routing", "parent_id": parent_id, "operator": operator,
                           "sql": sql, "reason": "equivalent_candidate_already_checked_or_attempted"})
                continue
            if grounding_issues(sql, self.state.schema):
                raise ValueError("A pure action produced an ungrounded SQL")
            self.attempted.add(identity)
            candidate = self.state.add_candidate(sql, "graph_proposal", parent_id=parent_id,
                operator=operator, evidence=[evidence], assumptions=list(assumptions))
            self.pending = candidate.id
            self.pending_details = {"parent_id": parent_id, "source_sql": parent.sql if parent is not None else None,
                                    "candidate_id": candidate.id, "sql": sql, "operator": operator}
            self.edges.append(dict(self.pending_details))
            self._log({"phase": "proposal", **self.pending_details, "evidence": evidence,
                       "preconditions": list(preconditions), "assumptions": list(assumptions),
                       "remaining_before_check": self.state.remaining})
            return {"tool": "check", "sql": sql}
        return self._finish("no_supported_untried_graph_edge")


def create_agent(checkpoint=None):
    return SqlRepairAgent(load_config(checkpoint))
