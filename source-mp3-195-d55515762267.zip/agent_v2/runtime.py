"""Offline, CPU-only Qwen runtime; only immutable model weights are shared."""

import json
import os
from pathlib import Path
import threading
import time


MODEL_REPOSITORY = "Qwen/Qwen3-0.6B"
MODEL_REVISION = "c1899de289a04d12100db370d81485cdf75e47ca"
_CACHE = {}
_CACHE_LOCK = threading.Lock()
_GENERATION_LOCK = threading.Lock()


def _model_directory(repository, revision):
    raw_path = os.environ.get("MP3_BASE_MODEL")
    if not raw_path:
        raise RuntimeError("Set MP3_BASE_MODEL to the downloaded local model directory")
    path = Path(raw_path).expanduser().resolve()
    if not path.is_dir():
        raise RuntimeError(f"Local model directory does not exist: {path}")

    # A custom download directory must carry the identity recorded at download time.
    # This identifies the declared source; it is not a substitute for file hashes.
    identity_path = path / "model_identity.json"
    if identity_path.is_file():
        identity = json.loads(identity_path.read_text(encoding="utf-8"))
        if (identity.get("repository") != repository
                or identity.get("revision") != revision):
            raise ValueError("Local model identity differs from the configured model")
    elif not (path.name == revision and path.parent.name == "snapshots"
              and path.parent.parent.name == "models--" + repository.replace("/", "--")):
        raise ValueError(
            "Use the pinned Hugging Face snapshot directory or add model_identity.json "
            "with repository and revision fields"
        )
    if not (path / "config.json").is_file():
        raise ValueError("Local model directory is missing config.json")
    if not list(path.glob("*.safetensors")):
        raise ValueError("Local model directory is missing safetensors weights")
    return path


class LocalGenerator:
    """Reuse CPU weights across tasks without retaining any task messages or answers."""

    def __init__(self, config):
        self.repository = config.get("model_repository", MODEL_REPOSITORY)
        self.revision = config.get("model_revision", MODEL_REVISION)
        self.max_input_tokens = config.get("max_input_tokens", 12000)
        self.threads = config.get("threads", 4)
        if self.repository != MODEL_REPOSITORY or self.revision != MODEL_REVISION:
            raise ValueError("This prototype supports only the pinned Qwen3-0.6B revision")
        if type(self.threads) is not int or not 1 <= self.threads <= 4:
            raise ValueError("threads must be an integer from 1 to 4")
        if type(self.max_input_tokens) is not int or not 1 <= self.max_input_tokens <= 30000:
            raise ValueError("max_input_tokens must be an integer from 1 to 30000")

    def _load(self):
        path = _model_directory(self.repository, self.revision)
        key = (str(path), self.revision, self.threads)
        with _CACHE_LOCK:
            if key not in _CACHE:
                # Imports are lazy so controller tests do not require model dependencies.
                import torch
                from transformers import AutoModelForCausalLM, AutoTokenizer

                torch.set_num_threads(self.threads)
                tokenizer = AutoTokenizer.from_pretrained(
                    str(path), local_files_only=True, trust_remote_code=False,
                )
                model = AutoModelForCausalLM.from_pretrained(
                    str(path), local_files_only=True, trust_remote_code=False,
                    use_safetensors=True, torch_dtype=torch.float32,
                ).to("cpu")
                model.eval()
                if model.config.model_type != "qwen3":
                    raise ValueError("Expected a Qwen3 model architecture")
                parameter_count = sum(parameter.numel() for parameter in model.parameters())
                if parameter_count > 1_000_000_000:
                    raise ValueError("Model exceeds the course parameter limit")
                _CACHE[key] = (torch, tokenizer, model, parameter_count)
            return _CACHE[key]

    def generate(self, messages, max_new_tokens):
        if type(max_new_tokens) is not int or not 1 <= max_new_tokens <= 2048:
            raise ValueError("max_new_tokens must be an integer from 1 to 2048")
        if not isinstance(messages, list) or not messages:
            raise ValueError("messages must be a nonempty list")
        if any(not isinstance(message, dict)
               or set(message) != {"role", "content"}
               or message["role"] not in {"system", "user", "assistant"}
               or not isinstance(message["content"], str)
               for message in messages):
            raise ValueError("messages must contain only role and string content")

        started = time.perf_counter()
        with _GENERATION_LOCK:
            torch, tokenizer, model, parameter_count = self._load()
            prompt = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True,
                enable_thinking=False,
            )
            inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
            prompt_tokens = int(inputs["input_ids"].shape[-1])
            if prompt_tokens > self.max_input_tokens:
                raise ValueError(
                    f"Prompt has {prompt_tokens} tokens; cap is {self.max_input_tokens}. "
                    "Refusing to silently truncate task evidence."
                )
            if prompt_tokens + max_new_tokens > model.config.max_position_embeddings:
                raise ValueError("Prompt plus requested generation exceeds model context")
            pad_token_id = tokenizer.pad_token_id
            if pad_token_id is None:
                pad_token_id = tokenizer.eos_token_id
            with torch.inference_mode():
                output = model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    temperature=None,
                    top_p=None,
                    top_k=None,
                    pad_token_id=pad_token_id,
                    use_cache=True,
                )
            generated = output[0, prompt_tokens:]
            new_tokens = int(generated.numel())
            text = tokenizer.decode(generated, skip_special_tokens=True)
            eos = model.generation_config.eos_token_id
            eos_ids = set(eos if isinstance(eos, list) else [eos])
            stopped_on_eos = bool(new_tokens and int(generated[-1]) in eos_ids)

        return {
            "text": text,
            "prompt_tokens": prompt_tokens,
            "new_tokens": new_tokens,
            "seconds": time.perf_counter() - started,
            "truncated": new_tokens >= max_new_tokens and not stopped_on_eos,
            "model": {
                "repository": self.repository,
                "revision": self.revision,
                "actual_parameters": parameter_count,
                "device": "cpu",
                "dtype": "float32",
                "threads": self.threads,
                "enable_thinking": False,
            },
        }
