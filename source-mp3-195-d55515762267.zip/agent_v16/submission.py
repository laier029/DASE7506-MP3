"""Try a grounded relation hypothesis after the existing candidate graph stalls."""
from dataclasses import replace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agent_v15.submission import SqlRepairAgent as GraphController, load_config as graph_config
from agent_v16.join_binding import build_join_binding_options


def load_config(checkpoint=None):
    config = graph_config(checkpoint)
    if checkpoint is None:
        config["log_dir"] = "outputs/agent-v16-relation-logs"
    return config


class SqlRepairAgent(GraphController):
    def _plans(self):
        yield from super()._plans()
        checks = self.state.checks
        if checks[self.incumbent_sql]["observation"].get("matches_example") is True:
            return
        incumbent = replace(self.state.incumbent, sql=self.incumbent_sql)
        parents = [incumbent] + [candidate for candidate in self.state.candidates.values()
                                 if candidate.id != incumbent.id]
        for parent in parents:
            event = checks.get(parent.sql)
            if event is None or event["observation"].get("ok") is not True:
                continue
            for option in build_join_binding_options(parent.sql, self.state.schema, event):
                if option.name != "KEEP":
                    yield parent, option.name, option.sql, option.evidence, option.assumptions, option.preconditions


def create_agent(checkpoint=None):
    return SqlRepairAgent(load_config(checkpoint))
