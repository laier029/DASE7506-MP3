"""One direct FK endpoint hypothesis from an exact executable checked parent."""

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from agent_v10.join_repair import (
    JoinOption, UnsupportedJoin, _bind, _binding_key, _require, _schema_tables,
    _source, _unique_edge, _unparen,
)


def _inspect(sql, schema, check_event):
    _require(isinstance(sql, str) and sql.strip(), "Expected SQL text")
    _require(isinstance(check_event, dict) and check_event.get("tool") == "check"
             and check_event.get("sql") == sql, "The exact parent string needs a real check event")
    observed = check_event.get("observation", {})
    _require(isinstance(observed, dict) and observed.get("ok") is True
             and type(observed.get("matches_example")) is bool, "The checked parent must execute")
    statements = sqlglot.parse(sql, read="sqlite")
    _require(len(statements) == 1 and isinstance(statements[0], exp.Select), "Expected one SELECT")
    tree = statements[0]
    _require(len(list(tree.find_all(exp.Select))) == 1
             and not any(tree.find_all(exp.Subquery, exp.With, exp.Window, exp.SetOperation))
             and not any(tree.args.get(key) for key in ("qualify", "windows", "laterals", "operation_modifiers")),
             "Nested or window scopes are unsupported")
    origin, joins = tree.args.get("from"), tree.args.get("joins", [])
    _require(isinstance(origin, exp.From) and origin.this is not None and not origin.expressions
             and len(joins) == 1, "Exactly one ordinary physical JOIN is supported")
    join = joins[0]
    _require(not join.args.get("side") and str(join.args.get("kind") or "").upper() in ("", "INNER")
             and join.args.get("on") is not None and not join.args.get("method") and not join.args.get("using")
             and not any(value for key, value in join.args.items()
                         if key not in ("this", "on", "kind", "side", "method", "using")),
             "Only a plain INNER JOIN is supported")
    tables = _schema_tables(schema)
    sources = [_source(origin.this, tables), _source(join.this, tables)]
    _require(len({source["alias"].casefold() for source in sources}) == 2
             and len({source["table"]["name"].casefold() for source in sources}) == 2,
             "Duplicate aliases and self-join roles are unsupported")
    _require(not any(not isinstance(star.parent, exp.Count) for star in tree.find_all(exp.Star)),
             "Expanded star outputs are unsupported")
    for column in tree.find_all(exp.Column):
        _bind(column, sources)
    condition = _unparen(join.args["on"])
    _require(isinstance(condition, exp.EQ), "The whole ON predicate must be a bare equality")
    left, right = _bind(condition.this, sources), _bind(condition.expression, sources)
    _require(left[0]["alias"].casefold() != right[0]["alias"].casefold(),
             "The equality must bind different physical aliases")
    edge = _unique_edge(sources[:1], sources[1])
    source, source_column, target, target_column = edge
    old_keys = {_binding_key(left), _binding_key(right)}
    fk_keys = {_binding_key((source, source_column)), _binding_key((target, target_column))}
    _require(old_keys != fk_keys, "The current equality already is the declared FK, possibly reversed")
    return tree, (left, right), edge, observed["matches_example"]


def build_join_binding_options(sql, schema, check_event) -> list[JoinOption]:
    """Pure KEEP + REBIND_JOIN_FK proposal; caller must gate unmatched incumbent.

    Non-FK equality is not itself an error. Exact successful execution is a fact;
    the intended relation is an assumption that still needs a real check.
    """
    try:
        tree, old_bindings, edge, parent_match = _inspect(sql, schema, check_event)
        source, source_column, target, target_column = edge
        replacement = exp.EQ(this=exp.column(source_column["name"], table=source["alias"], quoted=True),
                             expression=exp.column(target_column["name"], table=target["alias"], quoted=True))
        old_on = tree.args["joins"][0].args["on"]
        changed = tree.copy()
        changed.args["joins"][0].set("on", replacement)
        new_sql = changed.sql(dialect="sqlite")
        restored = sqlglot.parse_one(new_sql, read="sqlite")
        restored.args["joins"][0].set("on", old_on.copy())
        _require(restored == tree, "An unrelated source clause changed")
        evidence = {
            "status": "structural_hypothesis", "exact_parent_sql": sql,
            "parent_check_ok": True, "parent_matches_example": parent_match, "join_index": 0,
            "old_on_sql": old_on.sql(dialect="sqlite"),
            "replacement_on_sql": replacement.sql(dialect="sqlite"),
            "old_endpoints": [{"table": item[0]["table"]["name"], "alias": item[0]["alias"],
                               "column": item[1]["name"]} for item in old_bindings],
            "foreign_key": {"source_table": source["table"]["name"], "source_alias": source["alias"],
                            "source_column": source_column["name"], "target_table": target["table"]["name"],
                            "target_alias": target["alias"], "target_column": target_column["name"],
                            "target_single_column_primary_key": True},
        }
        preconditions = (
            "one physical SELECT, exactly one ordinary INNER JOIN and unambiguous original field bindings",
            "an exact real parent check reports successful execution",
            "the entire ON condition is a cross-alias column equality differing from the declared FK",
            "exactly one complete explicit FK connects the tables and targets a single-column primary key",
            "only the ON subtree changes; future controller must require its incumbent to be unmatched",
        )
        assumptions = (
            "the declared FK is the intended relation; a different valid equality can be intentional",
            "the resulting NULL filtering, row coverage and multiplicity are appropriate for the task",
            "the existing sources, INNER JOIN kind, filters, grouping, ordering and projection remain appropriate",
            "this candidate has no execution feedback yet; public matching would not prove semantic correctness",
        )
        return [JoinOption("KEEP", sql, preconditions, evidence, assumptions),
                JoinOption("REBIND_JOIN_FK", new_sql, preconditions, evidence, assumptions)]
    except (UnsupportedJoin, SqlglotError, TypeError, KeyError, AttributeError, RecursionError):
        return []
