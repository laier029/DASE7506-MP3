"""Compact, factual context and conservative SQL name checks.

These helpers do not read databases, infer a reference answer, or repair SQL.
"""

from copy import deepcopy

import sqlglot
from sqlglot import exp
from sqlglot.optimizer.scope import build_scope

from agent_v2.submission import parse_query, validate_schema


def schema_lines(schema):
    """Keep every table, column, type and declared key without truncation."""
    lines = []
    for table in schema:
        columns = []
        for column in table["columns"]:
            text = f"{column['name']}:{column.get('type') or 'UNSPECIFIED'}"
            if column.get("pk"):
                text += f" PK{column['pk']}"
            if column.get("not_null"):
                text += " NOT NULL"
            columns.append(text)
        lines.append(f"{table['name']}({', '.join(columns)})")
        for key in table.get("foreign_keys", []):
            lines.append(f"FK {table['name']}.{key['from']} -> {key['table']}.{key['to']}")
    return lines


def _sql(expression):
    return expression.sql(dialect="sqlite") if expression is not None else None


def sql_summary(sql):
    """Summarize syntax, preserving literals and separating SELECT query blocks.

    parse_ok is not an execution or semantic-correctness result. outputs describes
    the first SELECT (also the output shape source for a set operation). tables
    contains syntactic references, including CTE names, rather than bound sources.
    """
    try:
        expression = parse_query(sql)
    except (ValueError, sqlglot.errors.SqlglotError, RecursionError) as error:
        return {"parse_ok": False, "error": str(error), "outputs": [],
                "tables": [], "query_blocks": []}
    blocks = []
    for index, select in enumerate(expression.find_all(exp.Select)):
        group, order = select.args.get("group"), select.args.get("order")
        where, having = select.args.get("where"), select.args.get("having")
        limit = select.args.get("limit")
        aggregates = [node.sql(dialect="sqlite") for node in select.find_all(exp.AggFunc)
                      if node.find_ancestor(exp.Select) is select]
        blocks.append({
            "index": index,
            "outputs": [_sql(item) for item in select.expressions],
            "from": _sql(select.args.get("from")),
            "joins": [_sql(item) for item in select.args.get("joins", [])],
            "where": _sql(where.this) if where is not None else None,
            "group_by": [_sql(item) for item in group.expressions] if group else [],
            "having": _sql(having.this) if having is not None else None,
            "order_by": [_sql(item) for item in order.expressions] if order else [],
            "aggregates": list(dict.fromkeys(aggregates)),
            "distinct": select.args.get("distinct") is not None,
            "limit": _sql(limit.expression) if limit is not None else None,
        })
    return {
        "parse_ok": True,
        "error": None,
        "outputs": blocks[0]["outputs"] if blocks else [],
        "tables": list(dict.fromkeys(_sql(table) for table in expression.find_all(exp.Table))),
        "query_blocks": blocks,
        "set_operation": expression.key if isinstance(expression, exp.SetOperation) else None,
        "set_order_by": _sql(expression.args.get("order"))
        if isinstance(expression, exp.SetOperation) else None,
        "set_limit": _sql(expression.args.get("limit"))
        if isinstance(expression, exp.SetOperation) else None,
    }


def feedback_summary(check_event, example):
    """Expose observed facts only; a public match is not a general correctness claim."""
    feedback = check_event.get("observation", check_event)
    ok = feedback.get("ok")
    actual_columns = deepcopy(feedback.get("columns", []))
    expected_columns = deepcopy(example.get("columns", []))
    row_count = feedback.get("row_count")
    expected_count = example.get("row_count")
    empty = ok is True and row_count == 0
    return {
        "sql": check_event.get("sql"),
        "ok": ok,
        "error": deepcopy(feedback.get("error")),
        "actual_columns": actual_columns,
        "expected_columns": expected_columns,
        "actual_column_count": len(actual_columns),
        "expected_column_count": len(expected_columns),
        "column_count_delta": len(actual_columns) - len(expected_columns) if ok is True else None,
        "row_count": row_count,
        "expected_row_count": expected_count,
        "rows_preview": deepcopy(feedback.get("rows", [])),
        "expected_rows_preview": deepcopy(example.get("rows", [])),
        "truncated": feedback.get("truncated"),
        "expected_truncated": example.get("truncated"),
        "matches_example": feedback.get("matches_example"),
        "empty_result": empty,
        "matching_empty_result": empty and feedback.get("matches_example") is True,
    }


def grounding_issues(sql, schema):
    """Return definite parse/name issues, not an exhaustive SQLite validator.

    The extra unqualified-column check covers only one physical table in a single
    SELECT scope. Joins, CTEs, derived sources and correlated queries are left to
    SQLite. Quoted unqualified names are also deferred because SQLite may interpret
    an unknown double-quoted name as a string literal.
    """
    try:
        expression = parse_query(sql)
        validate_schema(expression, schema)
        root = build_scope(expression)
        scopes = list(root.traverse())
    except (ValueError, sqlglot.errors.SqlglotError, RecursionError) as error:
        return [str(error)]
    if (len(scopes) != 1 or not isinstance(expression, exp.Select)
            or expression.args.get("with") or expression.args.get("joins")
            or len(root.sources) != 1):
        return []
    source = next(iter(root.sources.values()))
    if not isinstance(source, exp.Table):
        return []
    table = next(table for table in schema if table["name"].casefold() == source.name.casefold())
    columns = {column["name"].casefold() for column in table["columns"]}
    # These hidden names may exist on ordinary SQLite tables; the schema does not
    # identify WITHOUT ROWID tables, so leave availability to the executor.
    columns.update({"rowid", "_rowid_", "oid"})
    aliases = {item.alias.casefold() for item in expression.expressions if item.alias}
    projection_nodes = {id(node) for item in expression.expressions for node in item.walk()}
    issues = []
    for column in root.columns:
        if column.table or column.name == "*" or column.name.casefold() in columns:
            continue
        if isinstance(column.this, exp.Identifier) and column.this.args.get("quoted"):
            continue
        if column.name.casefold() in aliases and id(column) not in projection_nodes:
            continue
        issues.append(f"Unknown column in {source.name}: {column.name}")
    return list(dict.fromkeys(issues))
