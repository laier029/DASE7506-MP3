# SQL Repair Agent

DASE7506 Mini-project 3 | Second submission | 27 November 2026

The frozen agent answered **195 of 240 TEST questions (81.25%)** and **117 of 120 validation questions (97.50%)**. The official scorer replays the tool trace and requires the submitted SQL to match the expected result on all three database instances. The previous submission scored 181/240. The 14-question increase is a difference between whole-bank scores. All examples and per-question comparisons below use TRAIN.

## Harness design

Each question starts with a fresh controller. V16 first produces a provisional SQL query. The controller may then request one independent model proposal and review how the chosen SQL counts entities or combines conditions. The same tool history and remaining budget travel through these stages.

### Context management

The controller organizes the question around two decisions. **What should be returned?** It uses the public example headers and the question to identify the output columns, their order and what one row represents. **Which records qualify?** It looks for the entity a condition applies to, the unit to count, the scope of a comparison, and cues such as “both”, “without” or “highest”. Table names, column ownership and foreign keys from the public schema help bind those requirements to expressions in the SQL. An ambiguous column or join can leave a proposed change unresolved.

The controller keeps the draft, provisional SQL, candidates and their tool observations within the episode. It can look up a previous check as it considers an alternative. The fixed model prompt contains the question, full schema, draft, draft check, expected example and ordering flag. Candidate rankings, hint lists and the controller's intermediate decisions stay with the program. This gives the model room to suggest a different interpretation, but also means it has no second turn to act on feedback about its own proposal.

### Tool-use strategy

The controller requests the schema first, then spends calls according to the uncertainty that remains. An evident output or binding conflict can justify checking a proposed edit before the original draft. Every charged action consumes one of eight calls. The controller reuses observations for previously checked SQL and can submit its provisional answer when the budget runs out.

| Tool | Decision it supports | TRAIN use |
|---|---|---:|
| `schema` | Identify the tables, columns and keys that can express the requested output and relationships. | 175 questions |
| `check` | Run an answer on the public instance. Read the execution error or result, row count and match flag before spending another call. | 482 calls on 175 questions |
| `repair_hint` | After checking or executing the exact draft, request its cached repair suggestions. A suggested SQL still needs evidence. | 161 questions |
| `execute` | Run a targeted probe, for example to see which values occur in a disputed column. The result reports rows or an error. | 14 questions |
| `retrieve` | Request up to three other TRAIN examples when the provisionally available evidence leaves a repair pattern unresolved. | 0 questions |
| `submit` | Return the selected SQL and end the episode. This action is free. | 175 questions |

Counts cover 79 development and 96 regression questions. Both query tools display up to eight rows. The match flag compares the full public result and respects the ordering requirement.

## From tool evidence to a submitted query

### Retrieval

The controller has two sources of prior repairs. The official `retrieve` action searches TRAIN questions and drafts and returns examples that can seed a candidate. The local index built from 305 fitting questions stores anonymized question patterns and SQL operator tags. It excludes entries with the current schema fingerprint, finds the nine closest patterns and weights their votes by similarity. A phrase such as “for each” can give grouping candidates more weight. The local lookup consumes no official tool call. These votes help rank candidates. The current schema supplies the identifiers.

### SQL repair and model routing

V16 proposes edits to the draft and considers tool suggestions. For a grouping error, for example, the repair can change which entity is counted while preserving the output columns. Once V16 has a provisional answer, a public mismatch, an empty match, or cues about roles, counts, grouping or existence can trigger the H65 model if checking budget remains. H65 proposes one complete query. The controller requires a standalone, read-only `SELECT` or `WITH` query and checks that identifiers bind to the schema. A final program stage can also build qualifying groups separately and combine them using union, intersection or exclusion. This handles conditions that apply to different rows or different groups.

### Candidate acceptance and stopping

When the model and V16 disagree, the controller prefers the model query if only it matches the public example. When both match, supported cases use small synthetic databases with independently computed answers. Unequal numbers of child records, for example, can distinguish counting entities from counting joined rows. If the comparison is inconclusive, the program retains V16 at that stage. A later review can reopen a public match for a specific structural discrepancy, such as an unrestricted maximum where the question names a comparison group. The final population review considers at most two distinct alternatives, reuses known checks and requires a public match before replacing its provisional answer. Otherwise it submits that answer.

### A TRAIN trace across the modules

A question asks for the date and ID of claims with **more than two settlements or the highest claimed amount**. The two output columns belong to a claim. The settlement threshold counts related rows per claim, while the maximum compares claims themselves. The provisional query compared payment amounts and dates. Its public check returned zero rows and matched. The controller rebuilt the count using the claim-to-settlement key and computed the maximum on the claims table. A claim could then qualify through either branch, including a highest-value claim with no settlement.

The recorded run used one schema call and four checks. All four returned matching empty results, and the controller submitted the fourth query. An independent TRAIN fixture later gave one low-value claim three settlements and two equally highest claims no settlements. All three should appear. The repaired SQL returned all three. The fixture verifies the semantic interpretation offline. The online decision used only the question, schema and public observations.

## Controlled evaluation

The harness fitting panel used 305 TRAIN questions from 75 databases. The development and regression panels used 79 questions from 19 databases and 96 from 24, respectively. These panels are database-disjoint from fitting and have been used in earlier experiments. Validation served as a regression check before the final offline TEST run. The choice of controller was frozen before that run.

**Ablation 1. Which conditions can the controller represent?** The same provisional-answer pipeline, H65 weights and eight-call budget were used throughout. Each row retains the preceding capabilities. Results count actual final submissions passing all three instances.

| Controller | Fit / 305 | Development / 79 | Regression / 96 |
|---|---:|---:|---:|
| Preceding frozen controller | 252 | 73 | 85 |
| Add union, intersection and exclusion of qualifying groups | 254 | 73 | 85 |
| Add independently ranked or counted alternatives | 254 | 74 | 86 |
| Restrict a comparison to the class named in the question | 254 | 75 | 86 |
| Final field-binding and impossible-intersection guards | 254 | 75 | 86 |

On the 175 development and regression questions, the final stage checked five additional queries, adopted all five and gained three correct submissions with zero regressions. The three gains occurred in three databases. Across all three TRAIN panels, eleven independently specified fixtures cover the five gains. The last row tied the preceding row on correctness and saved one fitting-panel check. Both this controller and its immediate predecessor scored 195/240 on TEST.

**Ablation 2. What does live generation contribute?** With the final harness and the same public tools available, disabling live H65 generation yielded 73/79 and 84/96. Enabling it yielded 75/79 and 86/96. On matched questions, H65 added five correct submissions and lost one, for a net gain of four. The public hint tool remained available in both arms.

**Where repair still fails.** For the 14 remaining incorrect submissions on those two TRAIN panels, the queries already checked by the controller contained zero three-instance-correct answers. A separate TRAIN audit obtained all official hints and also found zero correct hints on those 14 questions. Changing only which of these queries is selected would therefore have recovered none of them. Other failure cases include choosing the wrong relationship role and confusing one row per entity with one row per distinct displayed value. Independently constructed data can distinguish a particular interpretation, while sparse public data can leave it unresolved.

## Model, cost and reproduction

**Model and training data.** The sole live model is Qwen/Qwen3-0.6B at revision `c1899de289a04d12100db370d81485cdf75e47ca`, with 596,049,920 base parameters and 1,146,880 unmerged adapter parameters, 597,196,800 in total. H65 was trained on 257 unique official TRAIN questions from 74 fitting databases. Targets comprised 196 repairs and 61 preserved queries. Only the A/B matrices in q_proj and v_proj were trained, with rank 8, alpha 16, seed 42 and 76 updates. The final harness experiment reused these weights. Training records, configuration, label provenance and the training log are in `training/`.

**Official runtime.** Offline Linux used four CPU threads, one prediction worker and the official scorer. Greedy non-thinking inference generated at most one completion per task, with a 384-new-token cap.

| Measured resource | Validation / 120 | TEST / 240 |
|---|---:|---:|
| Questions with a live generation | 98 | 182 |
| Generated tokens, total / maximum per completion | 2,184 / 83 | 4,781 / 384 |
| Mean charged tool calls per question | 4.425 | 4.6125 |
| Prediction / scoring wall time, seconds | 649.8 / 8.7 | 1,123.1 / 17.4 |
| Prediction / scoring CPU time, seconds | 2,297.1 / 32.5 | 3,958.5 / 66.8 |
| Peak prediction RSS, GiB | 4.61 | 4.68 |

**Untrusted inputs.** Questions, schema text, retrieved material, hints, generated text and database values can contain instructions or misleading SQL. The controller packages observations as data, constructs tool actions in code and passes SQL through read-only parsing and the official execution limits. Network access is disabled during inference. A misleading instruction can still induce a legal query with the wrong meaning.

**Reproduction.** Extract the source and adapter separately. Provision the pinned base snapshot and dependencies, then follow `REPRODUCE.md` using the unchanged official Starter. The entry is `method.py` with `create_agent(checkpoint=None)`. Set `MP3_BASE_MODEL` and `MP3_ADAPTER_DIR` to absolute local paths. The loader uses local safetensors and disables remote code. The archive contains the original predictions and full official scores in `outputs/`, with run statistics, TRAIN comparisons and model receipts in `evidence/`.

**Attribution.** Codex assisted with experimental design, implementation, verification and report preparation. The benchmark is the course's Spider-derived dataset. Distribution details and upstream acknowledgements appear in `NOTICE`.
