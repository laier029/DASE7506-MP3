# Repairing SQL with public feedback and a small language model

DASE7506 Mini-project 3 · Individual project report · Frozen submission H80-B

## Abstract

A SQL query can return the expected result on one database while counting the wrong objects. This project asks whether a small model can propose a repair that a deterministic agent missed, and what evidence the agent needs before accepting it. The submitted agent first runs a program called V16 to obtain a provisional answer. When the execution history or the wording of the question gives a reason to reconsider, a locally trained Qwen3-0.6B LoRA proposes one complete query. The controller checks that proposal and can use small, independently specified databases to resolve a tie.

On two TRAIN panels with separate databases, the system improved from 59 to 62 correct out of 79 and from 76 to 79 out of 96, preserving every previously correct answer. Independent examples supported two of the six gains. On official validation it scored **117/120 (97.50%)**. On the full public TEST benchmark it scored **181/240 (75.42%)** in **19 minutes 54 seconds** of offline CPU prediction, with **4.64 GiB** peak resident memory. These are local results from the official scorer.

## 1. What counts as a repair?

Each task supplies a natural-language question, an imperfect SQLite query and a public example. A practical repair must preserve both what the question asks to return and which records should contribute. Getting the output width right can still leave a duplicated count, a missing group or an unintended exclusion.

The controller sees the results of queries on one public instance. The official scorer independently replays the tool trace and awards one point only if the submitted query produces the expected result on **all three instances**. A third form of evidence is an independently constructed database with an expected answer derived from the question. Its purpose is to expose a semantic difference, such as whether a branch with zero customers contributes to an average. The report distinguishes public matches, official points and independent evidence throughout. The course splits contain 480 TRAIN, 120 validation and 240 TEST tasks with separate database schemas. [Official project specification](https://raw.githubusercontent.com/xudongwu-0/xudongwu-0.github.io/main/courses/dase7506/mp3/PROJECT.md)

## 2. How the agent reaches a decision

| Stage | Information and decision |
|---|---|
| Build a provisional answer | V16 reads the schema, considers edits to the draft and checks candidates against the public example. It proposes a SQL query for submission. |
| Decide whether to call the model | With budget remaining, the H67 rule routes a task to the model if the public result or the query raises a specific risk. Otherwise V16's answer is submitted. |
| Generate one alternative | The H65 adapter receives the original task and its public evidence. It returns a complete SQLite query in one greedy, non-thinking completion of up to 384 new tokens. |
| Check the alternative | The controller accepts a single read-only SELECT or WITH query, parses it, checks that its fields bind and obtains or reuses an actual public check for that SQL. |
| Submit | A uniquely matching model proposal can replace V16. When two different queries both match, the controller looks for evidence that distinguishes them. Inconclusive evidence leaves V16's answer in place. |

### Tools and memory

The official factory creates a fresh agent for each task. Each call to `act(observation)` returns one action, and the tool result appears in the next observation. V16 uses the history to track attempted queries, their outputs and the remaining budget. The model weights stay loaded across tasks. The course allows eight charged actions per task, bans repeated identical actions and makes submission free. Previously checked SQL can use the recorded feedback.

| Tool | Role in the submitted system | Validation calls |
|---|---|---:|
| `schema` | Read the tables, columns and declared foreign keys. Use them to bind fields and identify possible joins. | 120 |
| `check` | Run the draft or a candidate and compare it with the example. Record errors, result width, row count, preview and match status. | 286 |
| `repair_hint` | Read the course's cached suggestions after checking or executing the exact original draft. A suggested SQL query still needs verification. | 108 |
| `execute` | Inspect an error or a result to investigate a specific data hypothesis. | 3 |
| `retrieve` | Retrieve TRAIN examples through the official tool. Reuse a structural edit or shortlist a compatible example query for checking on the current task. | 1 |

Across the 120 validation tasks, all began with `schema`. The first `check` tested the exact draft on 100 tasks and a structurally motivated alternative on 20. All 108 hint requests followed a check of the original draft. The total was **518 charged actions**, plus 120 free submissions. This gives the model access to full schema and real execution evidence while preserving room for a candidate that the draft alone did not suggest.

### Routing and acceptance

The H67 route looks for a missing or failed check, a matching empty result, question wording about roles, counts or quantifiers, or query structures such as `DISTINCT`, `GROUP BY`, `HAVING` and `EXISTS`. A flag makes the task eligible for review. The controller obtains the original check if needed and possible. The model receives the question, full public schema, original draft, original check feedback, public example and ordering flag. V16's provisional SQL, retrieved passages and hint text remain in the controller. This lets the model reconsider a mistaken join or aggregation without being asked to defend V16's answer.

A truncated response, unbound column or unusable SQL leaves the provisional answer in place. If the proposals are distinct and both have public feedback, the controller adopts the model when it alone matches. If both match, the H61 rules can construct small in-memory databases with expected answers grounded in the question. When H61 abstains, H66 checks a narrower family of aggregate and join-multiplicity disagreements. For example, a join may give a branch four votes in an average because it has four clients. A rule selects the model only when the available evidence supports it. Two failing queries, missing evidence, equivalent SQL or an inconclusive tie retain V16. [Agent entry point](method.py) · [Routing implementation](harness_lab/h67/routed_agent.py) · [Tie-breaking rules](harness_lab/h66/judge.py)

## 3. Training the repair adapter

The 480 TRAIN tasks were partitioned by whole database. The fitting partition contained **305 tasks from 75 databases**. The development panel contained **79 from 19**, and the confirmation panel **96 from 24**. These database sets were disjoint. Both panels had been used in earlier experiments, so they measure cross-database regression on known benchmarks. Validation informed design selection. H80-B and its weights were frozen before its reported TEST run. Several frozen systems were evaluated over the life of the project, and the hand-in uses the best previously recorded aggregate result.

H65 learned from **257 distinct fitting questions across 74 databases**. Each input used the same information available for the model's first answer online. The target was a complete SQLite query. There were 196 examples of changing the draft and 61 of returning it intact. Including the latter gave the model a concrete response to a correct draft. Each target passed all three grading instances for its TRAIN task. Of the 257 labels, 104 also had independent boundary examples, 45 had additional normalized syntax-tree or SQLite bytecode equivalence evidence, and 108 relied on the course reference with nonempty official results. References and extra scoring instances supported offline labels and evaluation. They were excluded from the inference prompt.

| Setting | Frozen value |
|---|---|
| Base model | `Qwen/Qwen3-0.6B`, revision `c1899de289a04d12100db370d81485cdf75e47ca` |
| Trainable weights | LoRA A/B on the query and value projections (`q_proj`, `v_proj`), rank 8, alpha 16, dropout 0. The original base and tokenizer were frozen. |
| Actual parameters | 596,049,920 base + 1,146,880 adapter = **597,196,800** loaded parameters |
| Optimization | Local Apple MPS, AdamW, learning rate 0.0002, weight decay 0.01, seed 42, effective batch size 8 |
| Supervision | Fixed endpoint of 76 optimizer updates, 608 sample presentations and 18,257 supervised answer tokens including end-of-sequence markers. Prompt tokens were masked in the loss. |

The submitted adapter is the H65 run trained on these real repair examples. Training provenance, the frozen schedule and the completed run record are included in the source archive. [Provenance](training/provenance.json) · [Training plan](training/plan.json) · [Completion record](training/completed.json)

## 4. What did the model and controller each contribute?

The table separates producing a correct SQL query from getting it into the final submission. Comparisons used the same questions within each panel and the same three-instance metric. Controller-only replays reused model outputs for matching prompts and weights, then reran tool and selection decisions. Counts of routed requests in those replays measure how often a policy would call the model. Section 6 reports live inference costs.

| Controlled comparison | Outcome |
|---|---|
| **Whole system.** Add H65 proposals, tie-breaking and risk routing to the complete V16 program. | Development improved **59/79 → 62/79** and confirmation **76/96 → 79/96**. Each panel gained three and lost zero. The six gains came from six databases. |
| **Adapter.** Hold the 79 development questions, V16 trajectory, first-answer format and H61 acceptance rule fixed. Replace the unmodified Qwen base with H65. | Valid proposals rose **46 → 57**. Proposals passing all three instances rose **23 → 34**. Final correct submissions rose **60 → 62**. Better generation helped even though most of the additional correct proposals did not change the final score. |
| **Tie-breaking.** Hold H65 outputs and public feedback fixed. Invoke H66 only when H61 abstains. | Of 64 public ties across the two panels, one changed the final selection. Confirmation rose **78/96 → 79/96** and development stayed **62/79**. The successful bank query already existed before the acceptance rule changed. |
| **Routing.** Hold the H65 model and H66 acceptance fixed. Compare requesting a model answer on every task with the H67 risk rule. | Requests fell **175 → 146** and charged tool actions **789 → 771**. All 175 final SQL strings were identical. The policy avoided 29 requests (16.6%) on these panels. |
| **Combining edits.** Hold the two proposals, acceptance rule and total budget fixed. Allow one candidate formed by merging independent edits to the original draft. | On 79 development tasks this spent one additional check, added no previously missing three-instance-correct query and left the score at **62/79**. It failed the development threshold and was excluded from the submitted system. |

Candidate coverage limited the benefit of better selection. The complete system missed **34 of the 175 tasks**. In an offline analysis, choosing the best available SQL for every question from the V16/H65 checked queries, valid model first answers and final submissions would yield **63/79 and 80/96**. Two errors were recoverable by choosing differently. In the other **32**, the recorded pool contained no three-instance-correct query. These figures bound selection within this pool. They leave open the gains from generating a genuinely different query. [Frozen version-selection record](evidence/selection.json)

## 5. Three TRAIN decisions that explain the numbers

**A branch should contribute once to a branch average.** A bank question asked for the average number of customers per branch. The original draft referenced a nonexistent customer-table column. V16 located the right field in `bank` but retained an inner join to individual customers. This repeated a busy branch once per customer and removed branches with none. H65 removed the join and averaged the stored branch counts directly.

```sql
SELECT AVG(no_of_customers) FROM bank
```

The agent read the schema, checked the V16 query, checked the original draft and then checked the H65 query. That took four charged actions and one model call. Both candidates returned **163** on the public instance. In a small database constructed by the tie rule, four branches had **4, 0, 2 and 0** customers. The question gives each branch one vote, so the expected average is **1.5**. After the inner join, the six customer rows yield **3.33**. A second constructed database also favored the direct average. The agent submitted H65's query and moved from **one of three** official TRAIN instances to **three of three**. This case explains the mechanism directly. The database had been examined during development.

**An empty public result can conceal a correct draft.** Another question requested the names and ages of all males, ordered by age. The supplied draft included all three requirements.

```sql
SELECT name, age
FROM Person
WHERE gender = 'Male'
ORDER BY age ASC
```

V16 removed the age output and kept the ordering. H65 kept both columns and removed the ordering. All three queries returned zero rows publicly, and the public example expected one column. Only V16 matched the public check. The agent submitted V16 after four charged actions and one model call, passing **one of three** official TRAIN instances. A later independent example with Kai aged 19 and Lee aged 35 made the error observable. The draft returned both ordered pairs, while the final SQL returned only their names. This example was built after the run. The online controller had only the public evidence when it chose.

**Two partially correct queries can still leave no correct choice.** A claims question requested the identifier, date and settlement count of the claim with the most settlements. V16 supplied all three outputs, but its extra join to payments could count one settlement twice. H65 counted rows in the settlement table but omitted the claim date. Neither query passed all three TRAIN instances. Repairing the question requires counting settlements at the correct level and obtaining the date without changing that count.

Across the six official gains over V16, a separate review using 13 constructed examples supported two repairs, exposed counterexamples for three and left one interpretation ambiguous. One instructive distinction was between a city with a small store and a city with no large store. A city can contain both. A single qualifying row can establish the former, while the latter requires excluding any disqualifying row for that city. These results qualify the semantic interpretation of the six gains even though all six count under the official metric.

## 6. Frozen results and measured cost

| Metric | Validation | TEST |
|---|---:|---:|
| Correct on all three instances | **117/120 (97.50%)** | **181/240 (75.42%)** |
| Actual model completions | 98 | 182 |
| New tokens, total / largest completion | 2,184 / 83 | 4,781 / 384 |
| Charged tool actions, total / mean / maximum per task | 518 / 4.32 / 8 | 1,033 / 4.30 / 8 |
| Prediction elapsed time | 664.19 s | 1,193.81 s |
| Prediction CPU time, user + system | 2,340.49 s | 4,185.19 s |
| Peak prediction RSS | 4.60 GiB | 4.64 GiB |
| Official scoring elapsed time | 8.70 s | 16.92 s |

Prediction ran offline on Linux with four CPU threads and one prediction worker. CPU time sums work across threads and can exceed elapsed time. The scorer ran separately with four workers. Both runs stayed within the live-model route's 16 GiB peak memory, two-hour prediction and 180-second scoring limits. On validation, all 120 submitted queries were byte-for-byte identical to V16's provisional answers despite 98 real completions. The 117 correct answers therefore show preservation on this panel. The TRAIN comparisons above provide the evidence of incremental model-assisted repairs. [Validation measurements](evidence/validation-verification.json) · [TEST aggregate measurements](evidence/test-verification.json)

## 7. Untrusted input, assistance and reproduction

Question text, schema identifiers, cell values, hints and retrieved examples can contain instruction-like content. The controller keeps public evidence in structured fields and gives the model authority only to propose SQL. It controls the tool names, budgets and final submission. It checks the proposed query's form and field binding before using the official read-only executor. Constructed examples run in a separate in-memory database. An adversarial value can still induce a syntactically valid query with the wrong meaning. A public check or a tie-breaking example can expose some such mistakes. The framework cannot guarantee the semantic integrity of every input.

The course supplied the Spider-derived data and cached shared hints. All task-specific material used to fit H65 came from the TRAIN fitting partition. OpenAI Codex assisted with implementation, experimental design, diagnosis, verification and writing. Other language models were consulted in earlier design discussions. Graded prediction used the single local Qwen base and the declared adapter. The shared hint is a fixed course tool. Dataset and component attribution are included in the archive. [Notices](NOTICE)

**Reproduction.** Use the official Starter, the extracted source ZIP and the separately extracted adapter ZIP. The recorded Linux aarch64 environment used Python 3.12.16, CPU PyTorch 2.7.1, Transformers 4.53.2, PEFT 0.17.1 and SQLGlot 27.29.0. Install the two packaged requirements files, using CPU PyTorch. Before disconnecting the network, download the pinned base with the command below and retain the snapshot path it prints.

```sh
hf download Qwen/Qwen3-0.6B --revision c1899de289a04d12100db370d81485cdf75e47ca
```

Set the five paths below to actual absolute directories. The loader verifies the pinned base files, uses local safetensors with remote code disabled, and loads the unmerged adapter for inference. Run the predictor and scorer inside offline Linux with four CPU threads and a 16 GiB memory limit.

```sh
set -eu
export STARTER=/absolute/path/to/official/starter
export EXPORT=/absolute/path/to/extracted/source
export MP3_BASE_MODEL=/absolute/path/to/pinned/base/snapshot
export MP3_ADAPTER_DIR=/absolute/path/to/extracted/adapter
export RESULT_DIR=/absolute/path/to/new/results
export PYTHONPATH="$EXPORT:$STARTER"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$RESULT_DIR"
cd "$RESULT_DIR"
for split in validation test; do
  export MP3_RECEIPTS="$RESULT_DIR/$split-model-receipts"
  timeout 7200 python -m mp3_sql.predict --split "$split" --workers 1 \
    --method "$EXPORT/method.py" --output "$RESULT_DIR/$split.json"
  timeout 180 python -m mp3_sql.score --split "$split" --workers 4 \
    --predictions "$RESULT_DIR/$split.json" --output "$RESULT_DIR/$split-score.json"
done
```

File references in this report are relative to the root of the extracted source ZIP. It contains the complete predictions and original official score files in `outputs/`, the training records in `training/`, and the model identity, inference receipts and resource records in `evidence/`. Receipts preserve prompts, generated text, token counts and model identity for inspection. The separate adapter ZIP contains only `adapter_config.json` and `adapter_model.safetensors`. Exact dependency versions and loading details are recorded in the reproduction guide. [Reproduction guide](REPRODUCE.md)
